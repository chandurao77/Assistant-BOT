import { ChevronLeft, Menu } from "lucide-react";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { TooltipProvider } from "@/components/ui/tooltip";
import { KIND_LABEL, TECH, jobById } from "@/lib/chat/jobs";
import { useBeaconStore } from "@/lib/chat/store";
import { ChatThread } from "./chat-thread";
import { Composer } from "./composer";
import { JobBoard } from "./job-board";
import { JobFacts, JobRail } from "./job-rail";
import { BeaconMark } from "./mark";

export function AppShell() {
  const hydrate = useBeaconStore((state) => state.hydrate);
  const activeJobId = useBeaconStore((state) => state.activeJobId);
  const clearJob = useBeaconStore((state) => state.clearJob);
  const [sheetOpen, setSheetOpen] = useState(false);
  const job = activeJobId ? jobById(activeJobId) : undefined;

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <TooltipProvider>
      <div className="flex h-dvh min-h-0 flex-col bg-bg text-fg">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-elevated focus:px-3 focus:py-2"
        >
          Skip to board
        </a>
        <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b border-border bg-surface px-3 sm:px-4">
          <div className="flex min-w-0 items-center gap-2">
            {job ? (
              <Button
                variant="ghost"
                size="icon"
                className="size-10 shrink-0"
                aria-label="Back to board"
                onClick={() => clearJob()}
              >
                <ChevronLeft className="size-5" />
              </Button>
            ) : (
              <BeaconMark className="size-7 shrink-0" />
            )}
            <div className="min-w-0">
              <p className="truncate text-sm font-medium tracking-tight">
                {job ? job.workOrder : "Beacon"}
              </p>
              <p className="truncate text-xs text-muted">
                {job
                  ? `${job.customer} · ${KIND_LABEL[job.kind]}`
                  : `${TECH.crew} · ${TECH.district}`}
              </p>
            </div>
          </div>
          {job ? (
            <Button
              variant="ghost"
              size="icon"
              className="size-10 lg:hidden"
              aria-label="Job details"
              onClick={() => setSheetOpen(true)}
            >
              <Menu className="size-5" />
            </Button>
          ) : (
            <span className="hidden text-xs text-subtle sm:inline">{TECH.name}</span>
          )}
        </header>

        <div id="main" className="flex min-h-0 flex-1">
          {job ? (
            <>
              <JobRail job={job} />
              <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-bg">
                <ChatThread job={job} />
                <Composer job={job} />
              </section>
            </>
          ) : (
            <section className="min-h-0 flex-1 overflow-y-auto">
              <JobBoard />
            </section>
          )}
        </div>

        {job ? (
          <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
            <SheetContent side="bottom" className="lg:hidden">
              <SheetHeader>
                <SheetTitle>{job.workOrder}</SheetTitle>
                <SheetDescription>
                  {job.customer} · {job.address}
                  {job.unit ? `, ${job.unit}` : ""}
                </SheetDescription>
              </SheetHeader>
              <JobFacts job={job} />
            </SheetContent>
          </Sheet>
        ) : null}

        <Toaster
          position="bottom-center"
          toastOptions={{
            className: "bg-ink text-accent-fg border-0 shadow-border rounded-md font-sans text-sm",
          }}
        />
      </div>
    </TooltipProvider>
  );
}
