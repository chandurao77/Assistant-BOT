import { Clock, MapPin } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { KIND_LABEL, TECH } from "@/lib/chat/jobs";
import { JOBS, useBeaconStore } from "@/lib/chat/store";
import type { Job } from "@/lib/chat/types";
import { cn } from "@/lib/utils";

const kindTone = {
  install: "ink",
  mesh: "neutral",
  trouble: "danger",
} as const;

export function JobBoard() {
  const selectJob = useBeaconStore((state) => state.selectJob);
  const [today, setToday] = useState("Today");
  useEffect(() => {
    setToday(
      new Date().toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
      }),
    );
  }, []);
  const high = JOBS.filter((job) => job.priority === "high").length;

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col px-4 pt-8 pb-16 sm:px-6">
      <header className="flex items-start justify-between gap-4">
        <div className="stagger-in">
          <h1 className="font-display max-w-md text-3xl leading-tight font-medium tracking-display text-balance">
            Today’s board
          </h1>
          <p className="mt-2 text-sm text-muted">
            {TECH.name} · {TECH.crew} · {TECH.district}
          </p>
        </div>
        <div className="stagger-in stagger-2 text-right">
          <p className="font-mono text-xs text-subtle tabular-nums uppercase">{today}</p>
          <p className="mt-1 text-sm text-muted">
            {JOBS.length} open{high ? ` · ${high} high` : ""}
          </p>
        </div>
      </header>

      <ol className="mt-8 flex flex-col gap-3">
        {JOBS.map((job, index) => (
          <li key={job.id} className={cn("stagger-in", `stagger-${index + 1}`)}>
            <JobCard job={job} onOpen={() => selectJob(job.id)} />
          </li>
        ))}
      </ol>
    </div>
  );
}

function JobCard({ job, onOpen }: { job: Job; onOpen: () => void }) {
  const where = job.unit ? `${job.address}, ${job.unit}` : job.address;
  return (
    <button
      type="button"
      onClick={onOpen}
      className={cn(
        "w-full rounded-xl bg-elevated p-4 text-left shadow-border",
        "transition-[box-shadow,transform] duration-(--motion-quick) ease-(--ease-out)",
        "hover:shadow-border-hover active:scale-[0.99]",
        "focus-visible:ring-2 focus-visible:ring-accent/40 focus-visible:outline-none",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm text-fg tabular-nums">{job.workOrder}</span>
          <Badge tone={kindTone[job.kind]}>{KIND_LABEL[job.kind]}</Badge>
          {job.priority === "high" ? <Badge tone="high">High</Badge> : null}
        </div>
        <span className="flex items-center gap-1 text-xs text-subtle">
          <Clock className="size-3" />
          {job.window}
        </span>
      </div>
      <p className="mt-3 text-base font-medium text-fg">{job.customer}</p>
      <p className="mt-1 flex items-start gap-1.5 text-sm text-muted">
        <MapPin className="mt-0.5 size-3.5 shrink-0" />
        <span>
          {where}
          <span className="text-subtle"> · {job.city}</span>
        </span>
      </p>
      <p className="mt-3 text-sm text-pretty text-muted">{job.notes}</p>
      <p className="mt-3 font-mono text-xs text-subtle tabular-nums">
        {job.planDown >= 1000 ? `${job.planDown / 1000} Gig` : `${job.planDown} Mbps`} ·{" "}
        {job.gateway.model}
      </p>
    </button>
  );
}
