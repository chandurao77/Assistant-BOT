import { ArrowUp } from "lucide-react";
import { useState, type FormEvent, type KeyboardEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { actionsFor } from "@/lib/chat/jobs";
import { useBeaconStore } from "@/lib/chat/store";
import type { Job } from "@/lib/chat/types";

export function Composer({ job }: { job: Job }) {
  const pending = useBeaconStore((state) => state.pending);
  const send = useBeaconStore((state) => state.send);
  const runAction = useBeaconStore((state) => state.runAction);
  const [value, setValue] = useState("");
  const actions = actionsFor(job);

  function submit(event?: FormEvent) {
    event?.preventDefault();
    const text = value.trim();
    if (!text || pending) return;
    setValue("");
    void send(text);
  }

  function onKey(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  }

  return (
    <div className="border-t border-border bg-surface/90 px-3 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-sm sm:px-6">
      <div className="mx-auto flex w-full max-w-2xl flex-col gap-2">
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {actions.map((action) => (
            <button
              key={action.id}
              type="button"
              disabled={pending}
              onClick={() => runAction(action.id)}
              className="h-11 shrink-0 rounded-full bg-elevated px-3.5 text-sm text-fg shadow-border transition-[box-shadow,opacity,transform] duration-(--motion-quick) ease-(--ease-out) hover:shadow-border-hover active:scale-[0.96] disabled:opacity-50"
            >
              {action.label}
            </button>
          ))}
        </div>
        <form
          onSubmit={submit}
          className="flex items-center gap-2 rounded-xl bg-elevated p-1.5 shadow-border focus-within:shadow-border-hover"
        >
          <Input
            value={value}
            onChange={(event) => setValue(event.target.value)}
            onKeyDown={onKey}
            placeholder="Ask Beacon about this drop…"
            aria-label="Message Beacon"
            disabled={pending}
            className="h-11 min-w-0 flex-1 text-sm sm:text-base"
          />
          <Button
            type="submit"
            size="icon"
            className="size-11 shrink-0 rounded-lg"
            disabled={pending || !value.trim()}
            aria-label="Send"
          >
            <ArrowUp className="size-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
