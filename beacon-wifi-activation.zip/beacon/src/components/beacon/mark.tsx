import { cn } from "@/lib/utils";

export function BeaconMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("text-accent", className)} aria-hidden="true">
      <path
        d="M10.2 11.2a8.2 8.2 0 0 1 11.6 0"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
      <path
        d="M6.6 8.2a13 13 0 0 1 18.8 0"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
      <circle cx="16" cy="16" r="3.1" fill="currentColor" />
      <rect x="14.35" y="19.2" width="3.3" height="8.2" rx="1.1" fill="currentColor" />
    </svg>
  );
}
