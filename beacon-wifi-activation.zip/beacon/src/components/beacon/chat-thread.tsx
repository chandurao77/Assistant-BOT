import { useEffect, useRef } from "react";
import { TECH, actionsFor } from "@/lib/chat/jobs";
import { useBeaconStore } from "@/lib/chat/store";
import type { ChatMessage, Job } from "@/lib/chat/types";
import { cn } from "@/lib/utils";
import { MessageCards } from "./cards";
import { BeaconMark } from "./mark";

export function ChatThread({ job }: { job: Job }) {
  const messages = useBeaconStore((state) => state.conversations[job.id] ?? []);
  const pending = useBeaconStore((state) => state.pending);
  const runAction = useBeaconStore((state) => state.runAction);
  const send = useBeaconStore((state) => state.send);
  const scrollerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages, pending]);

  return (
    <div ref={scrollerRef} className="min-h-0 flex-1 overflow-y-auto px-4 py-5 sm:px-6">
      <div className="mx-auto flex w-full max-w-2xl flex-col gap-5">
        {messages.map((message) => (
          <MessageRow
            key={message.id}
            message={message}
            onChip={(label) => {
              if (label === "Back to board") {
                useBeaconStore.getState().clearJob();
                return;
              }
              const action = actionsFor(job).find((item) => item.label === label);
              if (action) runAction(action.id);
              else void send(label);
            }}
          />
        ))}
        {pending ? <Typing /> : null}
      </div>
    </div>
  );
}

function MessageRow({
  message,
  onChip,
}: {
  message: ChatMessage;
  onChip: (label: string) => void;
}) {
  const mine = message.role === "user";
  return (
    <article className={cn("flex gap-3", mine ? "flex-row-reverse" : "flex-row")}>
      {mine ? (
        <div
          className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full bg-accent font-mono text-[10px] text-accent-fg"
          aria-hidden
        >
          {TECH.initials}
        </div>
      ) : (
        <div
          className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-elevated shadow-border"
          aria-hidden
        >
          <BeaconMark className="size-4" />
        </div>
      )}
      <div className={cn("min-w-0 max-w-[min(100%,36rem)]", mine && "text-right")}>
        <p className="text-xs text-subtle">{mine ? TECH.name : "Beacon"}</p>
        <div
          className={cn(
            "mt-1 rounded-lg px-3.5 py-2.5 text-left text-sm leading-normal text-pretty",
            mine ? "bg-accent text-accent-fg" : "bg-elevated text-fg shadow-border",
          )}
        >
          {message.text}
        </div>
        {!mine && message.cards?.length ? <MessageCards cards={message.cards} /> : null}
        {!mine && message.quickReplies?.length ? (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {message.quickReplies.map((label, index) => (
              <button
                key={`${label}-${index}`}
                type="button"
                onClick={() => onChip(label)}
                className="h-11 rounded-full bg-elevated px-3.5 text-sm text-fg shadow-border transition-[box-shadow,transform] duration-(--motion-quick) ease-(--ease-out) hover:shadow-border-hover active:scale-[0.96]"
              >
                {label}
              </button>
            ))}
          </div>
        ) : null}
      </div>
    </article>
  );
}

function Typing() {
  return (
    <div className="flex gap-3">
      <div className="mt-0.5 flex size-8 items-center justify-center rounded-md bg-elevated shadow-border">
        <BeaconMark className="size-4" />
      </div>
      <div className="rounded-lg bg-elevated px-3.5 py-3 shadow-border">
        <p className="sr-only">Beacon is writing</p>
        <span className="flex gap-1" aria-hidden>
          <span className="typing-dot" />
          <span className="typing-dot" />
          <span className="typing-dot" />
        </span>
      </div>
    </div>
  );
}
