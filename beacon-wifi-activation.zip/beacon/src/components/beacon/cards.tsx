import { Check, Copy, Eye, EyeOff, Wifi } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import type {
  CloseoutCard,
  DeviceCard,
  MessageCard,
  OntCard,
  SpeedCard,
  SsidCard,
  StepsCard,
  WarnCard,
} from "@/lib/chat/types";
import { cn } from "@/lib/utils";

export function MessageCards({ cards }: { cards: MessageCard[] }) {
  return (
    <div className="mt-3 flex flex-col gap-2">
      {cards.map((card, index) => (
        <CardSwitch key={`${card.type}-${index}`} card={card} />
      ))}
    </div>
  );
}

function CardSwitch({ card }: { card: MessageCard }) {
  switch (card.type) {
    case "ont":
      return <OntPanel card={card} />;
    case "device":
      return <DevicePanel card={card} />;
    case "ssid":
      return <SsidPanel card={card} />;
    case "speed":
      return <SpeedPanel card={card} />;
    case "steps":
      return <StepsPanel card={card} />;
    case "closeout":
      return <CloseoutPanel card={card} />;
    case "warn":
      return <WarnPanel card={card} />;
  }
}

function FieldCard({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-lg bg-elevated p-4 shadow-border", className)}>{children}</div>
  );
}

function Meta({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <p className="text-xs font-medium tracking-wide text-subtle uppercase">{label}</p>
      <p className={cn("mt-0.5 truncate text-sm text-fg", mono && "font-mono tabular-nums")}>
        {value}
      </p>
    </div>
  );
}

function Led({
  label,
  state,
  good,
}: {
  label: string;
  state: string;
  good: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <span
        className={cn(
          "size-2.5 rounded-full",
          good ? "bg-signal" : state === "search" ? "bg-warn" : "bg-danger",
        )}
        aria-hidden
      />
      <span className="w-14 text-sm text-muted">{label}</span>
      <span className="font-mono text-sm tracking-wide text-fg uppercase">{state}</span>
    </div>
  );
}

function OntPanel({ card }: { card: OntCard }) {
  return (
    <FieldCard>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-subtle uppercase">ONT</p>
          <p className="mt-0.5 text-sm font-medium text-fg">{card.model}</p>
        </div>
        <p className="font-mono text-xs text-muted tabular-nums">{card.serial}</p>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2">
        <Led label="Power" state={card.power} good={card.power === "on"} />
        <Led label="PON" state={card.pon} good={card.pon === "lock"} />
        <Led label="LOS" state={card.los} good={card.los === "clear"} />
        <Led label="LAN" state={card.lan} good={card.lan === "up"} />
      </div>
    </FieldCard>
  );
}

function DevicePanel({ card }: { card: DeviceCard }) {
  return (
    <FieldCard>
      <p className="text-xs font-medium tracking-wide text-subtle uppercase">{card.role}</p>
      <p className="mt-1 text-sm font-medium text-fg">{card.model}</p>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-2">
        <Meta label="Serial" value={card.serial} mono />
        <span className="rounded-full bg-signal/12 px-2 py-0.5 text-xs font-medium text-signal">
          {card.status}
        </span>
      </div>
      {card.detail ? <p className="mt-3 text-sm text-pretty text-muted">{card.detail}</p> : null}
    </FieldCard>
  );
}

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      className="size-9"
      aria-label={`Copy ${label}`}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          toast(`Copied ${label}`);
          window.setTimeout(() => setCopied(false), 1400);
        } catch {
          toast("Could not copy");
        }
      }}
    >
      {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
    </Button>
  );
}

function SsidPanel({ card }: { card: SsidCard }) {
  const [show, setShow] = useState(false);
  return (
    <FieldCard>
      <div className="flex items-center gap-2">
        <Wifi className="size-4 text-muted" />
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">SSID plan</p>
      </div>
      <div className="mt-3 grid gap-3">
        <div className="flex items-center justify-between gap-2">
          <Meta label="2.4 GHz" value={card.band24} />
          <CopyButton value={card.band24} label="2.4 GHz name" />
        </div>
        <div className="flex items-center justify-between gap-2">
          <Meta label="5 GHz" value={card.band5} />
          <CopyButton value={card.band5} label="5 GHz name" />
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-wide text-subtle uppercase">Passphrase</p>
            <p className="mt-0.5 font-mono text-sm text-fg">
              {show ? card.passphrase : "••••••••••••"}
            </p>
          </div>
          <div className="flex">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-9"
              aria-label={show ? "Hide passphrase" : "Show passphrase"}
              onClick={() => setShow((value) => !value)}
            >
              {show ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
            </Button>
            <CopyButton value={card.passphrase} label="passphrase" />
          </div>
        </div>
      </div>
      <p className="mt-3 text-xs text-muted">
        Band steering {card.steering ? "on" : "off"} · same key on both radios
      </p>
    </FieldCard>
  );
}

function SpeedBar({ value, plan, label }: { value: number; plan: number; label: string }) {
  const pct = Math.min(100, Math.round((value / plan) * 100));
  const pass = value >= plan * 0.7;
  return (
    <div>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-medium tracking-wide text-subtle uppercase">{label}</span>
        <span className="font-mono text-sm text-fg tabular-nums">
          {value} <span className="text-subtle">/ {plan}</span>
        </span>
      </div>
      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-fg/8">
        <div
          className={cn("h-full rounded-full", pass ? "bg-signal" : "bg-warn")}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function SpeedPanel({ card }: { card: SpeedCard }) {
  const pass = card.down >= card.planDown * 0.7 && card.up >= card.planUp * 0.7;
  return (
    <FieldCard>
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">Speed test</p>
        <span
          className={cn(
            "rounded-full px-2 py-0.5 text-xs font-medium",
            pass ? "bg-signal/12 text-signal" : "bg-warn/12 text-warn",
          )}
        >
          {pass ? "Pass" : "Below 70%"}
        </span>
      </div>
      <p className="mt-1 text-sm text-muted">
        {card.band} · {card.location}
      </p>
      <div className="mt-4 flex flex-col gap-3">
        <SpeedBar value={card.down} plan={card.planDown} label="Down Mbps" />
        <SpeedBar value={card.up} plan={card.planUp} label="Up Mbps" />
      </div>
    </FieldCard>
  );
}

function StepsPanel({ card }: { card: StepsCard }) {
  return (
    <FieldCard>
      <p className="text-xs font-medium tracking-wide text-subtle uppercase">{card.title}</p>
      <ol className="mt-3 flex flex-col gap-2.5">
        {card.items.map((item, index) => (
          <li key={`${index}-${item}`} className="flex gap-3 text-sm text-pretty text-fg">
            <span className="font-mono text-xs text-subtle tabular-nums">{index + 1}</span>
            <span>{item}</span>
          </li>
        ))}
      </ol>
    </FieldCard>
  );
}

function CloseoutPanel({ card }: { card: CloseoutCard }) {
  return (
    <FieldCard>
      <p className="text-xs font-medium tracking-wide text-subtle uppercase">Closeout</p>
      <p className="mt-1 font-mono text-sm text-fg">{card.workOrder}</p>
      <p className="mt-1 text-sm text-pretty text-muted">{card.summary}</p>
      <ul className="mt-3 flex flex-col gap-2">
        {card.checks.map((check) => (
          <li key={check.label} className="flex items-center gap-2 text-sm text-fg">
            <Check className={cn("size-3.5", check.done ? "text-signal" : "text-subtle")} />
            {check.label}
          </li>
        ))}
      </ul>
    </FieldCard>
  );
}

function WarnPanel({ card }: { card: WarnCard }) {
  return (
    <FieldCard className="shadow-none ring-1 ring-warn/30">
      <p className="text-xs font-medium tracking-wide text-warn uppercase">{card.title}</p>
      <p className="mt-1 text-sm text-pretty text-fg">{card.body}</p>
    </FieldCard>
  );
}
