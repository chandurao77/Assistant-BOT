import { Check } from "lucide-react";
import { KIND_LABEL } from "@/lib/chat/jobs";
import { useBeaconStore } from "@/lib/chat/store";
import type { Job } from "@/lib/chat/types";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export function JobRail({ job }: { job: Job }) {
  const completed = useBeaconStore((state) => state.completed[job.id] ?? []);
  const send = useBeaconStore((state) => state.send);
  const pending = useBeaconStore((state) => state.pending);
  const doneCount = job.steps.filter((step) => completed.includes(step.id)).length;

  return (
    <aside className="hidden w-[20.5rem] shrink-0 flex-col border-r border-border bg-surface lg:flex">
      <div className="px-5 pt-6 pb-4">
        <p className="font-mono text-xs text-subtle tabular-nums">{job.workOrder}</p>
        <h2 className="font-display mt-1 text-lg leading-snug font-medium tracking-tight text-fg">
          {job.customer}
        </h2>
        <p className="mt-1 text-sm text-muted">
          {job.address}
          {job.unit ? `, ${job.unit}` : ""}
          <span className="text-subtle"> · {job.city}</span>
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Badge tone={job.kind === "trouble" ? "danger" : job.kind === "install" ? "ink" : "neutral"}>
            {KIND_LABEL[job.kind]}
          </Badge>
          {job.priority === "high" ? <Badge tone="high">High</Badge> : null}
        </div>
      </div>
      <Separator />
      <div className="px-5 py-4">
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">Equipment</p>
        <dl className="mt-3 flex flex-col gap-3">
          <RailMeta label="ONT" value={job.ont.serial} hint={job.ont.model} />
          <RailMeta label="Gateway" value={job.gateway.serial} hint={job.gateway.model} />
          {job.meshNodes[0] ? (
            <RailMeta label="Node" value={job.meshNodes[0].serial} hint={job.meshNodes[0].model} />
          ) : null}
        </dl>
      </div>
      <Separator />
      <div className="flex min-h-0 flex-1 flex-col px-5 py-4">
        <div className="flex items-baseline justify-between">
          <p className="text-xs font-medium tracking-wide text-subtle uppercase">Activation</p>
          <p className="font-mono text-xs text-muted tabular-nums">
            {doneCount}/{job.steps.length}
          </p>
        </div>
        <ol className="mt-3 flex flex-col gap-0.5">
          {job.steps.map((step, index) => {
            const done = completed.includes(step.id);
            return (
              <li key={step.id}>
                <button
                  type="button"
                  disabled={pending}
                  onClick={() => send(step.hint)}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-md px-2 py-2 text-left",
                    "transition-[background-color] duration-(--motion-quick) ease-(--ease-out)",
                    "hover:bg-fg/4 disabled:opacity-50",
                  )}
                >
                  <span
                    className={cn(
                      "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full",
                      done ? "bg-signal text-accent-fg" : "bg-fg/8 text-subtle",
                    )}
                  >
                    {done ? (
                      <Check className="size-3" strokeWidth={2.5} />
                    ) : (
                      <span className="font-mono text-[10px] tabular-nums">{index + 1}</span>
                    )}
                  </span>
                  <span className="min-w-0">
                    <span className={cn("block text-sm", done ? "text-muted" : "text-fg")}>
                      {step.label}
                    </span>
                    <span className="mt-0.5 block text-xs text-pretty text-subtle">{step.hint}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      </div>
    </aside>
  );
}

function RailMeta({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div>
      <dt className="text-xs text-subtle">{label}</dt>
      <dd className="font-mono text-sm text-fg tabular-nums">{value}</dd>
      <p className="text-xs text-muted">{hint}</p>
    </div>
  );
}

export function JobFacts({ job }: { job: Job }) {
  const completed = useBeaconStore((state) => state.completed[job.id] ?? []);
  const doneCount = job.steps.filter((step) => completed.includes(step.id)).length;
  return (
    <div className="flex flex-col gap-4 px-5 pb-8">
      <p className="text-sm text-pretty text-muted">{job.notes}</p>
      <div>
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">Plan</p>
        <p className="mt-1 font-mono text-sm tabular-nums">
          {job.planDown}/{job.planUp} Mbps · {job.window}
        </p>
      </div>
      <div>
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">Equipment</p>
        <p className="mt-1 font-mono text-sm tabular-nums">{job.ont.model}</p>
        <p className="font-mono text-xs text-muted">{job.ont.serial}</p>
        <p className="mt-2 font-mono text-sm tabular-nums">{job.gateway.model}</p>
        <p className="font-mono text-xs text-muted">{job.gateway.serial}</p>
      </div>
      <div>
        <p className="text-xs font-medium tracking-wide text-subtle uppercase">
          Activation · {doneCount}/{job.steps.length}
        </p>
        <ul className="mt-2 flex flex-col gap-1.5">
          {job.steps.map((step) => (
            <li key={step.id} className="flex items-center gap-2 text-sm">
              <Check
                className={cn(
                  "size-3.5",
                  completed.includes(step.id) ? "text-signal" : "text-subtle",
                )}
              />
              <span className={completed.includes(step.id) ? "text-muted" : "text-fg"}>
                {step.label}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
