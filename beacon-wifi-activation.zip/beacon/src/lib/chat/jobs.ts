import type { Job, QuickAction } from "./types";

export const TECH = {
  name: "Jordan Hale",
  initials: "JH",
  crew: "Crew 7",
  district: "North District",
};

export const JOBS: Job[] = [
  {
    id: "wo-48291",
    workOrder: "WO-48291",
    kind: "install",
    priority: "normal",
    address: "1847 Maple Avenue",
    city: "Ridgefield",
    customer: "Maya Ellison",
    phone: "555-0148",
    planDown: 1000,
    planUp: 1000,
    window: "14:00–16:00",
    notes: "New fiber drop. ONT already lit by construction. Hang GX-6, set SSID, prove 1 Gig.",
    ont: { model: "Nokia XS-010X-A", serial: "ALCLF8A21944" },
    gateway: { model: "Arcadyan GX-6", serial: "GX6-4419-7C2A" },
    meshNodes: [],
    ssid: {
      band24: "Maple-1847",
      band5: "Maple-1847-5",
      passphrase: "ridge.maple.19",
    },
    steps: [
      { id: "arrive", label: "Verify address", hint: "Match the drop to Maple 1847 before you unbox." },
      { id: "ont", label: "Confirm ONT lights", hint: "Power, PON lock, LOS clear." },
      { id: "gateway", label: "Seat the gateway", hint: "LAN 1 from ONT, power, wait for WAN." },
      { id: "ssid", label: "Set SSID and key", hint: "Write the names on the gatefold sticker." },
      { id: "speed", label: "Speed test", hint: "Stand 2 m from the gateway on 5 GHz." },
      { id: "handoff", label: "Customer handoff", hint: "Show the names, the app, and the 1 Gig result." },
      { id: "close", label: "Close the job", hint: "Photos, serials, and a one-line closeout." },
    ],
  },
  {
    id: "wo-48302",
    workOrder: "WO-48302",
    kind: "mesh",
    priority: "normal",
    address: "22 Harbor Court",
    unit: "Apt 4B",
    city: "Ridgefield",
    customer: "Luis Ortega",
    phone: "555-0192",
    planDown: 300,
    planUp: 300,
    window: "16:00–18:00",
    notes: "Existing service. Dead zone in the back bedroom. Add one mesh node, keep current SSID.",
    ont: { model: "Nokia XS-010X-A", serial: "ALCLF7C11028" },
    gateway: { model: "Arcadyan GX-6", serial: "GX6-3188-AA01" },
    meshNodes: [{ model: "Arcadyan MX-1", serial: "MX1-8821-04F0" }],
    ssid: {
      band24: "Harbor22",
      band5: "Harbor22-5",
      passphrase: "orcas.tide.4b",
    },
    steps: [
      { id: "verify", label: "Verify existing WiFi", hint: "Confirm the current SSID still authenticates." },
      { id: "place", label: "Place the node", hint: "Halfway to the dead room, not in a cabinet." },
      { id: "pair", label: "Pair the node", hint: "WPS on gateway, then node, wait for backhaul." },
      { id: "backhaul", label: "Check backhaul", hint: "Node should show a wired-grade wireless hop." },
      { id: "walk", label: "Coverage walk", hint: "Test the bedroom that failed yesterday." },
      { id: "speed", label: "Far-room speed test", hint: "Must hold the 300 plan at the complaint room." },
      { id: "close", label: "Close the job", hint: "Leave the node where it passed, not where it looks pretty." },
    ],
  },
  {
    id: "wo-48318",
    workOrder: "WO-48318",
    kind: "trouble",
    priority: "high",
    address: "901 Cedar Ridge Road",
    city: "Westmere",
    customer: "Hannah Cho",
    phone: "555-0166",
    planDown: 1000,
    planUp: 1000,
    window: "Now · committed",
    notes: "No WiFi after last night’s outage. Customer rebooted twice. Check path from ONT to gateway before you swap hardware.",
    ont: { model: "Nokia XS-010X-A", serial: "ALCLF9B33017" },
    gateway: { model: "Arcadyan GX-6", serial: "GX6-9021-11DE" },
    meshNodes: [],
    ssid: {
      band24: "Cedar901",
      band5: "Cedar901-5",
      passphrase: "westmere.ridge.7",
    },
    steps: [
      { id: "repro", label: "Reproduce the fault", hint: "Confirm SSIDs are missing, not just slow." },
      { id: "power", label: "Power-cycle the path", hint: "Gateway off, ONT 30 s, ONT on, then gateway." },
      { id: "ont", label: "Read ONT lights", hint: "LOS alarm means stop and call fiber, not WiFi." },
      { id: "wan", label: "Check gateway WAN", hint: "Internet LED and 192.168.1.1 status page." },
      { id: "wifi", label: "Prove WiFi", hint: "Join both bands, then a 5 GHz speed test." },
      { id: "close", label: "Close the job", hint: "Note root cause: power path, not a new gateway." },
    ],
  },
];

export const KIND_LABEL: Record<Job["kind"], string> = {
  install: "New install",
  mesh: "Mesh add",
  trouble: "Trouble",
};

export function jobById(id: string): Job | undefined {
  return JOBS.find((job) => job.id === id);
}

export function actionsFor(job: Job): QuickAction[] {
  if (job.kind === "install") {
    return [
      { id: "ont", label: "ONT lights", prompt: "Walk me through the ONT lights on this drop." },
      { id: "gateway", label: "Seat gateway", prompt: "How do I seat the gateway and get WAN up?" },
      { id: "ssid", label: "Set SSID", prompt: "Give me the SSID plan and how to write it." },
      { id: "speed", label: "Speed test", prompt: "Run me through the 1 Gig speed test." },
      { id: "close", label: "Close job", prompt: "Help me close this work order." },
    ];
  }
  if (job.kind === "mesh") {
    return [
      { id: "place", label: "Place node", prompt: "Where should I place the mesh node in this apartment?" },
      { id: "pair", label: "Pair node", prompt: "Walk me through pairing the mesh node." },
      { id: "walk", label: "Coverage walk", prompt: "How do I prove the dead zone is gone?" },
      { id: "speed", label: "Far-room test", prompt: "What speed should I see in the back bedroom?" },
      { id: "close", label: "Close job", prompt: "Help me close this mesh add." },
    ];
  }
  return [
    { id: "repro", label: "Reproduce", prompt: "How do I confirm this is a true no-WiFi fault?" },
    { id: "power", label: "Power path", prompt: "Give me the power-cycle order for ONT and gateway." },
    { id: "ont", label: "ONT lights", prompt: "What should the ONT lights look like after the outage?" },
    { id: "wan", label: "WAN status", prompt: "Gateway has power. How do I check WAN?" },
    { id: "close", label: "Close job", prompt: "Help me close this trouble ticket." },
  ];
}
