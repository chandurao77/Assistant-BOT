import type { AssistantPayload, Job } from "./types";

function nextChips(...labels: string[]): string[] {
  return labels.filter(Boolean).slice(0, 3);
}

export function greetingFor(job: Job): AssistantPayload {
  const where = job.unit ? `${job.address}, ${job.unit}` : job.address;
  if (job.kind === "install") {
    return {
      text: `${job.customer} at ${where}. ${job.planDown / 1000} Gig symmetric, window ${job.window}. Construction already lit the ONT — your job is the gateway, the names, and a clean speed test. Start with the drop address, then the three ONT lights.`,
      cards: [
        {
          type: "device",
          role: "ONT on the drop",
          model: job.ont.model,
          serial: job.ont.serial,
          status: "Lit by construction",
          detail: "Do not reseat unless PON is dark.",
        },
        {
          type: "steps",
          title: "First ten minutes",
          items: [
            `Match ${job.address} to the drop tag before you cut plastic.`,
            "Read Power / PON / LOS on the ONT.",
            "LAN 1 from ONT to the GX-6, then power the gateway.",
          ],
        },
      ],
      complete: ["arrive"],
    };
  }
  if (job.kind === "mesh") {
    return {
      text: `${job.customer}, ${where}. Existing ${job.planDown} Mbps service, complaint is the back bedroom. Keep SSID ${job.ssid.band24}. You have one MX-1. Place it halfway — not in the room that failed, and not in a cabinet.`,
      cards: [
        {
          type: "ssid",
          band24: job.ssid.band24,
          band5: job.ssid.band5,
          passphrase: job.ssid.passphrase,
          steering: true,
        },
        {
          type: "device",
          role: "Mesh node",
          model: job.meshNodes[0]?.model ?? "MX-1",
          serial: job.meshNodes[0]?.serial ?? "—",
          status: "Unpaired",
          detail: "Pair after placement, not on the kitchen counter.",
        },
      ],
      complete: ["verify"],
    };
  }
  return {
    text: `High priority. ${job.customer} at ${where} has had no WiFi since last night’s outage. Do not start with a gateway swap. Reproduce the fault, then power-cycle ONT → gateway in that order. If LOS is red, this is fiber, not WiFi.`,
    cards: [
      {
        type: "warn",
        title: "Outage path",
        body: "Customer already rebooted the gateway twice. A third reboot without an ONT read wastes the committed window.",
      },
      {
        type: "steps",
        title: "Order of operations",
        items: [
          "Confirm the SSIDs are gone, not just slow.",
          "Gateway off. ONT 30 seconds off. ONT on. Wait for PON lock.",
          "Then gateway on. Read WAN before you touch WiFi names.",
        ],
      },
    ],
  };
}

export function replyFor(job: Job, text: string): AssistantPayload {
  const t = text.toLowerCase();

  if (/(los.+(red|alarm|on|lit)|red los|los alarm|los is (red|on))/.test(t)) {
    return losAlarmReply(job);
  }
  if (/(ont|pon|optical|gpon|lights?)/.test(t)) return ontReply(job);
  if (/(wan|seat|gateway|gx-6|gx6|hang the|internet led)/.test(t)) return gatewayReply(job);
  if (/(ssid|passphrase|password|wifi name|key|write it)/.test(t)) return ssidReply(job);
  if (/(pair|wps|backhaul|mesh node|mx-1|mx1)/.test(t)) return meshReply(job);
  if (/(place the node|placement|where should i place|cabinet)/.test(t)) return placeReply(job);
  if (/(coverage|dead zone|walk|bedroom|far room)/.test(t)) return coverageReply(job);
  if (/(speed|gig|mbps|iperf|ookla|test)/.test(t)) return speedReply(job);
  if (/(power.cycle|power path|outage|reboot|reproduce)/.test(t)) return powerReply(job);
  if (/(handoff|customer|explain|show them)/.test(t)) return handoffReply(job);
  if (/(close|closeout|wrap|complete the job|done)/.test(t)) return closeReply(job);
  if (/(serial|barcode|scan)/.test(t)) return serialReply(job);

  return {
    text: `Stay on this ticket — ${job.workOrder} at ${job.address}. I can walk ONT lights, WAN, SSID, mesh pairing, coverage, speed test, or closeout. Tell me what the lights or the customer are doing.`,
    quickReplies: nextChips("ONT lights", "Set SSID", "Close job"),
  };
}

function losAlarmReply(job: Job): AssistantPayload {
  return {
    text: "Stop. A red LOS is a dark drop — the ONT cannot see the plant. Do not reseat the fiber more than once, do not swap the gateway, do not set SSIDs. Photograph the ONT face, leave it powered, and kick this to fiber. WiFi will not come up on a dead PON.",
    cards: [
      {
        type: "ont",
        model: job.ont.model,
        serial: job.ont.serial,
        power: "on",
        pon: "off",
        los: "alarm",
        lan: "down",
      },
      {
        type: "warn",
        title: "Fiber ticket",
        body: "LOS alarm = plant or drop, not the GX-6. One reseat of the SC/APC, then hand it off.",
      },
    ],
    quickReplies: nextChips("ONT lights", "Close job"),
  };
}

function ontReply(job: Job): AssistantPayload {
  const trouble = job.kind === "trouble";
  return {
    text: trouble
      ? "After a clean power cycle the ONT should look like this: Power on, PON lock (steady), LOS clear, LAN up once the gateway is back. If LOS is alarm, stop. That is a dark drop — call fiber, do not swap the GX-6."
      : "Construction said this ONT is already in service. You want Power on, PON lock, LOS clear. LAN comes up after the gateway is seated. If PON is still searching after two minutes, do not hang WiFi on it — kick it back to fiber.",
    cards: [
      {
        type: "ont",
        model: job.ont.model,
        serial: job.ont.serial,
        power: "on",
        pon: "lock",
        los: "clear",
        lan: trouble ? "down" : "up",
      },
    ],
    quickReplies: nextChips(trouble ? "Power path" : "Seat gateway"),
    complete: job.kind === "mesh" ? [] : ["ont"],
  };
}

function gatewayReply(job: Job): AssistantPayload {
  return {
    text: `Seat the ${job.gateway.model} on a high, open shelf — not the floor, not behind the TV. Cat6 from ONT LAN to gateway WAN. Power last. WAN LED should go solid within three minutes. Serial ${job.gateway.serial} is the one that must match the work order.`,
    cards: [
      {
        type: "device",
        role: "Gateway",
        model: job.gateway.model,
        serial: job.gateway.serial,
        status: "Provisioning",
        detail: "WAN LED solid = provisioned. Blinking = still DHCP.",
      },
      {
        type: "steps",
        title: "Seat order",
        items: [
          "ONT LAN → GX-6 WAN. Do not use LAN 2/3/4 on the ONT.",
          "Power the gateway. Wait for the Internet LED.",
          "Only then open the local UI or the tech app to set names.",
        ],
      },
    ],
    quickReplies: nextChips("Set SSID"),
    complete: ["gateway", "wan"],
  };
}

function ssidReply(job: Job): AssistantPayload {
  return {
    text: `Write these names on the gatefold sticker before you leave the room. Band steering stays on. 2.4 and 5 share the passphrase. Do not “help” by renaming 5 GHz to something cute — the customer already has devices on ${job.ssid.band24}.`,
    cards: [
      {
        type: "ssid",
        band24: job.ssid.band24,
        band5: job.ssid.band5,
        passphrase: job.ssid.passphrase,
        steering: true,
      },
    ],
    quickReplies: nextChips("Speed test"),
    complete: ["ssid"],
  };
}

function placeReply(job: Job): AssistantPayload {
  return {
    text: "For 4B, put the MX-1 in the hallway niche between the living room and the back bedroom — about halfway, eye level, no metal cabinet, no aquarium. Pairing it next to the gateway and then walking it back is how you get a one-bar backhaul.",
    cards: [
      {
        type: "steps",
        title: "Placement",
        items: [
          "Gateway stays where it already has WAN.",
          "Node lives at the midpoint, not in the dead room.",
          "Power the node only after it sits in its final spot.",
        ],
      },
    ],
    quickReplies: nextChips("Pair node"),
    complete: ["place"],
  };
}

function meshReply(job: Job): AssistantPayload {
  const node = job.meshNodes[0];
  return {
    text: "Pair at the final location. Hold WPS on the GX-6 until it blinks, then WPS on the MX-1 within two minutes. Backhaul LED on the node should go steady. If it keeps hunting, the node is too far — walk it one room closer, do not factory-reset the gateway.",
    cards: [
      {
        type: "device",
        role: "Mesh node",
        model: node?.model ?? "Arcadyan MX-1",
        serial: node?.serial ?? "—",
        status: "Backhaul up",
        detail: "Steady LED = wireless hop is good. Hunting = move closer.",
      },
      {
        type: "steps",
        title: "Pairing",
        items: [
          "WPS on gateway until the LED blinks.",
          "WPS on the node within 120 seconds.",
          "Wait for a steady backhaul LED before you walk the apartment.",
        ],
      },
    ],
    quickReplies: nextChips("Coverage walk"),
    complete: ["pair", "backhaul"],
  };
}

function coverageReply(job: Job): AssistantPayload {
  return {
    text: "Phone on 5 GHz, WiFi details open. Walk living room → hallway → back bedroom. You want the bedroom to hold at least two bars and stay on the node, not jump to a neighbor’s SSID. If it still dumps to 2.4 from the gateway, the node is in the wrong niche.",
    cards: [
      {
        type: "steps",
        title: "Coverage walk",
        items: [
          "Join " + job.ssid.band5 + " explicitly for the walk.",
          "Pause 10 seconds in the complaint room before you judge it.",
          "If the bedroom is still on the gateway, move the node one room closer.",
        ],
      },
    ],
    quickReplies: nextChips("Far-room test"),
    complete: ["walk"],
  };
}

function speedReply(job: Job): AssistantPayload {
  const far = job.kind === "mesh";
  const down = far ? 318 : job.planDown >= 1000 ? 847 : 291;
  const up = far ? 274 : job.planUp >= 1000 ? 412 : 268;
  const pass = down >= job.planDown * 0.7;
  return {
    text: far
      ? `Far-room test, 5 GHz, on the node. Plan is ${job.planDown} / ${job.planUp}. You need about 70% of plan in the complaint room. ${pass ? "This pass closes the coverage ticket." : "If you are under 70%, move the node before you close."}`
      : `Stand two meters from the gateway, 5 GHz, no body between phone and radio. Plan is ${job.planDown} / ${job.planUp} Mbps. Wired LAN is the plant; WiFi will sit under that. Do not chase 1.0 Gig on a phone against a wall.`,
    cards: [
      {
        type: "speed",
        down,
        up,
        planDown: job.planDown,
        planUp: job.planUp,
        band: "5 GHz",
        location: far ? "Back bedroom · on node" : "2 m from gateway",
      },
    ],
    quickReplies: nextChips(job.kind === "install" ? "Customer handoff" : "Close job"),
    complete: ["speed"],
  };
}

function powerReply(job: Job): AssistantPayload {
  return {
    text: "Order matters. Take the gateway off power first so it does not hang on a dying ONT. Then ONT off for a full 30 seconds. ONT on, wait for PON lock. Gateway on last. If PON never locks, you are done with WiFi — this is a fiber ticket.",
    cards: [
      {
        type: "ont",
        model: job.ont.model,
        serial: job.ont.serial,
        power: "on",
        pon: "lock",
        los: "clear",
        lan: "up",
      },
      {
        type: "steps",
        title: "Power path",
        items: [
          "Gateway unplugged.",
          "ONT unplugged · 30 seconds · ONT back on.",
          "Wait for PON lock, then power the gateway.",
        ],
      },
    ],
    quickReplies: nextChips("ONT lights", "WAN status"),
    complete: ["power"],
  };
}

function handoffReply(job: Job): AssistantPayload {
  return {
    text: `Show ${job.customer.split(" ")[0]} the sticker, not the chat. Names are ${job.ssid.band24} and ${job.ssid.band5}, same key. Band steering is on. If a guest printer dies, it is almost always the 2.4 name — that is expected. Do not leave your tech SSID behind.`,
    cards: [
      {
        type: "ssid",
        band24: job.ssid.band24,
        band5: job.ssid.band5,
        passphrase: job.ssid.passphrase,
        steering: true,
      },
    ],
    quickReplies: nextChips("Close job"),
    complete: ["handoff"],
  };
}

function closeReply(job: Job): AssistantPayload {
  const checks =
    job.kind === "install"
      ? [
          { label: "ONT PON lock photographed", done: true },
          { label: "Gateway serial matches WO", done: true },
          { label: "SSID sticker left on gateway", done: true },
          { label: "5 GHz speed ≥ 70% of plan", done: true },
        ]
      : job.kind === "mesh"
        ? [
            { label: "Node paired at final location", done: true },
            { label: "Backhaul LED steady", done: true },
            { label: "Complaint room holds 5 GHz", done: true },
            { label: "Far-room speed ≥ 70% of plan", done: true },
          ]
        : [
            { label: "Fault reproduced", done: true },
            { label: "Power path completed", done: true },
            { label: "ONT LOS clear", done: true },
            { label: "WiFi restored on both bands", done: true },
          ];
  return {
    text: `Close ${job.workOrder}. Root note: ${job.kind === "trouble" ? "service restored after ordered power cycle; hardware not replaced." : job.kind === "mesh" ? "MX-1 placed at hallway midpoint; back bedroom holds plan." : "GX-6 seated, names written, 1 Gig proved on 5 GHz."} Photos on the WO, serials typed, customer shown the sticker.`,
    cards: [
      {
        type: "closeout",
        workOrder: job.workOrder,
        summary:
          job.kind === "trouble"
            ? "Restored after outage. No hardware swap."
            : job.kind === "mesh"
              ? "Mesh node added. Coverage complaint cleared."
              : "New install complete. 1 Gig proved.",
        checks,
      },
    ],
    quickReplies: ["Back to board"],
    complete: ["close"],
  };
}

function serialReply(job: Job): AssistantPayload {
  return {
    text: "Type the serials as printed, not as you remember them. ONT and gateway both go on the work order. If the GX-6 serial does not match the box you opened, stop and scan again before you provision.",
    cards: [
      {
        type: "device",
        role: "ONT",
        model: job.ont.model,
        serial: job.ont.serial,
        status: "On the drop",
      },
      {
        type: "device",
        role: "Gateway",
        model: job.gateway.model,
        serial: job.gateway.serial,
        status: "On this ticket",
      },
    ],
  };
}

export function payloadFromAction(job: Job, actionId: string): AssistantPayload {
  switch (actionId) {
    case "ont":
      return ontReply(job);
    case "gateway":
    case "wan":
      return gatewayReply(job);
    case "ssid":
      return ssidReply(job);
    case "place":
      return placeReply(job);
    case "pair":
      return meshReply(job);
    case "walk":
      return coverageReply(job);
    case "speed":
      return speedReply(job);
    case "power":
      return powerReply(job);
    case "repro":
      return {
        text: "Confirm the SSIDs are actually missing from the phone’s list — not just a stale connection. If Cedar901 still appears but will not auth, that is a different ticket than a dark radio.",
        cards: [
          {
            type: "warn",
            title: "Reproduce first",
            body: "No SSID in the list = radio or WAN. SSID present, auth fails = key or band. Do not skip this split.",
          },
        ],
        quickReplies: nextChips("Power path"),
        complete: ["repro"],
      };
    case "handoff":
      return handoffReply(job);
    case "close":
      return closeReply(job);
    default:
      return replyFor(job, actionId);
  }
}
