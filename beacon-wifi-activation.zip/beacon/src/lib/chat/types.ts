export type JobKind = "install" | "mesh" | "trouble";
export type JobPriority = "high" | "normal";
export type LedState = "on" | "off" | "search" | "alarm" | "lock" | "clear" | "up" | "down";

export type Job = {
  id: string;
  workOrder: string;
  kind: JobKind;
  priority: JobPriority;
  address: string;
  unit?: string;
  city: string;
  customer: string;
  phone: string;
  planDown: number;
  planUp: number;
  window: string;
  notes: string;
  ont: { model: string; serial: string };
  gateway: { model: string; serial: string };
  meshNodes: { model: string; serial: string }[];
  ssid: { band24: string; band5: string; passphrase: string };
  steps: ChecklistStep[];
};

export type ChecklistStep = {
  id: string;
  label: string;
  hint: string;
};

export type OntCard = {
  type: "ont";
  model: string;
  serial: string;
  power: "on" | "off";
  pon: "lock" | "search" | "off";
  los: "clear" | "alarm";
  lan: "up" | "down";
};

export type DeviceCard = {
  type: "device";
  role: string;
  model: string;
  serial: string;
  status: string;
  detail?: string;
};

export type SsidCard = {
  type: "ssid";
  band24: string;
  band5: string;
  passphrase: string;
  steering: boolean;
};

export type SpeedCard = {
  type: "speed";
  down: number;
  up: number;
  planDown: number;
  planUp: number;
  band: string;
  location: string;
};

export type StepsCard = {
  type: "steps";
  title: string;
  items: string[];
};

export type CloseoutCard = {
  type: "closeout";
  workOrder: string;
  summary: string;
  checks: { label: string; done: boolean }[];
};

export type WarnCard = {
  type: "warn";
  title: string;
  body: string;
};

export type MessageCard =
  | OntCard
  | DeviceCard
  | SsidCard
  | SpeedCard
  | StepsCard
  | CloseoutCard
  | WarnCard;

export type ChatRole = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: ChatRole;
  text: string;
  createdAt: number;
  cards?: MessageCard[];
  quickReplies?: string[];
};

export type AssistantPayload = {
  text: string;
  cards?: MessageCard[];
  quickReplies?: string[];
  complete?: string[];
};

export type QuickAction = {
  id: string;
  label: string;
  prompt: string;
};
