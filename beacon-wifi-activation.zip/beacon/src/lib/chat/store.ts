import { create } from "zustand";
import { askBeacon } from "./ask";
import { JOBS, actionsFor, jobById } from "./jobs";
import { greetingFor, payloadFromAction, replyFor } from "./playbook";
import type { AssistantPayload, ChatMessage, Job } from "./types";

const STORAGE_KEY = "beacon.v1";

type Persisted = {
  activeJobId: string | null;
  conversations: Record<string, ChatMessage[]>;
  completed: Record<string, string[]>;
};

type BeaconState = Persisted & {
  pending: boolean;
  sendError: string | null;
  hydrate: () => void;
  selectJob: (id: string) => void;
  clearJob: () => void;
  send: (text: string) => Promise<void>;
  runAction: (actionId: string) => void;
};

function uid(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function persist(state: Persisted) {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        activeJobId: state.activeJobId,
        conversations: state.conversations,
        completed: state.completed,
      } satisfies Persisted),
    );
  } catch {
    /* ignore quota */
  }
}

function assistantMessage(payload: AssistantPayload): ChatMessage {
  return {
    id: uid(),
    role: "assistant",
    text: payload.text,
    createdAt: Date.now(),
    cards: payload.cards,
    quickReplies: payload.quickReplies,
  };
}

function mergeComplete(
  completed: Record<string, string[]>,
  jobId: string,
  ids: string[] | undefined,
): Record<string, string[]> {
  if (!ids?.length) return completed;
  const current = new Set(completed[jobId] ?? []);
  for (const id of ids) current.add(id);
  return { ...completed, [jobId]: [...current] };
}

export const useBeaconStore = create<BeaconState>((set, get) => ({
  activeJobId: null,
  conversations: {},
  completed: {},
  pending: false,
  sendError: null,

  hydrate: () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as Persisted;
      if (!parsed || typeof parsed !== "object") return;
      set({
        activeJobId: parsed.activeJobId ?? null,
        conversations: parsed.conversations ?? {},
        completed: parsed.completed ?? {},
      });
    } catch {
      /* ignore */
    }
  },

  selectJob: (id) => {
    const job = jobById(id);
    if (!job) return;
    const existing = get().conversations[id];
    const greeting = greetingFor(job);
    const conversations = existing?.length
      ? get().conversations
      : {
          ...get().conversations,
          [id]: [assistantMessage(greeting)],
        };
    const completed = existing?.length
      ? get().completed
      : mergeComplete(get().completed, id, greeting.complete);
    const next = { activeJobId: id, conversations, completed };
    set({ ...next, sendError: null });
    persist({ ...get(), ...next });
  },

  clearJob: () => {
    set({ activeJobId: null, sendError: null });
    persist({ ...get(), activeJobId: null });
  },

  runAction: (actionId) => {
    const { activeJobId, conversations, completed, pending } = get();
    if (!activeJobId || pending) return;
    const job = jobById(activeJobId);
    if (!job) return;
    if (actionId === "board" || actionId === "Back to board") {
      get().clearJob();
      return;
    }
    const action = actionsFor(job).find((item) => item.id === actionId);
    const prompt = action?.prompt ?? actionId;
    const payload = payloadFromAction(job, action?.id ?? actionId);
    const user: ChatMessage = {
      id: uid(),
      role: "user",
      text: prompt,
      createdAt: Date.now(),
    };
    const nextConv = {
      ...conversations,
      [activeJobId]: [...(conversations[activeJobId] ?? []), user, assistantMessage(payload)],
    };
    const nextCompleted = mergeComplete(completed, activeJobId, payload.complete);
    set({ conversations: nextConv, completed: nextCompleted, sendError: null });
    persist({ activeJobId, conversations: nextConv, completed: nextCompleted });
  },

  send: async (text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    const { activeJobId, conversations, completed, pending } = get();
    if (!activeJobId || pending) return;
    const job = jobById(activeJobId);
    if (!job) return;

    const user: ChatMessage = {
      id: uid(),
      role: "user",
      text: trimmed,
      createdAt: Date.now(),
    };
    const thread = [...(conversations[activeJobId] ?? []), user];
    set({
      pending: true,
      sendError: null,
      conversations: { ...conversations, [activeJobId]: thread },
    });

    const fallback = replyFor(job, trimmed);
    let payload = fallback;

    try {
      const history = thread.slice(-12).map((message) => ({
        role: message.role,
        content: message.text,
      }));
      const result = await askBeacon({
        data: {
          messages: history,
          job: jobContext(job, completed[activeJobId] ?? []),
        },
      });
      if (result.ok) payload = result.payload;
    } catch {
      payload = fallback;
    }

    const latest = get();
    const nextConv = {
      ...latest.conversations,
      [activeJobId]: [...(latest.conversations[activeJobId] ?? thread), assistantMessage(payload)],
    };
    const nextCompleted = mergeComplete(latest.completed, activeJobId, payload.complete);
    set({
      pending: false,
      conversations: nextConv,
      completed: nextCompleted,
    });
    persist({
      activeJobId,
      conversations: nextConv,
      completed: nextCompleted,
    });
  },
}));

function jobContext(job: Job, done: string[]) {
  return {
    workOrder: job.workOrder,
    kind: job.kind,
    address: job.address,
    unit: job.unit,
    city: job.city,
    customer: job.customer,
    planDown: job.planDown,
    planUp: job.planUp,
    notes: job.notes,
    ont: job.ont,
    gateway: job.gateway,
    meshNodes: job.meshNodes,
    ssid: job.ssid,
    openSteps: job.steps.filter((step) => !done.includes(step.id)).map((step) => step.id),
  };
}

export function activeJob(): Job | undefined {
  const id = useBeaconStore.getState().activeJobId;
  return id ? jobById(id) : undefined;
}

export { JOBS };
