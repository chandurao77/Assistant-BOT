import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { AssistantPayload, MessageCard } from "./types";

const messageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
});

const jobSchema = z.object({
  workOrder: z.string(),
  kind: z.enum(["install", "mesh", "trouble"]),
  address: z.string(),
  unit: z.string().optional(),
  city: z.string(),
  customer: z.string(),
  planDown: z.number(),
  planUp: z.number(),
  notes: z.string(),
  ont: z.object({ model: z.string(), serial: z.string() }),
  gateway: z.object({ model: z.string(), serial: z.string() }),
  meshNodes: z.array(z.object({ model: z.string(), serial: z.string() })),
  ssid: z.object({
    band24: z.string(),
    band5: z.string(),
    passphrase: z.string(),
  }),
  openSteps: z.array(z.string()),
});

const inputSchema = z.object({
  messages: z.array(messageSchema).max(16),
  job: jobSchema,
});

const cardSchema: z.ZodType<MessageCard> = z.union([
  z.object({
    type: z.literal("ont"),
    model: z.string(),
    serial: z.string(),
    power: z.enum(["on", "off"]),
    pon: z.enum(["lock", "search", "off"]),
    los: z.enum(["clear", "alarm"]),
    lan: z.enum(["up", "down"]),
  }),
  z.object({
    type: z.literal("device"),
    role: z.string(),
    model: z.string(),
    serial: z.string(),
    status: z.string(),
    detail: z.string().optional(),
  }),
  z.object({
    type: z.literal("ssid"),
    band24: z.string(),
    band5: z.string(),
    passphrase: z.string(),
    steering: z.boolean(),
  }),
  z.object({
    type: z.literal("speed"),
    down: z.number(),
    up: z.number(),
    planDown: z.number(),
    planUp: z.number(),
    band: z.string(),
    location: z.string(),
  }),
  z.object({
    type: z.literal("steps"),
    title: z.string(),
    items: z.array(z.string()).max(6),
  }),
  z.object({
    type: z.literal("closeout"),
    workOrder: z.string(),
    summary: z.string(),
    checks: z.array(z.object({ label: z.string(), done: z.boolean() })).max(6),
  }),
  z.object({
    type: z.literal("warn"),
    title: z.string(),
    body: z.string(),
  }),
]);

const payloadSchema = z.object({
  text: z.string(),
  cards: z.array(cardSchema).max(3).optional(),
  quickReplies: z.array(z.string()).max(4).optional(),
  complete: z.array(z.string()).max(6).optional(),
});

const SYSTEM = `You are Beacon, a senior fiber/WiFi field trainer riding along with a technician who is activating or repairing residential WiFi.

Voice: terse, precise, no cheerleading, no emoji, no markdown. Talk like a lead tech on the truck. Short sentences. Name hardware and lights. Never invent serials, SSIDs, or speeds that contradict the job JSON.

You MUST reply with a single JSON object:
{
  "text": "2-6 sentences of field guidance",
  "cards": [optional 0-3 cards],
  "quickReplies": ["up to 4 short chip labels"],
  "complete": ["checklist step ids the tech just finished, if any"]
}

Card types (only these):
- {"type":"ont","model","serial","power":"on|off","pon":"lock|search|off","los":"clear|alarm","lan":"up|down"}
- {"type":"device","role","model","serial","status","detail"?}
- {"type":"ssid","band24","band5","passphrase","steering":true}
- {"type":"speed","down","up","planDown","planUp","band","location"}
- {"type":"steps","title","items":["..."]}
- {"type":"closeout","workOrder","summary","checks":[{"label","done"}]}
- {"type":"warn","title","body"}

Safety: LOS alarm = fiber ticket, stop. Don't swap a gateway before ONT lights are read. Don't rename SSIDs on mesh adds. Speed tests on 5 GHz. Power-cycle order is gateway off, ONT off 30s, ONT on, gateway on.`;

export const askBeacon = createServerFn({ method: "POST" })
  .validator((input: unknown) => inputSchema.parse(input))
  .handler(async ({ data }): Promise<{ ok: true; payload: AssistantPayload } | { ok: false; error: string }> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "AI is not available" };

    const job = data.job;
    const jobBlock = JSON.stringify(job);

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.3,
        max_tokens: 700,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM },
          {
            role: "system",
            content: `Current job JSON:\n${jobBlock}`,
          },
          ...data.messages.map((message) => ({
            role: message.role,
            content: message.content,
          })),
        ],
      }),
    });

    if (!res.ok) {
      return { ok: false, error: `xAI API error ${res.status}` };
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = body.choices?.[0]?.message?.content ?? "";
    try {
      const parsed = payloadSchema.parse(JSON.parse(raw));
      return { ok: true, payload: parsed };
    } catch {
      if (raw.trim()) {
        return { ok: true, payload: { text: raw.replace(/[#*_`]/g, "").trim() } };
      }
      return { ok: false, error: "Empty model response" };
    }
  });
