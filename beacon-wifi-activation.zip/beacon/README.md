# Beacon

Field WiFi activation desk for technicians. React chat UI with a job board, ONT / SSID / speed cards, and a field playbook.

## Run

```bash
npm install
npm run dev
```

Opens on port 8080.

Optional: set `XAI_API_KEY` for live Grok replies. Without it, Beacon still walks activations from the built-in playbook.

## Layout

- `src/components/beacon` — board, chat, composer, job rail, field cards
- `src/lib/chat` — jobs, playbook, store, Grok server function
- `src/styles.css` — design tokens
- `public/` — favicon and share card

Sample work orders: new install, mesh add, trouble (LOS / outage).
