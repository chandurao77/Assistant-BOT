/* global window */
// Animation timeline hook + small utility helpers.

function useTimeline({ duration = 12000, speed = 1, autoplay = true, key = 0 } = {}) {
  const [t, setT] = React.useState(0);
  const [playing, setPlaying] = React.useState(autoplay);
  const startedAtRef = React.useRef(null);
  const baseRef = React.useRef(0);
  const rafRef = React.useRef(0);

  // Reset when key changes (e.g. user hits replay).
  React.useEffect(() => {
    setT(0);
    baseRef.current = 0;
    startedAtRef.current = null;
    setPlaying(autoplay);
  }, [key, autoplay]);

  React.useEffect(() => {
    if (!playing) {
      // Snapshot accumulated time so play() resumes correctly.
      baseRef.current = t;
      startedAtRef.current = null;
      cancelAnimationFrame(rafRef.current);
      return;
    }
    const loop = (now) => {
      if (startedAtRef.current == null) startedAtRef.current = now;
      const elapsed = (now - startedAtRef.current) * speed + baseRef.current;
      if (elapsed >= duration) {
        setT(duration);
        setPlaying(false);
        return;
      }
      setT(elapsed);
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [playing, speed, duration]);

  const play = React.useCallback(() => setPlaying(true), []);
  const pause = React.useCallback(() => setPlaying(false), []);
  const seek = React.useCallback((ms) => {
    setT(Math.max(0, Math.min(duration, ms)));
    baseRef.current = ms;
    startedAtRef.current = null;
  }, [duration]);

  return { t, playing, play, pause, seek, duration };
}

// Linear progress for a streaming segment.
function streamProgress(playhead, startAt, duration) {
  if (playhead < startAt) return 0;
  if (playhead >= startAt + duration) return 1;
  return (playhead - startAt) / duration;
}

// Reveal a string proportionally given progress 0..1. We respect word boundaries
// so partial words don't blink in mid-character — better reading experience.
function streamText(full, progress) {
  if (progress >= 1) return full;
  if (progress <= 0) return '';
  const target = Math.floor(full.length * progress);
  // walk back to nearest space if we're mid-word
  let i = target;
  while (i > 0 && /\S/.test(full[i]) && /\S/.test(full[i - 1] || '')) i--;
  return full.slice(0, i);
}

Object.assign(window, { useTimeline, streamProgress, streamText });
