/* global window, React */
// PolicyPilot — Chat Hero (1440 × 880)
// 4-pane composition: conversations sidebar · chat · reasoning trace · live tree.
// Driven by a single playhead; visited set + answer reveal all share the same clock.

const HERO_TIMELINE = {
  total: 11600,
  events: {
    questionAt: 0,
    thinkingAt: 200,
    step1At: 500,
    visit_N004At: 800,
    step2At: 1200,
    visit_N004_1At: 1500,
    step3At: 1900,
    visit_N004_2At: 2200,
    step4At: 2700,
    visit_N004_3At: 3000,
    answerStart0: 3300,
    answerEnd0: 4300,
    step5At: 4500,
    visit_N007At: 4800,
    visit_N007_2At: 4900,
    answerStart1: 5100,
    answerEnd1: 7800,
    step6At: 7900,
    answerStart2: 8100,
    answerEnd2: 9500,
    citationsAt: 9700,
    metaAt: 10100,
  },
};

// Map each visited node to the timeline ms when it lights up.
const NODE_VISIT_AT = {
  'N004': HERO_TIMELINE.events.visit_N004At,
  'N004-1': HERO_TIMELINE.events.visit_N004_1At,
  'N004-2': HERO_TIMELINE.events.visit_N004_2At,
  'N004-3': HERO_TIMELINE.events.visit_N004_3At,
  'N007': HERO_TIMELINE.events.visit_N007At,
  'N007-2': HERO_TIMELINE.events.visit_N007_2At,
};

const STEP_AT = [
  HERO_TIMELINE.events.step1At,
  HERO_TIMELINE.events.step2At,
  HERO_TIMELINE.events.step3At,
  HERO_TIMELINE.events.step4At,
  HERO_TIMELINE.events.step5At,
  HERO_TIMELINE.events.step6At,
];

function ChatHero({ replayKey = 0, speed = 1, density = 'comfy' }) {
  const theme = window.useTheme();
  const { t, playing, play, pause, seek, duration } = window.useTimeline({
    duration: HERO_TIMELINE.total, speed, autoplay: true, key: replayKey,
  });

  // Compute live visited set + primary
  const visitedSet = React.useMemo(() => {
    const s = new Set();
    Object.entries(NODE_VISIT_AT).forEach(([id, at]) => { if (t >= at) s.add(id); });
    return s;
  }, [t]);
  const primaryId = t >= HERO_TIMELINE.events.visit_N004_3At ? 'N004-3' : null;
  const focusOrder = React.useMemo(() => {
    const m = {};
    if (t >= HERO_TIMELINE.events.visit_N004At) m['N004'] = 1;
    if (t >= HERO_TIMELINE.events.visit_N004_1At) m['N004-1'] = 2;
    if (t >= HERO_TIMELINE.events.visit_N004_2At) m['N004-2'] = 3;
    if (t >= HERO_TIMELINE.events.visit_N004_3At) m['N004-3'] = 4;
    if (t >= HERO_TIMELINE.events.visit_N007_2At) m['N007-2'] = 5;
    return m;
  }, [t]);

  // Stream answer paragraphs
  const para0Progress = window.streamProgress(t, HERO_TIMELINE.events.answerStart0, HERO_TIMELINE.events.answerEnd0 - HERO_TIMELINE.events.answerStart0);
  const para1Progress = window.streamProgress(t, HERO_TIMELINE.events.answerStart1, HERO_TIMELINE.events.answerEnd1 - HERO_TIMELINE.events.answerStart1);
  const para2Progress = window.streamProgress(t, HERO_TIMELINE.events.answerStart2, HERO_TIMELINE.events.answerEnd2 - HERO_TIMELINE.events.answerStart2);
  const citationsVisible = t >= HERO_TIMELINE.events.citationsAt;
  const metaVisible = t >= HERO_TIMELINE.events.metaAt;
  const showThinking = t >= HERO_TIMELINE.events.thinkingAt && para2Progress < 1;

  const stepsRevealed = STEP_AT.map((at, i) => t >= at);

  // Auto-scroll the chat area so the latest content stays in view
  const chatScrollRef = React.useRef(null);
  React.useEffect(() => {
    const el = chatScrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [t, para0Progress, para1Progress, para2Progress, citationsVisible, metaVisible]);

  const reasoningScrollRef = React.useRef(null);
  React.useEffect(() => {
    const el = reasoningScrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [t]);

  return (
    <div style={{
      width: 1440, height: 880,
      background: theme.decor.chatBg,
      color: theme.color.text,
      fontFamily: theme.font.sans,
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <HeroTopBar onReplay={() => seek(0) || play()} playing={playing} onPlayPause={() => playing ? pause() : play()} t={t} duration={duration} />
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <ConversationsSidebar />
        <ChatPane
          chatScrollRef={chatScrollRef}
          showThinking={showThinking}
          para0Progress={para0Progress}
          para1Progress={para1Progress}
          para2Progress={para2Progress}
          citationsVisible={citationsVisible}
          metaVisible={metaVisible}
        />
        <ReasoningPane reasoningScrollRef={reasoningScrollRef} stepsRevealed={stepsRevealed} />
        <TreePane visitedSet={visitedSet} primaryId={primaryId} focusOrder={focusOrder} />
      </div>
    </div>
  );
}

// ─── Top bar ─────────────────────────────────────────────────────────────────

function HeroTopBar({ onReplay, playing, onPlayPause, t, duration }) {
  const theme = window.useTheme();
  return (
    <div style={{
      height: 56, flex: '0 0 56px',
      display: 'flex', alignItems: 'center', gap: 16,
      padding: '0 20px',
      background: theme.color.surface,
      borderBottom: `1px solid ${theme.color.line}`,
    }}>
      <Logo />
      <div style={{
        width: 1, height: 22, background: theme.color.line, margin: '0 4px',
      }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: theme.color.muted, fontSize: 13 }}>
        <span>Workspaces</span>
        <Chevron />
        <span>Mesh Architecture</span>
        <Chevron />
        <span style={{ color: theme.color.ink, fontWeight: 500 }}>Auth proxy degraded refresh</span>
      </div>
      <div style={{ flex: 1 }} />
      {/* Timeline scrub */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onReplay} style={iconBtn(theme)} title="Replay">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>
        </button>
        <button onClick={onPlayPause} style={iconBtn(theme)} title={playing ? 'Pause' : 'Play'}>
          {playing
            ? <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>
            : <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="6,4 20,12 6,20"/></svg>}
        </button>
        <div style={{
          width: 140, height: 4, background: theme.color.surfaceSunk,
          borderRadius: 999, overflow: 'hidden', position: 'relative',
        }}>
          <div style={{
            width: `${(t / duration) * 100}%`, height: '100%',
            background: theme.color.accent, transition: 'width 80ms linear',
          }} />
        </div>
      </div>
      <div style={{ width: 1, height: 22, background: theme.color.line, margin: '0 8px' }} />
      <LayoutToggle active="chat" />
      <UserAvatar />
    </div>
  );
}

function iconBtn(theme) {
  return {
    width: 28, height: 28,
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    background: 'transparent', color: theme.color.muted,
    border: `1px solid ${theme.color.line}`,
    borderRadius: theme.radius.sm, cursor: 'pointer',
  };
}

function Chevron() {
  const theme = window.useTheme();
  return <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={theme.color.subtle} strokeWidth="2"><polyline points="9 6 15 12 9 18"/></svg>;
}

function Logo({ size = 'md' }) {
  const theme = window.useTheme();
  const dim = size === 'lg' ? 32 : 24;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: dim, height: dim, borderRadius: theme.radius.sm,
        background: `linear-gradient(135deg, ${theme.color.accent} 0%, ${theme.color.accentDeep} 100%)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: theme.color.accentInk, fontFamily: theme.font.mono, fontWeight: 700,
        fontSize: dim * 0.42, letterSpacing: '-0.04em',
        boxShadow: `0 0 0 1px ${theme.color.accentDeep}30, 0 6px 16px -8px ${theme.color.glow}`,
      }}>
        {/* tree-leaf glyph */}
        <svg width={dim * 0.6} height={dim * 0.6} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
          <circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/>
          <path d="M6 8v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8"/><path d="M12 14v2"/>
        </svg>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <span style={{
          fontFamily: theme.decor.headerSerif ? theme.font.serif : theme.font.sans,
          fontWeight: 600, fontSize: 15, color: theme.color.ink, letterSpacing: '-0.01em',
        }}>PolicyPilot</span>
        <span style={{ fontFamily: theme.font.mono, fontSize: 9.5, color: theme.color.muted, marginTop: 2, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          Vectorless RAG
        </span>
      </div>
    </div>
  );
}

function LayoutToggle({ active }) {
  const theme = window.useTheme();
  const btn = (id, icon) => (
    <button style={{
      width: 32, height: 28, padding: 0,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      background: active === id ? theme.color.surface : 'transparent',
      color: active === id ? theme.color.ink : theme.color.muted,
      border: 'none', borderRadius: theme.radius.sm - 1,
      boxShadow: active === id ? theme.shadow.sm : 'none',
      cursor: 'pointer',
    }}>{icon}</button>
  );
  return (
    <div style={{
      display: 'inline-flex', padding: 3, gap: 2,
      background: theme.color.surfaceSunk, borderRadius: theme.radius.sm,
    }}>
      {btn('chat',
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      )}
      {btn('dash',
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      )}
    </div>
  );
}

function UserAvatar() {
  const theme = window.useTheme();
  return (
    <div style={{
      width: 30, height: 30, borderRadius: 999,
      background: theme.color.accentSoft, color: theme.color.accent,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: theme.font.sans, fontWeight: 600, fontSize: 12,
      border: `1px solid ${theme.color.line}`,
    }}>AK</div>
  );
}

// ─── Sidebar (conversations) ─────────────────────────────────────────────────

function ConversationsSidebar() {
  const theme = window.useTheme();
  return (
    <aside style={{
      width: 240, flex: '0 0 240px',
      background: theme.decor.sidebarBg,
      borderRight: `1px solid ${theme.color.line}`,
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <div style={{ padding: 14 }}>
        <button style={{
          width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          padding: '9px 12px',
          background: theme.color.accent, color: theme.color.accentInk,
          border: 'none', borderRadius: theme.radius.md,
          fontFamily: theme.font.sans, fontSize: 13, fontWeight: 600,
          cursor: 'pointer',
          boxShadow: `0 0 0 1px ${theme.color.accentDeep}20, 0 6px 16px -8px ${theme.color.glow}`,
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          New conversation
        </button>
      </div>
      <div style={{ padding: '0 14px 6px', fontFamily: theme.font.mono, fontSize: 10, color: theme.color.subtle, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        Documents in context
      </div>
      <div style={{ padding: '0 10px 14px' }}>
        <DocChip name="Xfinity Stream Mesh v3.2" active />
      </div>
      <div style={{ padding: '0 14px 6px', fontFamily: theme.font.mono, fontSize: 10, color: theme.color.subtle, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        Recent
      </div>
      <div style={{ padding: '0 8px 12px', display: 'flex', flexDirection: 'column', gap: 2, overflow: 'hidden' }}>
        {window.DEMO_CONVERSATIONS.map((c) => (
          <button key={c.id} style={{
            display: 'flex', flexDirection: 'column', gap: 3,
            padding: '8px 10px', textAlign: 'left',
            background: c.active ? theme.color.surface : 'transparent',
            border: 'none', borderRadius: theme.radius.sm,
            color: c.active ? theme.color.ink : theme.color.text,
            cursor: 'pointer',
            boxShadow: c.active ? `0 0 0 1px ${theme.color.line}` : 'none',
          }}>
            <span style={{ fontSize: 12.5, fontWeight: c.active ? 600 : 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {c.title}
            </span>
            <span style={{ fontSize: 11, color: theme.color.muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontFamily: theme.font.mono }}>
              {c.doc} · {c.when}
            </span>
          </button>
        ))}
      </div>
    </aside>
  );
}

function DocChip({ name, active }) {
  const theme = window.useTheme();
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '7px 10px',
      background: active ? theme.color.accentSoft : 'transparent',
      borderRadius: theme.radius.sm,
      border: `1px solid ${active ? theme.color.accent + '40' : theme.color.line}`,
    }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={active ? theme.color.accent : theme.color.muted} strokeWidth="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
      </svg>
      <span style={{ fontSize: 12, color: active ? theme.color.ink : theme.color.text, fontWeight: 500, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
      <span style={{ fontFamily: theme.font.mono, fontSize: 9.5, color: theme.color.muted, padding: '2px 5px', background: theme.color.surface, borderRadius: 3, border: `1px solid ${theme.color.line}` }}>38n</span>
    </div>
  );
}

Object.assign(window, { ChatHero, HERO_TIMELINE, Logo, LayoutToggle, UserAvatar, Chevron, iconBtn });
