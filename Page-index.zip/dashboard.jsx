/* global window, React */
// PolicyPilot — Dashboard / File Manager artboard (1280 × 800)

function Dashboard() {
  const theme = window.useTheme();
  const docs = window.DEMO_DOCS;
  const total = docs.length;
  const ready = docs.filter((d) => d.status === 'ready').length;
  const processing = docs.filter((d) => d.status === 'processing').length;
  const error = docs.filter((d) => d.status === 'error').length;
  const totalNodes = docs.reduce((a, d) => a + (d.nodeCount || 0), 0);

  return (
    <div style={{
      width: 1280, height: 800,
      background: theme.color.bg, color: theme.color.text,
      fontFamily: theme.font.sans,
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <window.HeroTopBar onReplay={() => {}} playing={false} onPlayPause={() => {}} t={0} duration={1} />
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* Light sidebar */}
        <DashSidebar />
        <main style={{ flex: 1, overflow: 'auto', padding: '24px 28px 32px' }}>
          {/* Title row */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, marginBottom: 22 }}>
            <div>
              <h1 style={{
                margin: 0, fontSize: 24, fontWeight: 600,
                fontFamily: theme.decor.headerSerif ? theme.font.serif : theme.font.sans,
                color: theme.color.ink, letterSpacing: '-0.015em', lineHeight: 1.1,
              }}>Documents</h1>
              <p style={{ margin: '6px 0 0', fontSize: 13, color: theme.color.muted, lineHeight: 1.5 }}>
                Trees built and cached. Query any document or combination — PageIndex reasons over structure, never embeddings.
              </p>
            </div>
            <div style={{ flex: 1 }} />
            <SearchBar />
            <SortButton />
          </div>

          {/* Stats row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 22 }}>
            <StatTile label="Documents" value={total} hint={`${ready} ready`} accent={theme.color.ink} />
            <StatTile label="Tree nodes" value={totalNodes.toLocaleString()} hint="cached in Redis" accent={theme.color.ink} />
            <StatTile label="Processing" value={processing} hint={processing ? 'building tree…' : 'none'} accent={processing ? theme.color.warn : theme.color.muted} dotPulse={processing > 0} />
            <StatTile label="Errors" value={error} hint={error ? 'needs OCR' : 'none'} accent={error ? theme.color.err : theme.color.muted} />
          </div>

          {/* Upload zone */}
          <UploadZone />

          {/* List header */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 110px 110px 130px 130px 120px 32px',
            gap: 12,
            padding: '14px 16px',
            fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.subtle,
            textTransform: 'uppercase', letterSpacing: '0.08em',
            borderBottom: `1px solid ${theme.color.line}`,
            marginTop: 18,
          }}>
            <span>Document</span><span>Type</span><span>Size</span><span>Nodes</span><span>Status</span><span>Uploaded</span><span></span>
          </div>

          {/* Document rows */}
          <div>
            {docs.map((d) => <DocumentRow key={d.id} doc={d} />)}
          </div>
        </main>
      </div>
    </div>
  );
}

function DashSidebar() {
  const theme = window.useTheme();
  const items = [
    { label: 'Documents', icon: 'doc', active: true, count: 6 },
    { label: 'Conversations', icon: 'chat', count: 24 },
    { label: 'Tree explorer', icon: 'tree' },
    { label: 'Search history', icon: 'clock' },
  ];
  return (
    <aside style={{
      width: 220, flex: '0 0 220px',
      background: theme.decor.sidebarBg,
      borderRight: `1px solid ${theme.color.line}`,
      padding: '20px 12px',
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{
        padding: '4px 10px 14px', fontFamily: theme.font.mono, fontSize: 10,
        color: theme.color.subtle, letterSpacing: '0.08em', textTransform: 'uppercase',
      }}>Workspace</div>
      {items.map((it) => (
        <button key={it.label} style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '8px 10px',
          background: it.active ? theme.color.surface : 'transparent',
          color: it.active ? theme.color.ink : theme.color.text,
          border: 'none',
          borderRadius: theme.radius.sm,
          fontFamily: theme.font.sans, fontSize: 13,
          fontWeight: it.active ? 600 : 500,
          cursor: 'pointer', textAlign: 'left',
          boxShadow: it.active ? `0 0 0 1px ${theme.color.line}` : 'none',
        }}>
          <SidebarIcon kind={it.icon} active={it.active} />
          <span style={{ flex: 1 }}>{it.label}</span>
          {it.count != null && (
            <span style={{ fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.muted, padding: '1px 6px', background: theme.color.surfaceSunk, borderRadius: 3 }}>{it.count}</span>
          )}
        </button>
      ))}
      <div style={{ flex: 1 }} />
      <div style={{
        padding: 12,
        background: theme.color.surface,
        borderRadius: theme.radius.md,
        border: `1px solid ${theme.color.line}`,
        boxShadow: theme.shadow.sm,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 999, background: theme.color.ok }} />
          <span style={{ fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.muted, letterSpacing: '0.04em', textTransform: 'uppercase' }}>LLM</span>
        </div>
        <div style={{ fontSize: 12.5, color: theme.color.ink, fontWeight: 600 }}>gpt-5-mini</div>
        <div style={{ fontSize: 11, color: theme.color.muted, marginTop: 2, fontFamily: theme.font.mono }}>FlowContext · 24ms p50</div>
      </div>
    </aside>
  );
}

function SidebarIcon({ kind, active }) {
  const theme = window.useTheme();
  const stroke = active ? theme.color.accent : theme.color.muted;
  const props = { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none', stroke, strokeWidth: 2 };
  if (kind === 'doc') return <svg {...props}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>;
  if (kind === 'chat') return <svg {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
  if (kind === 'tree') return <svg {...props}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M6 8v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8"/><path d="M12 14v2"/></svg>;
  if (kind === 'clock') return <svg {...props}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>;
  return null;
}

function SearchBar() {
  const theme = window.useTheme();
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '7px 12px',
      background: theme.color.surface,
      border: `1px solid ${theme.color.line}`,
      borderRadius: theme.radius.md,
      width: 240,
      boxShadow: theme.shadow.sm,
    }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={theme.color.muted} strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <span style={{ fontSize: 13, color: theme.color.subtle, flex: 1 }}>Search by name…</span>
      <span style={{ fontFamily: theme.font.mono, fontSize: 10, padding: '1px 5px', background: theme.color.surfaceSunk, borderRadius: 3, color: theme.color.muted, border: `1px solid ${theme.color.line}` }}>⌘K</span>
    </div>
  );
}

function SortButton() {
  const theme = window.useTheme();
  return (
    <button style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '7px 12px',
      background: theme.color.surface,
      border: `1px solid ${theme.color.line}`,
      borderRadius: theme.radius.md,
      color: theme.color.text, fontSize: 12.5, fontFamily: theme.font.sans,
      cursor: 'pointer', boxShadow: theme.shadow.sm,
    }}>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="6" y1="8" x2="20" y2="8"/><line x1="6" y1="12" x2="14" y2="12"/><line x1="6" y1="16" x2="10" y2="16"/></svg>
      Sort · Recent
    </button>
  );
}

function StatTile({ label, value, hint, accent, dotPulse }) {
  const theme = window.useTheme();
  return (
    <div style={{
      padding: '14px 16px',
      background: theme.color.surface,
      border: `1px solid ${theme.color.line}`,
      borderRadius: theme.radius.md,
      boxShadow: theme.shadow.sm,
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ fontFamily: theme.font.mono, fontSize: 10, color: theme.color.subtle, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</span>
        {dotPulse && (
          <>
            <span style={{ width: 6, height: 6, borderRadius: 999, background: theme.color.warn, animation: 'pp-pulse2 1.3s infinite' }} />
            <style>{`@keyframes pp-pulse2 { 0%,100%{opacity:.3} 50%{opacity:1} }`}</style>
          </>
        )}
      </div>
      <div style={{ fontSize: 26, fontWeight: 600, color: accent || theme.color.ink, fontFamily: theme.decor.headerSerif ? theme.font.serif : theme.font.sans, letterSpacing: '-0.01em', lineHeight: 1.1 }}>{value}</div>
      <div style={{ fontSize: 11.5, color: theme.color.muted, fontFamily: theme.font.mono }}>{hint}</div>
    </div>
  );
}

function UploadZone() {
  const theme = window.useTheme();
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 16,
      padding: '18px 20px',
      background: theme.color.surface,
      border: `1.5px dashed ${theme.color.accent}55`,
      borderRadius: theme.radius.lg,
      boxShadow: theme.shadow.sm,
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: theme.radius.md,
        background: theme.color.accentSoft, color: theme.color.accent,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        flex: '0 0 44px',
      }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
        </svg>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: theme.color.ink, marginBottom: 3 }}>
          Drop a PDF, DOCX or Markdown file to build a tree
        </div>
        <div style={{ fontSize: 12, color: theme.color.muted, lineHeight: 1.5 }}>
          Up to 50 MB · tree built in 30–90s · cached for 24h. No embeddings, no chunking — PageIndex preserves your document's structure.
        </div>
      </div>
      <button style={{
        padding: '8px 14px',
        background: theme.color.accent, color: theme.color.accentInk,
        border: 'none', borderRadius: theme.radius.md,
        fontSize: 13, fontWeight: 600, fontFamily: theme.font.sans,
        cursor: 'pointer',
        boxShadow: `0 6px 16px -8px ${theme.color.glow}`,
      }}>Choose file</button>
    </div>
  );
}

function DocumentRow({ doc }) {
  const theme = window.useTheme();
  const typeColor = {
    PDF: { fg: theme.color.err, bg: theme.color.errSoft },
    DOCX: { fg: '#2A6FDB', bg: 'rgba(42,111,219,0.12)' },
    MD: { fg: theme.color.ok, bg: theme.color.okSoft },
  }[doc.fileType] || { fg: theme.color.muted, bg: theme.color.surfaceSunk };
  const isActive = doc.id === 'doc_x_stream_mesh';

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '1fr 110px 110px 130px 130px 120px 32px',
      gap: 12, alignItems: 'center',
      padding: '14px 16px',
      borderBottom: `1px solid ${theme.color.lineSoft}`,
      background: isActive ? theme.color.accentSoft + '40' : 'transparent',
      borderRadius: theme.radius.sm,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
        <div style={{
          width: 32, height: 36, flex: '0 0 32px',
          borderRadius: 4,
          background: typeColor.bg, color: typeColor.fg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: theme.font.mono, fontWeight: 700, fontSize: 9.5,
          border: `1px solid ${theme.color.line}`,
        }}>{doc.fileType}</div>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, color: theme.color.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {doc.filename}
          </div>
          <div style={{ fontSize: 11, color: theme.color.muted, fontFamily: theme.font.mono, marginTop: 2 }}>
            {doc.id} {isActive ? '· in current chat' : ''}
          </div>
        </div>
      </div>
      <span style={{ fontFamily: theme.font.mono, fontSize: 11, color: theme.color.text }}>{doc.fileType}</span>
      <span style={{ fontFamily: theme.font.mono, fontSize: 11, color: theme.color.text }}>{doc.fileSize}</span>
      <span style={{ fontFamily: theme.font.mono, fontSize: 11, color: theme.color.text }}>
        {doc.nodeCount > 0 ? `${doc.nodeCount} · ${doc.pageCount}p` : '—'}
      </span>
      <StatusBadge doc={doc} />
      <span style={{ fontSize: 11.5, color: theme.color.muted, fontFamily: theme.font.mono }}>{doc.uploadedAt}</span>
      <button style={{
        width: 28, height: 28, padding: 0,
        background: 'transparent', color: theme.color.muted,
        border: 'none', borderRadius: theme.radius.sm,
        cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>
      </button>
    </div>
  );
}

function StatusBadge({ doc }) {
  const theme = window.useTheme();
  if (doc.status === 'ready') {
    return (
      <span style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '3px 8px',
        background: theme.color.okSoft, color: theme.color.ok,
        borderRadius: 999, fontSize: 11, fontFamily: theme.font.mono, fontWeight: 600,
        border: `1px solid ${theme.color.ok}30`, width: 'fit-content',
      }}>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
        Ready
      </span>
    );
  }
  if (doc.status === 'processing') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, width: 'fit-content', minWidth: 100 }}>
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '3px 8px',
          background: theme.color.warnSoft, color: theme.color.warn,
          borderRadius: 999, fontSize: 11, fontFamily: theme.font.mono, fontWeight: 600,
          border: `1px solid ${theme.color.warn}40`, width: 'fit-content',
        }}>
          <span style={{
            width: 8, height: 8, border: `1.4px solid currentColor`, borderTopColor: 'transparent',
            borderRadius: 999, animation: 'pp-spin 0.9s linear infinite',
          }} />
          <style>{`@keyframes pp-spin { to { transform: rotate(360deg); } }`}</style>
          Processing
        </span>
        <div style={{ width: 110, height: 3, background: theme.color.surfaceSunk, borderRadius: 999 }}>
          <div style={{ width: `${(doc.progress || 0) * 100}%`, height: '100%', background: theme.color.warn, borderRadius: 999 }} />
        </div>
      </div>
    );
  }
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '3px 8px',
      background: theme.color.errSoft, color: theme.color.err,
      borderRadius: 999, fontSize: 11, fontFamily: theme.font.mono, fontWeight: 600,
      border: `1px solid ${theme.color.err}40`, width: 'fit-content',
    }}>
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      Error
    </span>
  );
}

Object.assign(window, { Dashboard });
