/* global window, React */
// Hierarchical tree viewer for PageIndex document trees.
// Props:
//   tree: flat node list from demo-data
//   visitedSet: Set of node ids currently "visited" (highlighted)
//   primaryId: node id to mark as primary (extra glow)
//   focusOrder: optional map nodeId -> step number to show as badge
//   compact: true reduces padding/font for narrow panels
//   onNodeClick: optional click handler

function buildTreeIndex(flat) {
  const byId = {};
  const children = {};
  flat.forEach((n) => { byId[n.id] = n; children[n.id] = []; });
  flat.forEach((n) => { if (n.parentId && children[n.parentId]) children[n.parentId].push(n.id); });
  const roots = flat.filter((n) => !n.parentId).map((n) => n.id);
  return { byId, children, roots };
}

function TreeViewer({
  tree,
  visitedSet = new Set(),
  primaryId = null,
  focusOrder = {},
  compact = false,
  onNodeClick,
  initialExpanded = null,
}) {
  const theme = window.useTheme();
  const { byId, children, roots } = React.useMemo(() => buildTreeIndex(tree), [tree]);

  // Default expanded: any branch with visited descendants is expanded; otherwise root only.
  const computeDefault = React.useCallback(() => {
    const ex = new Set();
    const hasVisitedDescendant = (id) => {
      if (visitedSet.has(id)) return true;
      return (children[id] || []).some(hasVisitedDescendant);
    };
    Object.keys(byId).forEach((id) => {
      if ((children[id] || []).length && hasVisitedDescendant(id)) ex.add(id);
    });
    return ex;
  }, [byId, children, visitedSet]);

  const [expanded, setExpanded] = React.useState(() => initialExpanded || computeDefault());

  // Auto-open ancestors when visitedSet changes so newly-visited nodes are visible.
  React.useEffect(() => {
    setExpanded((prev) => {
      const next = new Set(prev);
      let changed = false;
      visitedSet.forEach((nid) => {
        let cur = byId[nid];
        while (cur && cur.parentId) {
          if (!next.has(cur.parentId)) { next.add(cur.parentId); changed = true; }
          cur = byId[cur.parentId];
        }
      });
      return changed ? next : prev;
    });
  }, [visitedSet, byId]);

  const toggle = (id) => setExpanded((prev) => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const rowPadV = compact ? 5 : 8;
  const fontSize = compact ? 12 : 13;
  const summarySize = compact ? 10.5 : 11.5;
  const indentPx = compact ? 14 : 18;

  const renderNode = (id, depth) => {
    const n = byId[id];
    if (!n) return null;
    const kids = children[id] || [];
    const isOpen = expanded.has(id);
    const isVisited = visitedSet.has(id);
    const isPrimary = primaryId === id;
    const step = focusOrder[id];

    const bg = isPrimary
      ? theme.color.accent
      : isVisited ? theme.color.visitedFill : 'transparent';
    const fg = isPrimary
      ? theme.color.accentInk
      : isVisited ? theme.color.ink : theme.color.text;
    const ring = isPrimary
      ? `0 0 0 1px ${theme.color.accent}, 0 0 24px -2px ${theme.color.glow}`
      : isVisited ? `0 0 0 1px ${theme.color.accent}40` : 'none';

    return (
      <div key={id}>
        <button
          onClick={() => { if (kids.length) toggle(id); onNodeClick && onNodeClick(n); }}
          style={{
            width: '100%', textAlign: 'left',
            display: 'flex', gap: 8, alignItems: 'flex-start',
            padding: `${rowPadV}px 10px ${rowPadV}px ${10 + depth * indentPx}px`,
            background: bg,
            color: fg,
            border: 'none', cursor: kids.length ? 'pointer' : 'default',
            borderRadius: theme.radius.sm,
            boxShadow: ring,
            fontFamily: theme.font.sans,
            transition: 'background 240ms ease, box-shadow 240ms ease, color 240ms ease',
            marginBottom: 1,
          }}
        >
          {/* Disclosure caret */}
          <span style={{
            width: 12, flex: '0 0 12px',
            color: isPrimary ? theme.color.accentInk : theme.color.muted,
            fontFamily: theme.font.mono,
            fontSize: fontSize - 2,
            transform: kids.length ? (isOpen ? 'rotate(90deg)' : 'rotate(0deg)') : 'none',
            transition: 'transform 160ms ease',
            opacity: kids.length ? 1 : 0,
            marginTop: 2,
          }}>›</span>
          <span style={{ flex: 1, minWidth: 0 }}>
            <span style={{
              display: 'flex', alignItems: 'center', gap: 8,
              fontSize, fontWeight: depth === 0 ? 600 : 500,
              lineHeight: 1.3,
            }}>
              <span style={{
                fontFamily: theme.font.mono, fontSize: fontSize - 2,
                color: isPrimary ? theme.color.accentInk : (isVisited ? theme.color.accent : theme.color.subtle),
                letterSpacing: '0.02em',
                flex: '0 0 auto',
              }}>{n.id}</span>
              <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {n.title}
              </span>
              {step != null && (
                <span style={{
                  fontFamily: theme.font.mono, fontSize: 10,
                  padding: '1px 5px', borderRadius: 999,
                  background: isPrimary ? 'rgba(255,255,255,0.2)' : theme.color.accent,
                  color: isPrimary ? theme.color.accentInk : theme.color.accentInk,
                  fontWeight: 600,
                  flex: '0 0 auto',
                }}>{step}</span>
              )}
              <span style={{
                fontFamily: theme.font.mono, fontSize: fontSize - 3,
                color: isPrimary ? 'rgba(255,255,255,0.75)' : theme.color.subtle,
                flex: '0 0 auto', whiteSpace: 'nowrap',
              }}>p.{n.pages}</span>
            </span>
            {!compact && isVisited && n.summary && (
              <span style={{
                display: 'block', marginTop: 3,
                fontSize: summarySize, lineHeight: 1.45,
                color: isPrimary ? 'rgba(255,255,255,0.85)' : theme.color.muted,
                fontFamily: theme.font.sans,
              }}>{n.summary}</span>
            )}
          </span>
        </button>
        {isOpen && kids.map((cid) => renderNode(cid, depth + 1))}
      </div>
    );
  };

  return (
    <div style={{ fontFamily: theme.font.sans }}>
      {roots.map((rid) => renderNode(rid, 0))}
    </div>
  );
}

Object.assign(window, { TreeViewer });
