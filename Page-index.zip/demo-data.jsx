/* global window */
// Demo content for the PolicyPilot prototype.
// Document: a Comcast-flavored technical spec. Tree mirrors PageIndex output shape.

const DEMO_DOC = {
  id: 'doc_x_stream_mesh',
  filename: 'Xfinity Stream — Service Mesh Architecture v3.2.pdf',
  shortName: 'Xfinity Stream Mesh v3.2',
  fileType: 'PDF',
  fileSize: '4.8 MB',
  pageCount: 142,
  nodeCount: 38,
  uploadedAt: '2 days ago',
  status: 'ready',
};

const DEMO_DOCS = [
  DEMO_DOC,
  {
    id: 'doc_idp_runbook',
    filename: 'Identity Platform — Production Runbook.docx',
    shortName: 'IDP Runbook',
    fileType: 'DOCX',
    fileSize: '1.2 MB',
    pageCount: 48,
    nodeCount: 17,
    uploadedAt: '2 days ago',
    status: 'ready',
  },
  {
    id: 'doc_sre_oncall',
    filename: 'SRE On-Call Handbook 2026.md',
    shortName: 'SRE Handbook',
    fileType: 'MD',
    fileSize: '186 KB',
    pageCount: 22,
    nodeCount: 11,
    uploadedAt: '5 days ago',
    status: 'ready',
  },
  {
    id: 'doc_payment_compliance',
    filename: 'Payment Processing — Compliance & PCI Notes.pdf',
    shortName: 'Payment Compliance',
    fileType: 'PDF',
    fileSize: '7.1 MB',
    pageCount: 88,
    nodeCount: 24,
    uploadedAt: '1 week ago',
    status: 'ready',
  },
  {
    id: 'doc_data_retention',
    filename: 'Data Retention Policy v4.docx',
    shortName: 'Data Retention v4',
    fileType: 'DOCX',
    fileSize: '480 KB',
    pageCount: 19,
    nodeCount: 9,
    uploadedAt: '12 min ago',
    status: 'processing',
    progress: 0.62,
    progressLabel: 'Building tree · 16/38 nodes',
  },
  {
    id: 'doc_legacy_export',
    filename: 'Legacy CRM Export Schema.pdf',
    shortName: 'Legacy CRM Export',
    fileType: 'PDF',
    fileSize: '12.3 MB',
    pageCount: 0,
    nodeCount: 0,
    uploadedAt: '3 hours ago',
    status: 'error',
    errorLabel: 'PDF appears to be scanned — OCR required',
  },
];

// The hierarchical tree for the main demo doc.
// Flat array; each node has parentId. Tree component composes from this.
const DEMO_TREE = [
  { id: 'N001', title: 'Front Matter', pages: '1–4', summary: 'Cover, contributors, revision history, glossary.', level: 0 },
  { id: 'N002', title: '1. Executive Summary', pages: '5–9', summary: 'Goals, non-goals, SLO targets and rollout phases.', level: 0 },
  { id: 'N003', title: '2. System Overview', pages: '10–28', summary: 'Topology, components and deployment model for the mesh.', level: 0 },
  { id: 'N003-1', parentId: 'N003', title: '2.1 Service Topology', pages: '10–15', summary: 'East-west service graph and trust zones.', level: 1 },
  { id: 'N003-2', parentId: 'N003', title: '2.2 Component Inventory', pages: '16–22', summary: 'Sidecars, control plane, IDP, brokers.', level: 1 },
  { id: 'N003-3', parentId: 'N003', title: '2.3 Deployment Model', pages: '23–28', summary: 'Region/cell layout and bin-packing rules.', level: 1 },
  { id: 'N004', title: '3. Authentication & Authorization', pages: '29–58', summary: 'Token contracts, proxy behavior and degraded paths.', level: 0, visited: true, visitOrder: 1 },
  { id: 'N004-1', parentId: 'N004', title: '3.1 Token Lifecycle', pages: '29–37', summary: 'Issuance, refresh contract, JWKS rotation cadence.', level: 1, visited: true, visitOrder: 2 },
  { id: 'N004-2', parentId: 'N004', title: '3.2 Auth Proxy Behavior', pages: '38–46', summary: 'Refresh handoff, header normalization, retry budget.', level: 1, visited: true, visitOrder: 3 },
  { id: 'N004-3', parentId: 'N004', title: '3.3 Degraded-Mode Handling', pages: '47–53', summary: 'Cached refresh, shadow refresh, read-only degradation.', level: 1, visited: true, visitOrder: 4, primary: true },
  { id: 'N004-4', parentId: 'N004', title: '3.4 Service-to-Service mTLS', pages: '54–58', summary: 'Cert rotation and SPIFFE identity binding.', level: 1 },
  { id: 'N005', title: '4. Data Plane', pages: '59–92', summary: 'Ingress, sidecar proxy, egress controls.', level: 0 },
  { id: 'N005-1', parentId: 'N005', title: '4.1 Ingress', pages: '59–71', summary: 'Edge termination, WAF integration.', level: 1 },
  { id: 'N005-2', parentId: 'N005', title: '4.2 Sidecar Proxy', pages: '72–83', summary: 'Envoy config, filter chain, hot-restart.', level: 1 },
  { id: 'N005-3', parentId: 'N005', title: '4.3 Egress Controls', pages: '84–92', summary: 'Allowlists, third-party connector boundaries.', level: 1 },
  { id: 'N006', title: '5. Observability', pages: '93–118', summary: 'Tracing, metrics cardinality, log aggregation.', level: 0 },
  { id: 'N006-1', parentId: 'N006', title: '5.1 Distributed Tracing', pages: '93–104', summary: 'Span schema and sampling rules.', level: 1 },
  { id: 'N006-2', parentId: 'N006', title: '5.2 Metrics & SLOs', pages: '105–118', summary: 'SLO catalog and burn-rate alerts.', level: 1 },
  { id: 'N007', title: '6. Failure Modes', pages: '119–138', summary: 'Cascading failures, outage playbooks, recovery.', level: 0, visited: true, visitOrder: 5 },
  { id: 'N007-1', parentId: 'N007', title: '6.1 Cascading Failures', pages: '119–125', summary: 'Bulkhead patterns and circuit breaker tuning.', level: 1 },
  { id: 'N007-2', parentId: 'N007', title: '6.2 Auth Service Outage', pages: '126–132', summary: 'Recovery playbook for upstream IDP outages.', level: 1, visited: true, visitOrder: 6 },
  { id: 'N007-3', parentId: 'N007', title: '6.3 Recovery Procedures', pages: '133–138', summary: 'Step-by-step warm-start procedure.', level: 1 },
  { id: 'N008', title: 'Appendix A — Glossary', pages: '139–142', summary: 'Terms and acronyms used throughout.', level: 0 },
];

const DEMO_QUESTION = 'How does the auth proxy refresh tokens when the upstream identity service is degraded?';

// Reasoning trace — each step shows what PageIndex did, with a visible delay.
const DEMO_TRACE = [
  {
    n: 1,
    kind: 'plan',
    title: 'Read tree index',
    body: 'Scanning top-level chapter summaries. Keys in question: "auth proxy", "token refresh", "degraded upstream". §3 Authentication & Authorization is the strongest candidate.',
    nodes: ['N004'],
  },
  {
    n: 2,
    kind: 'fetch',
    title: 'Fetch §3.1 Token Lifecycle',
    body: 'Reading the refresh contract — TTLs, JWKS rotation, refresh-token reuse rules. Establishes baseline behavior.',
    nodes: ['N004-1'],
    pages: 'p.29–37',
  },
  {
    n: 3,
    kind: 'fetch',
    title: 'Fetch §3.2 Auth Proxy Behavior',
    body: 'Refresh handoff between the proxy and IDP lives here. Tells us how the proxy decides to refresh.',
    nodes: ['N004-2'],
    pages: 'p.38–46',
  },
  {
    n: 4,
    kind: 'fetch',
    title: 'Fetch §3.3 Degraded-Mode Handling',
    body: 'Primary answer source — explicit three-stage fallback when upstream IDP is unhealthy.',
    nodes: ['N004-3'],
    pages: 'p.47–53',
    primary: true,
  },
  {
    n: 5,
    kind: 'crossref',
    title: 'Cross-reference to §6.2',
    body: '§3.3 references the auth-outage playbook in §6.2 for the recovery contract. Following the pointer.',
    nodes: ['N007', 'N007-2'],
    pages: 'p.126–132',
  },
  {
    n: 6,
    kind: 'compose',
    title: 'Compose answer',
    body: 'Assembling answer from 4 nodes spanning 18 pages. Reasoning loop converged in 5 hops — within budget.',
    nodes: [],
  },
];

// Streamed answer broken into segments so we can interleave with reasoning steps.
// Markdown-lite — we'll render manually.
const DEMO_ANSWER_PARAS = [
  {
    text: 'The auth proxy uses a three-stage fallback when the upstream identity service is degraded:',
    after: 'step-4',
  },
  {
    list: [
      { strong: 'Cached refresh.', body: ' If a valid refresh token exists in the local Redis cache (TTL 15 min), the proxy re-signs a short-lived access token without contacting upstream.', cite: '§3.3, p.48' },
      { strong: 'Shadow refresh.', body: ' On cache miss the proxy attempts an async refresh against the primary IDP with a 200 ms ceiling; on timeout it falls back to the cached JWKS to validate the existing token\u2019s signature for one additional minute.', cite: '§3.3, p.49–51' },
      { strong: 'Read-only degradation.', body: ' After 60 s of sustained upstream errors the circuit breaker opens, the proxy issues read-only scoped tokens, and write endpoints are blocked until the §6.2 recovery playbook completes.', cite: '§3.3 → §6.2, p.52 → p.128' },
    ],
    after: 'step-5',
  },
  {
    text: 'During degraded operation the proxy never extends a refresh window beyond 5 minutes — this bounds the blast radius of compromised credentials and is enforced by an out-of-band watchdog in the control plane.',
    after: 'step-6',
  },
];

const DEMO_CITATIONS = [
  {
    nodeId: 'N004-1',
    title: '§3.1 Token Lifecycle',
    pages: 'pp. 29–37',
    doc: 'Xfinity Stream Mesh v3.2',
    why: 'Establishes refresh contract and JWKS rotation cadence.',
  },
  {
    nodeId: 'N004-2',
    title: '§3.2 Auth Proxy Behavior',
    pages: 'pp. 38–46',
    doc: 'Xfinity Stream Mesh v3.2',
    why: 'Defines refresh handoff and retry budget between proxy ↔ IDP.',
  },
  {
    nodeId: 'N004-3',
    title: '§3.3 Degraded-Mode Handling',
    pages: 'pp. 47–53',
    doc: 'Xfinity Stream Mesh v3.2',
    why: 'Primary source — three-stage fallback during upstream degradation.',
    primary: true,
  },
  {
    nodeId: 'N007-2',
    title: '§6.2 Auth Service Outage',
    pages: 'pp. 126–132',
    doc: 'Xfinity Stream Mesh v3.2',
    why: 'Recovery playbook referenced by §3.3 for the read-only path.',
  },
];

const DEMO_CONVERSATIONS = [
  { id: 'c1', title: 'Auth proxy degraded refresh', doc: 'Xfinity Stream Mesh v3.2', when: 'now', active: true },
  { id: 'c2', title: 'mTLS cert rotation cadence', doc: 'Xfinity Stream Mesh v3.2', when: '2h' },
  { id: 'c3', title: 'PCI scope for tokenized PANs', doc: 'Payment Compliance', when: 'yesterday' },
  { id: 'c4', title: 'On-call escalation for IDP outage', doc: 'SRE Handbook · IDP Runbook', when: 'yesterday' },
  { id: 'c5', title: 'Retention rules for billing events', doc: 'Data Retention v4', when: '3d' },
  { id: 'c6', title: 'Sidecar hot-restart safety', doc: 'Xfinity Stream Mesh v3.2', when: '4d' },
];

Object.assign(window, {
  DEMO_DOC, DEMO_DOCS, DEMO_TREE,
  DEMO_QUESTION, DEMO_TRACE, DEMO_ANSWER_PARAS, DEMO_CITATIONS,
  DEMO_CONVERSATIONS,
});
