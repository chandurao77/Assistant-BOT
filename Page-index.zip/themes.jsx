/* global window */
// Three design directions for PolicyPilot.
// All share the same component API — components read tokens via the THEME context.

const themeAegis = {
  id: 'aegis',
  name: 'Aegis',
  tagline: 'Claude-warm · paper · restrained',
  mode: 'light',
  font: {
    sans: '"Inter", "SF Pro Text", system-ui, sans-serif',
    serif: '"Source Serif 4", "Charter", "Iowan Old Style", Georgia, serif',
    mono: '"JetBrains Mono", "IBM Plex Mono", ui-monospace, monospace',
  },
  color: {
    bg: '#F5F2EA',
    surface: '#FBF9F2',
    surfaceAlt: '#F0EDE2',
    surfaceSunk: '#EBE7DA',
    ink: '#1F1E1B',
    text: '#3D3929',
    muted: '#8B8475',
    subtle: '#B5AE9C',
    line: '#E2DCC8',
    lineSoft: '#EDE8D9',
    accent: '#C96442',
    accentInk: '#FFFFFF',
    accentSoft: '#F4DCD0',
    accentDeep: '#9B4A2E',
    ok: '#5B7F4F',
    okSoft: '#E2EAD7',
    warn: '#C28C2A',
    warnSoft: '#F4E6C2',
    err: '#A8413C',
    errSoft: '#F1D5D2',
    glow: 'rgba(201,100,66,0.18)',
    visited: '#C96442',
    visitedFill: '#F4DCD0',
  },
  radius: { sm: 6, md: 10, lg: 14, xl: 20 },
  shadow: {
    sm: '0 1px 0 rgba(31,30,27,0.04), 0 1px 2px rgba(31,30,27,0.03)',
    md: '0 1px 0 rgba(31,30,27,0.04), 0 8px 24px -12px rgba(31,30,27,0.10)',
    lg: '0 1px 0 rgba(31,30,27,0.04), 0 24px 48px -24px rgba(31,30,27,0.18)',
  },
  decor: {
    headerSerif: true,
    chatBg: '#F5F2EA',
    sidebarBg: '#EBE7DA',
    paneBg: '#FBF9F2',
    paneAltBg: '#F0EDE2',
  },
};

const themeNebula = {
  id: 'nebula',
  name: 'Nebula',
  tagline: 'Atmospheric · violet depth · glow',
  mode: 'dark',
  font: {
    sans: '"Inter", "SF Pro Text", system-ui, sans-serif',
    serif: '"Source Serif 4", "Charter", Georgia, serif',
    mono: '"JetBrains Mono", "IBM Plex Mono", ui-monospace, monospace',
  },
  color: {
    bg: '#0A0814',
    surface: '#13102A',
    surfaceAlt: '#1A1638',
    surfaceSunk: '#0F0B22',
    ink: '#F2EEF8',
    text: '#D6CFE8',
    muted: '#928BB0',
    subtle: '#605884',
    line: 'rgba(167,139,250,0.14)',
    lineSoft: 'rgba(167,139,250,0.07)',
    accent: '#A78BFA',
    accentInk: '#0A0814',
    accentSoft: 'rgba(167,139,250,0.16)',
    accentDeep: '#7C5CFF',
    ok: '#4ADE80',
    okSoft: 'rgba(74,222,128,0.14)',
    warn: '#F5C26B',
    warnSoft: 'rgba(245,194,107,0.14)',
    err: '#F87171',
    errSoft: 'rgba(248,113,113,0.14)',
    glow: 'rgba(167,139,250,0.35)',
    visited: '#A78BFA',
    visitedFill: 'rgba(167,139,250,0.18)',
  },
  radius: { sm: 6, md: 12, lg: 18, xl: 24 },
  shadow: {
    sm: '0 1px 0 rgba(0,0,0,0.4)',
    md: '0 12px 40px -12px rgba(167,139,250,0.25), 0 1px 0 rgba(255,255,255,0.04) inset',
    lg: '0 24px 80px -20px rgba(167,139,250,0.35), 0 1px 0 rgba(255,255,255,0.05) inset',
  },
  decor: {
    headerSerif: false,
    chatBg: 'radial-gradient(120% 80% at 20% 0%, #1a0e3a 0%, #0a0814 50%, #07050f 100%)',
    sidebarBg: 'linear-gradient(180deg, #0f0b22 0%, #07050f 100%)',
    paneBg: 'linear-gradient(180deg, #13102A 0%, #100D24 100%)',
    paneAltBg: '#0F0B22',
  },
};

const themeCitadel = {
  id: 'citadel',
  name: 'Citadel',
  tagline: 'Operator console · mono · disciplined',
  mode: 'dark',
  font: {
    sans: '"Inter", "SF Pro Text", system-ui, sans-serif',
    serif: '"Source Serif 4", Georgia, serif',
    mono: '"JetBrains Mono", "IBM Plex Mono", ui-monospace, monospace',
  },
  color: {
    bg: '#0E0D0A',
    surface: '#16140F',
    surfaceAlt: '#1C1A14',
    surfaceSunk: '#0A0907',
    ink: '#F4F1EA',
    text: '#D6D0BF',
    muted: '#8A8470',
    subtle: '#5A5547',
    line: '#2A2721',
    lineSoft: '#1F1C17',
    accent: '#D97757',
    accentInk: '#0E0D0A',
    accentSoft: 'rgba(217,119,87,0.14)',
    accentDeep: '#A85537',
    ok: '#7FB069',
    okSoft: 'rgba(127,176,105,0.12)',
    warn: '#E0B341',
    warnSoft: 'rgba(224,179,65,0.12)',
    err: '#D26A6A',
    errSoft: 'rgba(210,106,106,0.12)',
    glow: 'rgba(217,119,87,0.25)',
    visited: '#D97757',
    visitedFill: 'rgba(217,119,87,0.16)',
  },
  radius: { sm: 4, md: 6, lg: 8, xl: 12 },
  shadow: {
    sm: '0 1px 0 rgba(0,0,0,0.5)',
    md: '0 1px 0 rgba(255,255,255,0.03) inset, 0 8px 24px -12px rgba(0,0,0,0.6)',
    lg: '0 1px 0 rgba(255,255,255,0.04) inset, 0 24px 60px -24px rgba(0,0,0,0.8)',
  },
  decor: {
    headerSerif: false,
    chatBg: '#0E0D0A',
    sidebarBg: '#0A0907',
    paneBg: '#16140F',
    paneAltBg: '#1C1A14',
  },
};

const THEMES = { aegis: themeAegis, nebula: themeNebula, citadel: themeCitadel };
const THEME_LIST = [themeAegis, themeNebula, themeCitadel];

const ThemeContext = React.createContext(themeAegis);
const useTheme = () => React.useContext(ThemeContext);

Object.assign(window, { THEMES, THEME_LIST, ThemeContext, useTheme });
