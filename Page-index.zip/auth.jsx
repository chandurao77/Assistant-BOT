/* global window, React */
// PolicyPilot — Auth screen (520 × 680)
// A single card. Toggle between Sign in / Create account.

function AuthScreen() {
  const theme = window.useTheme();
  const [mode, setMode] = React.useState('signin');

  return (
    <div style={{
      width: 520, height: 680,
      background: theme.decor.chatBg,
      color: theme.color.text,
      fontFamily: theme.font.sans,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 28, overflow: 'hidden',
      position: 'relative',
    }}>
      {/* Decorative orbit / glow */}
      {theme.id === 'nebula' && (
        <>
          <div style={{
            position: 'absolute', width: 360, height: 360, borderRadius: 999,
            border: `1px solid ${theme.color.line}`,
            top: -120, left: -100, pointerEvents: 'none',
          }} />
          <div style={{
            position: 'absolute', width: 200, height: 200, borderRadius: 999,
            background: `radial-gradient(circle, ${theme.color.accentSoft} 0%, transparent 70%)`,
            top: 380, right: -80, pointerEvents: 'none', filter: 'blur(8px)',
          }} />
        </>
      )}
      {theme.id === 'citadel' && (
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          backgroundImage: `linear-gradient(${theme.color.lineSoft} 1px, transparent 1px), linear-gradient(90deg, ${theme.color.lineSoft} 1px, transparent 1px)`,
          backgroundSize: '32px 32px',
          maskImage: 'radial-gradient(ellipse at center, black 0%, transparent 70%)',
          opacity: 0.5,
        }} />
      )}

      <div style={{
        width: '100%', maxWidth: 380,
        display: 'flex', flexDirection: 'column', gap: 24,
        position: 'relative', zIndex: 1,
      }}>
        {/* Logo + brand */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, textAlign: 'center' }}>
          <window.Logo size="lg" />
          <div>
            <h1 style={{
              margin: 0, fontSize: 22, fontWeight: 600,
              color: theme.color.ink,
              fontFamily: theme.decor.headerSerif ? theme.font.serif : theme.font.sans,
              letterSpacing: '-0.015em', lineHeight: 1.15,
            }}>
              {mode === 'signin' ? 'Welcome back' : 'Create your account'}
            </h1>
            <p style={{ margin: '6px 0 0', fontSize: 12.5, color: theme.color.muted, lineHeight: 1.5 }}>
              {mode === 'signin'
                ? 'Reason over your documents, not just search them.'
                : 'Sign up with your Comcast SSO or an email and password.'}
            </p>
          </div>
        </div>

        {/* SSO */}
        <button style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          padding: '11px 14px',
          background: theme.color.surface,
          color: theme.color.ink,
          border: `1px solid ${theme.color.line}`,
          borderRadius: theme.radius.md,
          fontSize: 13.5, fontWeight: 600, fontFamily: theme.font.sans,
          cursor: 'pointer', boxShadow: theme.shadow.sm,
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M2 12 12 2l10 10-10 10z" fill={theme.color.accent}/>
          </svg>
          Continue with Comcast SSO
        </button>

        {/* Divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1, height: 1, background: theme.color.line }} />
          <span style={{ fontFamily: theme.font.mono, fontSize: 10, color: theme.color.subtle, letterSpacing: '0.08em' }}>OR</span>
          <div style={{ flex: 1, height: 1, background: theme.color.line }} />
        </div>

        {/* Form fields */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {mode === 'signup' && <Field label="Full name" placeholder="Ada Kovacs" />}
          <Field label="Work email" placeholder="ada.kovacs@comcast.net" />
          <Field label="Password" type="password" placeholder={mode === 'signup' ? 'At least 12 characters' : '••••••••••••'} hint={mode === 'signin' ? <a href="#" style={{ color: theme.color.accent, textDecoration: 'none', fontSize: 11.5 }}>Forgot?</a> : null} />
          {mode === 'signup' && (
            <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 11.5, color: theme.color.muted, lineHeight: 1.5, cursor: 'pointer' }}>
              <span style={{
                width: 14, height: 14, borderRadius: 3,
                border: `1.4px solid ${theme.color.line}`,
                background: theme.color.surface, flex: '0 0 14px',
                marginTop: 1,
              }} />
              <span>I agree to the <span style={{ color: theme.color.accent }}>Acceptable Use Policy</span> and confirm uploaded documents are not subject to external sharing restrictions.</span>
            </label>
          )}
        </div>

        <button style={{
          padding: '11px 14px',
          background: theme.color.accent, color: theme.color.accentInk,
          border: 'none', borderRadius: theme.radius.md,
          fontSize: 13.5, fontWeight: 600, fontFamily: theme.font.sans,
          cursor: 'pointer',
          boxShadow: `0 8px 20px -8px ${theme.color.glow}, 0 0 0 1px ${theme.color.accentDeep}30 inset`,
        }}>
          {mode === 'signin' ? 'Sign in' : 'Create account'}
        </button>

        <div style={{ textAlign: 'center', fontSize: 12, color: theme.color.muted }}>
          {mode === 'signin' ? 'No account yet?' : 'Already have one?'}{' '}
          <a href="#" onClick={(e) => { e.preventDefault(); setMode(mode === 'signin' ? 'signup' : 'signin'); }} style={{
            color: theme.color.accent, fontWeight: 600, textDecoration: 'none',
          }}>{mode === 'signin' ? 'Create one' : 'Sign in'}</a>
        </div>

        {/* Footer trust line */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          fontSize: 10.5, color: theme.color.subtle, fontFamily: theme.font.mono,
          letterSpacing: '0.06em', marginTop: 4,
        }}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span>JWT · BCRYPT · INTERNAL COMCAST USE ONLY</span>
        </div>
      </div>
    </div>
  );
}

function Field({ label, placeholder, type = 'text', hint }) {
  const theme = window.useTheme();
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 11.5, color: theme.color.muted, fontFamily: theme.font.sans, fontWeight: 500,
      }}>
        <span>{label}</span>
        {hint}
      </span>
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '9px 12px',
        background: theme.color.surface,
        border: `1px solid ${theme.color.line}`,
        borderRadius: theme.radius.md,
        boxShadow: theme.shadow.sm,
      }}>
        <span style={{ fontSize: 13, color: theme.color.subtle, flex: 1, fontFamily: theme.font.sans }}>
          {placeholder}
        </span>
        {type === 'password' && (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={theme.color.muted} strokeWidth="2">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
          </svg>
        )}
      </div>
    </label>
  );
}

Object.assign(window, { AuthScreen });
