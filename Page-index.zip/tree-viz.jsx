/* global window, React */
// PolicyPilot — Tree Visualization standalone view (980 × 780)
// Click any node to see its full summary in the side panel; visited nodes
// from the last query are highlighted by default.

function TreeVizScreen() {
  const theme = window.useTheme();
  const [selectedId, setSelectedId] = React.useState('N004-3');
  const [showVisited, setShowVisited] = React.useState(true);

  const visitedSet = React.useMemo(() => new Set(
    showVisited ? ['N004', 'N004-1', 'N004-2', 'N004-3', 'N007', 'N007-2'] : []
  ), [showVisited]);
  const primaryId = showVisited ? 'N004-3' : null;
  const focusOrder = showVisited
    ? { 'N004': 1, 'N004-1': 2, 'N004-2': 3, 'N004-3': 4, 'N007-2': 5 }
    : {};

  const selected = window.DEMO_TREE.find((n) => n.id === selectedId) || window.DEMO_TREE[0];

  return (
    <div style={{
      width: 980, height: 780,
      background: theme.color.bg, color: theme.color.text,
      fontFamily: theme.font.sans,
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        padding: '18px 24px',
        borderBottom: `1px solid ${theme.color.line}`,
        background: theme.color.surface,
        display: 'flex', alignItems: 'flex-start', gap: 16,
      }}>
        <div style={{
          width: 38, height: 46, borderRadius: 4,
          background: theme.color.errSoft, color: theme.color.err,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: theme.font.mono, fontWeight: 700, fontSize: 11,
          border: `1px solid ${theme.color.line}`,
        }}>PDF</div>
        <div style={{ flex: 1 }}>
          <div style={{
            fontSize: 18, fontWeight: 600, color: theme.color.ink,
            fontFamily: theme.decor.headerSerif ? theme.font.serif : theme.font.sans,
            letterSpacing: '-0.01em',
          }}>Xfinity Stream — Service Mesh Architecture v3.2</div>
          <div style={{ fontSize: 12, color: theme.color.muted, marginTop: 4, fontFamily: theme.font.mono }}>
            142 pages · 38 nodes · 6 visited in last query · cached 18h ago
          </div>
        </div>
        <button onClick={() => setShowVisited(!showVisited)} style={{
          display: 'inline-flex', alignItems: 'center', gap: 7,
          padding: '7px 11px',
          background: showVisited ? theme.color.accent : theme.color.surface,
          color: showVisited ? theme.color.accentInk : theme.color.text,
          border: `1px solid ${showVisited ? theme.color.accent : theme.color.line}`,
          borderRadius: theme.radius.md,
          fontSize: 12.5, fontFamily: theme.font.sans, fontWeight: 600,
          cursor: 'pointer',
        }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          {showVisited ? 'Showing visited' : 'Show visited'}
        </button>
      </div>

      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* Tree */}
        <div style={{
          flex: 1, overflow: 'auto',
          padding: '18px 18px 24px',
          background: theme.decor.paneBg,
          borderRight: `1px solid ${theme.color.line}`,
        }}>
          <window.TreeViewer
            tree={window.DEMO_TREE}
            visitedSet={visitedSet}
            primaryId={primaryId}
            focusOrder={focusOrder}
            onNodeClick={(n) => setSelectedId(n.id)}
          />
        </div>

        {/* Selection panel */}
        <aside style={{
          width: 340, flex: '0 0 340px',
          padding: '20px 22px 24px',
          display: 'flex', flexDirection: 'column', gap: 14,
          overflow: 'auto',
          background: theme.color.bg,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{
              fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.accent,
              padding: '2px 7px', background: theme.color.accentSoft,
              borderRadius: 3, letterSpacing: '0.04em',
            }}>{selected.id}</span>
            <span style={{ fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.muted }}>
              p.{selected.pages}
            </span>
            {visitedSet.has(selected.id) && (
              <span style={{
                marginLeft: 'auto',
                fontFamily: theme.font.mono, fontSize: 9.5, fontWeight: 700,
                padding: '2px 6px',
                background: theme.color.accent, color: theme.color.accentInk,
                borderRadius: 3, letterSpacing: '0.06em',
              }}>VISITED · STEP {focusOrder[selected.id] || '—'}</span>
            )}
          </div>
          <h2 style={{
            margin: 0, fontSize: 18, fontWeight: 600,
            color: theme.color.ink, lineHeight: 1.25,
            fontFamily: theme.decor.headerSerif ? theme.font.serif : theme.font.sans,
            letterSpacing: '-0.01em',
          }}>{selected.title}</h2>

          <div style={{ fontSize: 13, color: theme.color.text, lineHeight: 1.6 }}>
            {selected.summary}
            {selected.id === 'N004-3' && (
              <span style={{ display: 'block', marginTop: 10, color: theme.color.muted, fontSize: 12 }}>
                Defines the three-stage fallback: cached refresh → shadow refresh → read-only degradation.
                Cross-references §6.2 for the recovery contract and §3.1 for refresh-token TTLs.
              </span>
            )}
          </div>

          {/* Page preview thumbnail */}
          <div style={{
            background: theme.color.surface,
            border: `1px solid ${theme.color.line}`,
            borderRadius: theme.radius.md,
            padding: 14,
            boxShadow: theme.shadow.sm,
            display: 'flex', flexDirection: 'column', gap: 8,
            minHeight: 200,
          }}>
            <div style={{ fontFamily: theme.font.mono, fontSize: 10, color: theme.color.subtle, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Source excerpt · p.{(selected.pages || '').split('–')[0]}
            </div>
            <PagePreview node={selected} />
          </div>

          {/* Action buttons */}
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={pillBtn(theme, true)}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              Ask about this section
            </button>
            <button style={pillBtn(theme, false)}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="14 2 14 8 20 8"/><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg>
              Open
            </button>
          </div>

          {/* Node JSON inspector */}
          <div style={{
            marginTop: 4,
            padding: 12,
            background: theme.color.surfaceSunk,
            borderRadius: theme.radius.md,
            border: `1px solid ${theme.color.lineSoft}`,
            fontFamily: theme.font.mono, fontSize: 10.5, lineHeight: 1.6,
            color: theme.color.text,
          }}>
            <div style={{ color: theme.color.subtle, marginBottom: 4 }}>// stored in documents.tree_json (JSONB)</div>
            <span style={{ color: theme.color.muted }}>{`{`}</span><br/>
            &nbsp;&nbsp;<span style={{ color: theme.color.accent }}>"id"</span>: <span style={{ color: theme.color.ok }}>"{selected.id}"</span>,<br/>
            &nbsp;&nbsp;<span style={{ color: theme.color.accent }}>"title"</span>: <span style={{ color: theme.color.ok }}>"{selected.title}"</span>,<br/>
            &nbsp;&nbsp;<span style={{ color: theme.color.accent }}>"pages"</span>: <span style={{ color: theme.color.ok }}>"{selected.pages}"</span>,<br/>
            &nbsp;&nbsp;<span style={{ color: theme.color.accent }}>"level"</span>: <span style={{ color: theme.color.warn }}>{selected.level}</span>,<br/>
            &nbsp;&nbsp;<span style={{ color: theme.color.accent }}>"summary"</span>: <span style={{ color: theme.color.ok }}>"…"</span><br/>
            <span style={{ color: theme.color.muted }}>{`}`}</span>
          </div>
        </aside>
      </div>
    </div>
  );
}

function pillBtn(theme, primary) {
  return {
    display: 'inline-flex', alignItems: 'center', gap: 6,
    padding: '8px 12px',
    background: primary ? theme.color.accent : theme.color.surface,
    color: primary ? theme.color.accentInk : theme.color.text,
    border: `1px solid ${primary ? theme.color.accent : theme.color.line}`,
    borderRadius: theme.radius.md,
    fontSize: 12.5, fontWeight: 600, fontFamily: theme.font.sans,
    cursor: 'pointer', flex: primary ? 1 : 'unset',
    boxShadow: primary ? `0 6px 16px -8px ${theme.color.glow}` : 'none',
  };
}

function PagePreview({ node }) {
  const theme = window.useTheme();
  // Highlight key lines for the primary node (§3.3)
  const isPrimary = node.id === 'N004-3';
  return (
    <div style={{ fontSize: 11.5, lineHeight: 1.65, color: theme.color.text, fontFamily: theme.font.serif }}>
      <div style={{
        fontFamily: theme.font.sans, fontSize: 13, fontWeight: 700, color: theme.color.ink,
        letterSpacing: '-0.005em', marginBottom: 6,
      }}>{node.title}</div>
      <p style={{ margin: '0 0 6px' }}>
        {node.id === 'N004-3'
          ? <>When the upstream identity service returns <code style={inlineCode(theme)}>5xx</code> beyond the proxy's tolerance budget, the auth proxy enters degraded mode. Three fallback stages are evaluated in order:</>
          : <>This section describes the contract governing {node.title.toLowerCase().replace(/^\d+(\.\d+)?\s+/, '')}. See related sections for cross-references and the recovery procedures.</>}
      </p>
      {isPrimary && (
        <ol style={{ margin: 0, paddingLeft: 18, fontSize: 11, color: theme.color.muted }}>
          <li style={{ marginBottom: 4 }}>Cached refresh against local Redis <span style={pageRef(theme)}>p.48</span></li>
          <li style={{ marginBottom: 4, background: theme.color.accentSoft, padding: '2px 4px', borderRadius: 3, color: theme.color.text }}>
            Shadow refresh with 200 ms ceiling <span style={pageRef(theme)}>p.49–51</span>
          </li>
          <li>Read-only degradation after 60 s circuit-breaker open <span style={pageRef(theme)}>p.52</span></li>
        </ol>
      )}
      <div style={{
        marginTop: 10, paddingTop: 8,
        borderTop: `1px dashed ${theme.color.line}`,
        fontFamily: theme.font.mono, fontSize: 10, color: theme.color.subtle,
      }}>… excerpt truncated · click "Open" to view full page</div>
    </div>
  );
}
function inlineCode(theme) {
  return { fontFamily: theme.font.mono, fontSize: 10.5, padding: '1px 5px', background: theme.color.surfaceSunk, borderRadius: 3, color: theme.color.accent };
}
function pageRef(theme) {
  return { fontFamily: theme.font.mono, fontSize: 10, color: theme.color.accent, marginLeft: 4 };
}

Object.assign(window, { TreeVizScreen });
