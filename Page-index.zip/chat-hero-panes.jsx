/* global window, React */
// ChatHero sub-panes: ChatPane, ReasoningPane, TreePane.
// All consume the playhead via props from the parent ChatHero.

// ─── Chat pane (center) ──────────────────────────────────────────────────────

function ChatPane({
  chatScrollRef,
  showThinking,
  para0Progress, para1Progress, para2Progress,
  citationsVisible, metaVisible,
}) {
  const theme = window.useTheme();
  return (
    <main style={{
      flex: '0 0 500px', width: 500,
      display: 'flex', flexDirection: 'column',
      background: theme.color.bg,
      borderRight: `1px solid ${theme.color.line}`,
      minHeight: 0, overflow: 'hidden',
    }}>
      {/* Doc context header */}
      <div style={{
        padding: '14px 22px',
        borderBottom: `1px solid ${theme.color.line}`,
        background: theme.color.surface,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <DocPill />
        <div style={{ flex: 1 }} />
        <span style={{
          fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.muted,
          padding: '3px 8px', background: theme.color.surfaceSunk,
          borderRadius: 999, border: `1px solid ${theme.color.line}`,
          letterSpacing: '0.04em',
        }}>VECTORLESS · gpt-5-mini</span>
      </div>

      {/* Messages */}
      <div ref={chatScrollRef} style={{
        flex: 1, overflowY: 'auto', overflowX: 'hidden',
        padding: '24px 22px 16px',
        display: 'flex', flexDirection: 'column', gap: 22,
      }}>
        <UserMessage text={window.DEMO_QUESTION} />
        <AssistantMessage
          showThinking={showThinking}
          para0Progress={para0Progress}
          para1Progress={para1Progress}
          para2Progress={para2Progress}
          citationsVisible={citationsVisible}
          metaVisible={metaVisible}
        />
      </div>

      {/* Input */}
      <ChatInputBar />
    </main>
  );
}

function DocPill() {
  const theme = window.useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: 32, height: 36, borderRadius: 4,
        background: theme.color.errSoft, color: theme.color.err,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: theme.font.mono, fontWeight: 700, fontSize: 9.5,
        border: `1px solid ${theme.color.line}`,
      }}>PDF</div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.2 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: theme.color.ink }}>Xfinity Stream Mesh v3.2</span>
        <span style={{ fontSize: 11, color: theme.color.muted, fontFamily: theme.font.mono, marginTop: 2 }}>
          142 pages · 38 nodes · ready
        </span>
      </div>
    </div>
  );
}

function UserMessage({ text }) {
  const theme = window.useTheme();
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
      <div style={{
        maxWidth: '85%',
        padding: '10px 14px',
        background: theme.color.accent, color: theme.color.accentInk,
        borderRadius: `${theme.radius.lg}px ${theme.radius.lg}px 4px ${theme.radius.lg}px`,
        fontSize: 14, lineHeight: 1.5, fontWeight: 500,
        boxShadow: `0 6px 16px -8px ${theme.color.glow}`,
      }}>{text}</div>
    </div>
  );
}

function AssistantMessage({
  showThinking,
  para0Progress, para1Progress, para2Progress,
  citationsVisible, metaVisible,
}) {
  const theme = window.useTheme();
  const paras = window.DEMO_ANSWER_PARAS;
  const cites = window.DEMO_CITATIONS;

  return (
    <div style={{ display: 'flex', gap: 12 }}>
      <div style={{
        width: 28, height: 28, borderRadius: 999,
        background: theme.color.surface,
        border: `1px solid ${theme.color.line}`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        flex: '0 0 28px', marginTop: 2,
        boxShadow: theme.shadow.sm,
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={theme.color.accent} strokeWidth="2.2">
          <circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/>
          <path d="M6 8v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8"/><path d="M12 14v2"/>
        </svg>
      </div>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* paragraph 0 */}
        {para0Progress > 0 && (
          <p style={paraStyle(theme)}>
            {window.streamText(paras[0].text, para0Progress)}
            {para0Progress < 1 && <Caret />}
          </p>
        )}
        {/* paragraph 1 — list */}
        {para1Progress > 0 && (
          <ol style={listStyle(theme)}>
            {paras[1].list.map((item, i) => {
              const segProg = Math.max(0, Math.min(1, (para1Progress - i / paras[1].list.length) * paras[1].list.length));
              if (segProg <= 0) return null;
              // Compose full segment text to apply word-safe streaming
              const fullText = item.body;
              return (
                <li key={i} style={{ paddingLeft: 0 }}>
                  <span style={{ fontWeight: 600, color: theme.color.ink }}>{item.strong}</span>
                  {window.streamText(fullText, segProg)}
                  {segProg >= 1 && (
                    <span style={citeRefStyle(theme)}>{item.cite}</span>
                  )}
                  {segProg < 1 && i === Math.floor(para1Progress * paras[1].list.length) && <Caret />}
                </li>
              );
            })}
          </ol>
        )}
        {/* paragraph 2 */}
        {para2Progress > 0 && (
          <p style={paraStyle(theme)}>
            {window.streamText(paras[2].text, para2Progress)}
            {para2Progress < 1 && <Caret />}
          </p>
        )}
        {/* citations */}
        {citationsVisible && (
          <div style={{ marginTop: 6 }}>
            <div style={{
              fontFamily: theme.font.mono, fontSize: 10.5, letterSpacing: '0.06em',
              color: theme.color.subtle, textTransform: 'uppercase', marginBottom: 8,
            }}>Sources · {cites.length}</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {cites.map((c, i) => <CitationCard key={i} c={c} delay={i * 60} />)}
            </div>
          </div>
        )}
        {/* completion meta */}
        {metaVisible && <CompletionMeta />}
        {showThinking && para0Progress === 0 && <Thinking />}
      </div>
    </div>
  );
}

function paraStyle(theme) {
  return {
    margin: 0, color: theme.color.text,
    fontSize: 14, lineHeight: 1.65,
    fontFamily: theme.font.sans,
  };
}
function listStyle(theme) {
  return {
    margin: 0, paddingLeft: 18,
    color: theme.color.text, fontSize: 14, lineHeight: 1.65,
    display: 'flex', flexDirection: 'column', gap: 8,
    fontFamily: theme.font.sans,
  };
}
function citeRefStyle(theme) {
  return {
    display: 'inline-block', marginLeft: 6,
    fontFamily: theme.font.mono, fontSize: 10.5,
    color: theme.color.accent,
    padding: '1px 6px',
    background: theme.color.accentSoft,
    borderRadius: 3, verticalAlign: 1,
    whiteSpace: 'nowrap',
  };
}

function Caret() {
  const theme = window.useTheme();
  return (
    <>
      <span style={{
        display: 'inline-block', width: 8, height: 14,
        background: theme.color.accent, verticalAlign: -2, marginLeft: 2,
        borderRadius: 1, animation: 'pp-blink 900ms infinite',
      }} />
      <style>{`@keyframes pp-blink { 0%,49%{opacity:1} 50%,100%{opacity:0} }`}</style>
    </>
  );
}

function Thinking() {
  const theme = window.useTheme();
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '6px 10px',
      background: theme.color.surface,
      border: `1px solid ${theme.color.line}`,
      borderRadius: theme.radius.md,
      width: 'fit-content',
      fontFamily: theme.font.mono, fontSize: 11, color: theme.color.muted,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: theme.color.accent, animation: 'pp-pulse 1.1s infinite' }} />
      <span>Reading tree index…</span>
      <style>{`@keyframes pp-pulse { 0%,100%{transform:scale(.7);opacity:.4} 50%{transform:scale(1);opacity:1} }`}</style>
    </div>
  );
}

function CitationCard({ c, delay }) {
  const theme = window.useTheme();
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const id = setTimeout(() => setShown(true), delay);
    return () => clearTimeout(id);
  }, [delay]);
  return (
    <div style={{
      padding: 10,
      background: theme.color.surface,
      border: `1px solid ${c.primary ? theme.color.accent + '60' : theme.color.line}`,
      borderRadius: theme.radius.md,
      display: 'flex', flexDirection: 'column', gap: 4,
      boxShadow: c.primary ? `0 0 0 1px ${theme.color.accent}40, 0 0 24px -6px ${theme.color.glow}` : theme.shadow.sm,
      opacity: shown ? 1 : 0, transform: shown ? 'translateY(0)' : 'translateY(4px)',
      transition: 'opacity 240ms ease, transform 240ms ease',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'space-between' }}>
        <span style={{ fontFamily: theme.font.mono, fontSize: 10, color: theme.color.accent, letterSpacing: '0.04em' }}>{c.nodeId}</span>
        <span style={{ fontFamily: theme.font.mono, fontSize: 10, color: theme.color.muted }}>{c.pages}</span>
      </div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: theme.color.ink, lineHeight: 1.35 }}>{c.title}</div>
      <div style={{ fontSize: 11, color: theme.color.muted, lineHeight: 1.45 }}>{c.why}</div>
    </div>
  );
}

function CompletionMeta() {
  const theme = window.useTheme();
  const metrics = [
    { label: 'Documents', value: '1' },
    { label: 'Nodes visited', value: '6' },
    { label: 'Reasoning hops', value: '5' },
    { label: 'Confidence', value: 'High', tint: theme.color.ok },
  ];
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '10px 14px', marginTop: 6,
      background: theme.color.surfaceSunk,
      borderRadius: theme.radius.md,
      border: `1px solid ${theme.color.lineSoft}`,
    }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={theme.color.ok} strokeWidth="2.4">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
      </svg>
      {metrics.map((m, i) => (
        <React.Fragment key={i}>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
            <span style={{ fontSize: 10, color: theme.color.subtle, fontFamily: theme.font.mono, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{m.label}</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: m.tint || theme.color.ink, marginTop: 2 }}>{m.value}</span>
          </div>
          {i < metrics.length - 1 && <div style={{ width: 1, height: 22, background: theme.color.line }} />}
        </React.Fragment>
      ))}
    </div>
  );
}

function ChatInputBar() {
  const theme = window.useTheme();
  return (
    <div style={{
      padding: '14px 18px 18px',
      borderTop: `1px solid ${theme.color.line}`,
      background: theme.color.bg,
    }}>
      <div style={{
        display: 'flex', alignItems: 'flex-end', gap: 10,
        padding: '10px 12px',
        background: theme.color.surface,
        border: `1px solid ${theme.color.line}`,
        borderRadius: theme.radius.lg,
        boxShadow: theme.shadow.sm,
      }}>
        <button style={{
          width: 30, height: 30, padding: 0,
          background: 'transparent', color: theme.color.muted,
          border: 'none', borderRadius: theme.radius.sm,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>
          </svg>
        </button>
        <div style={{ flex: 1, fontSize: 13.5, color: theme.color.subtle, padding: '5px 0', fontFamily: theme.font.sans }}>
          Ask another question about this document…
        </div>
        <div style={{
          fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.subtle,
          padding: '3px 7px', background: theme.color.surfaceSunk,
          borderRadius: 4, border: `1px solid ${theme.color.line}`, marginRight: 4,
        }}>⌘↵</div>
        <button style={{
          width: 32, height: 32, padding: 0,
          background: theme.color.accent, color: theme.color.accentInk,
          border: 'none', borderRadius: theme.radius.sm,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', boxShadow: theme.shadow.sm,
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
        </button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 10, fontSize: 11, color: theme.color.muted, fontFamily: theme.font.mono }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 6, height: 6, borderRadius: 999, background: theme.color.ok }} />
          gpt-5-mini · FlowContext
        </span>
        <span>·</span>
        <span>Reasoning over 1 doc · 38 nodes in cache</span>
      </div>
    </div>
  );
}

// ─── Reasoning pane ──────────────────────────────────────────────────────────

function ReasoningPane({ reasoningScrollRef, stepsRevealed }) {
  const theme = window.useTheme();
  const trace = window.DEMO_TRACE;
  const visibleCount = stepsRevealed.filter(Boolean).length;
  const done = stepsRevealed.every(Boolean);
  return (
    <section style={{
      flex: '0 0 320px', width: 320,
      display: 'flex', flexDirection: 'column',
      background: theme.decor.paneBg,
      borderRight: `1px solid ${theme.color.line}`,
      minHeight: 0, overflow: 'hidden',
    }}>
      <PaneHeader
        title="Reasoning trace"
        meta={done ? `${trace.length} steps · 5 hops` : `step ${visibleCount}/${trace.length}`}
        dotColor={done ? theme.color.ok : theme.color.accent}
        animate={!done}
      />
      <div ref={reasoningScrollRef} style={{
        flex: 1, overflowY: 'auto',
        padding: '16px 16px 24px',
        position: 'relative',
      }}>
        {/* vertical guideline */}
        <div style={{
          position: 'absolute', left: 26, top: 22, bottom: 24,
          width: 1, background: theme.color.line,
        }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {trace.map((step, i) => {
            const shown = stepsRevealed[i];
            const isLast = i === trace.length - 1 && stepsRevealed[i] && !stepsRevealed.every(Boolean);
            return (
              <TraceStep key={i} step={step} shown={shown} active={i === visibleCount - 1 && !done} />
            );
          })}
        </div>
      </div>
    </section>
  );
}

function TraceStep({ step, shown, active }) {
  const theme = window.useTheme();
  if (!shown) return null;
  const kindColor = {
    plan: theme.color.muted,
    fetch: theme.color.accent,
    crossref: theme.color.warn,
    compose: theme.color.ok,
  }[step.kind] || theme.color.accent;
  const kindLabel = {
    plan: 'PLAN',
    fetch: 'FETCH',
    crossref: 'XREF',
    compose: 'COMPOSE',
  }[step.kind] || 'STEP';
  return (
    <div style={{
      display: 'flex', gap: 10,
      opacity: shown ? 1 : 0, transform: shown ? 'translateY(0)' : 'translateY(4px)',
      transition: 'opacity 280ms ease, transform 280ms ease',
    }}>
      {/* Step circle */}
      <div style={{
        width: 22, height: 22, borderRadius: 999,
        background: step.primary ? theme.color.accent : theme.color.surface,
        color: step.primary ? theme.color.accentInk : theme.color.muted,
        border: `1px solid ${step.primary ? theme.color.accent : theme.color.line}`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: theme.font.mono, fontSize: 10, fontWeight: 700,
        flex: '0 0 22px',
        position: 'relative', zIndex: 1,
        boxShadow: step.primary ? `0 0 0 3px ${theme.color.accentSoft}` : 'none',
      }}>
        {step.n}
        {active && (
          <span style={{
            position: 'absolute', inset: -4,
            border: `1.5px solid ${theme.color.accent}`,
            borderRadius: 999, opacity: 0.6,
            animation: 'pp-ring 1.4s infinite ease-out',
          }} />
        )}
        <style>{`@keyframes pp-ring { 0%{transform:scale(.85);opacity:.7} 100%{transform:scale(1.5);opacity:0} }`}</style>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
          <span style={{
            fontFamily: theme.font.mono, fontSize: 9.5, fontWeight: 700,
            color: kindColor, letterSpacing: '0.06em',
            padding: '1px 5px', background: theme.color.surfaceSunk,
            borderRadius: 3, flex: '0 0 auto',
          }}>{kindLabel}</span>
          {step.pages && (
            <span style={{
              fontFamily: theme.font.mono, fontSize: 10, color: theme.color.muted,
              flex: '0 0 auto', whiteSpace: 'nowrap',
            }}>{step.pages}</span>
          )}
        </div>
        <div style={{
          fontSize: 12.5, fontWeight: 600, color: theme.color.ink, lineHeight: 1.3,
          marginBottom: 4,
        }}>
          {step.title}
        </div>
        <div style={{ fontSize: 11.5, color: theme.color.muted, lineHeight: 1.5, marginBottom: step.nodes && step.nodes.length ? 6 : 0 }}>
          {step.body}
        </div>
        {step.nodes && step.nodes.length > 0 && (
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {step.nodes.map((nid) => (
              <span key={nid} style={{
                fontFamily: theme.font.mono, fontSize: 10,
                padding: '2px 6px',
                background: theme.color.accentSoft,
                color: theme.color.accent,
                borderRadius: 3,
                whiteSpace: 'nowrap',
              }}>{nid}</span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PaneHeader({ title, meta, dotColor, animate }) {
  const theme = window.useTheme();
  return (
    <div style={{
      padding: '14px 18px',
      borderBottom: `1px solid ${theme.color.line}`,
      display: 'flex', alignItems: 'center', gap: 10,
      background: theme.decor.paneAltBg,
    }}>
      <span style={{
        width: 8, height: 8, borderRadius: 999, background: dotColor,
        boxShadow: animate ? `0 0 0 4px ${dotColor}25` : 'none',
        animation: animate ? 'pp-dot 1.4s infinite ease-out' : 'none',
      }} />
      <style>{`@keyframes pp-dot { 0%,100%{box-shadow:0 0 0 0 ${dotColor}40} 50%{box-shadow:0 0 0 5px ${dotColor}05} }`}</style>
      <span style={{
        fontFamily: theme.font.sans, fontSize: 12, fontWeight: 600,
        color: theme.color.ink, letterSpacing: '-0.005em', textTransform: 'uppercase',
      }}>{title}</span>
      <div style={{ flex: 1 }} />
      <span style={{ fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.muted }}>{meta}</span>
    </div>
  );
}

// ─── Tree pane ───────────────────────────────────────────────────────────────

function TreePane({ visitedSet, primaryId, focusOrder }) {
  const theme = window.useTheme();
  return (
    <section style={{
      flex: '0 0 380px', width: 380,
      display: 'flex', flexDirection: 'column',
      background: theme.decor.paneBg,
      minHeight: 0, overflow: 'hidden',
    }}>
      <PaneHeader
        title="Document tree"
        meta={`${visitedSet.size}/38 nodes visited`}
        dotColor={primaryId ? theme.color.accent : theme.color.muted}
        animate={visitedSet.size > 0 && visitedSet.size < 6}
      />
      <div style={{
        flex: 1, overflowY: 'auto',
        padding: '12px 12px 24px',
      }}>
        <window.TreeViewer
          tree={window.DEMO_TREE}
          visitedSet={visitedSet}
          primaryId={primaryId}
          focusOrder={focusOrder}
          compact
        />
      </div>
      <div style={{
        padding: '10px 14px',
        borderTop: `1px solid ${theme.color.line}`,
        background: theme.decor.paneAltBg,
        display: 'flex', alignItems: 'center', gap: 10,
        fontFamily: theme.font.mono, fontSize: 10.5, color: theme.color.muted,
      }}>
        <span style={{ width: 10, height: 10, borderRadius: 2, background: theme.color.accent, flex: '0 0 10px' }} />
        <span>Primary source</span>
        <span style={{ width: 10, height: 10, borderRadius: 2, background: theme.color.visitedFill, border: `1px solid ${theme.color.accent}40`, flex: '0 0 10px', marginLeft: 8 }} />
        <span>Visited</span>
      </div>
    </section>
  );
}

Object.assign(window, { ChatPane, ReasoningPane, TreePane });
