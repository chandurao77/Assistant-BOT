/* global window, React */
// PolicyPilot — Main app: assembles all artboards into a DesignCanvas,
// with Tweaks for replay, streaming speed, and accent.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "streamingSpeed": 1,
  "autoplay": true,
  "showVisitedTrail": true,
  "compactDensity": false
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [replayKey, setReplayKey] = React.useState(0);
  const speed = Number(tweaks.streamingSpeed) || 1;

  const themed = (themeId, child) => (
    <window.ThemeContext.Provider value={window.THEMES[themeId]}>
      {child}
    </window.ThemeContext.Provider>
  );

  const heroFor = (themeId) => themed(themeId,
    <window.ChatHero replayKey={replayKey} speed={speed} />
  );
  const dashFor = (themeId) => themed(themeId, <window.Dashboard />);
  const treeFor = (themeId) => themed(themeId, <window.TreeVizScreen />);
  const authFor = (themeId) => themed(themeId, <window.AuthScreen />);

  return (
    <>
      <window.DesignCanvas>
        {window.THEME_LIST.map((th) => (
          <window.DCSection
            key={th.id}
            id={th.id}
            title={`${th.name} — ${th.tagline}`}
            subtitle={
              th.id === 'aegis' ? 'Claude-warm paper. Coral on cream. Serif headlines. Restraint over volume.'
              : th.id === 'nebula' ? 'Dark violet atmosphere. Glow accents. Dramatic; the reasoning loop feels alive.'
              : 'Operator console. Mono-heavy, restrained warmth, disciplined density.'
            }
          >
            <window.DCArtboard
              id={`${th.id}-hero`}
              label={`${th.name} · Chat hero (answer + reasoning + tree)`}
              width={1440} height={880}
            >
              {heroFor(th.id)}
            </window.DCArtboard>
            <window.DCArtboard
              id={`${th.id}-dash`}
              label={`${th.name} · Dashboard / File Manager`}
              width={1280} height={800}
            >
              {dashFor(th.id)}
            </window.DCArtboard>
            <window.DCArtboard
              id={`${th.id}-tree`}
              label={`${th.name} · Tree visualization`}
              width={980} height={780}
            >
              {treeFor(th.id)}
            </window.DCArtboard>
            <window.DCArtboard
              id={`${th.id}-auth`}
              label={`${th.name} · Sign in / Create account`}
              width={520} height={680}
            >
              {authFor(th.id)}
            </window.DCArtboard>
          </window.DCSection>
        ))}
      </window.DesignCanvas>

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection label="Playback">
          <window.TweakButton
            label="Replay all heroes"
            onClick={() => setReplayKey((k) => k + 1)}
          />
          <window.TweakRadio
            label="Streaming speed"
            value={String(tweaks.streamingSpeed)}
            options={[
              { value: '0.5', label: 'Slow' },
              { value: '1', label: 'Normal' },
              { value: '2', label: 'Fast' },
            ]}
            onChange={(v) => setTweak('streamingSpeed', Number(v))}
          />
        </window.TweakSection>
        <window.TweakSection label="Display">
          <window.TweakToggle
            label="Show visited trail in tree views"
            value={!!tweaks.showVisitedTrail}
            onChange={(v) => setTweak('showVisitedTrail', v)}
          />
          <window.TweakToggle
            label="Compact density"
            value={!!tweaks.compactDensity}
            onChange={(v) => setTweak('compactDensity', v)}
          />
        </window.TweakSection>
        <window.TweakSection label="About">
          <div style={{ fontSize: 11.5, lineHeight: 1.55, opacity: 0.7 }}>
            Three directions, four screens each. Drag artboards to reorder.
            Click any artboard's <strong>⤢</strong> to view fullscreen with arrow-key navigation.
          </div>
        </window.TweakSection>
      </window.TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
