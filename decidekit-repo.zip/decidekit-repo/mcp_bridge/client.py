"""
Thin client for pulling log samples from your internal MCP server.

This file is intentionally generic: it does NOT know your server's real
address, auth scheme, or tool names. You fill those in once you have your
internal MCP server's connection details in front of you on your company
laptop. Nothing here talks to the outside internet.

Expected shape of your internal setup, based on what you described:
  your MCP server -> connects to an LLM gateway -> pulls logs from Kibana
  across your domains.

This client assumes your MCP server exposes at least one callable "tool"
that, given a domain and a time window, returns a list of log records or
query records. Adjust CONFIG and the two functions below to match your
server's actual tool name and response shape once you can see them.
"""
import json
import os
from dataclasses import dataclass
from typing import List, Dict, Any, Optional


@dataclass
class MCPBridgeConfig:
    # Fill these in from your internal MCP server's own docs/config.
    # Never hardcode secrets here -- read them from environment variables.
    server_url: Optional[str] = None          # e.g. os.environ.get("QQ_MCP_URL")
    auth_token_env_var: str = "QQ_MCP_TOKEN"   # name of the env var holding your token
    tool_name: str = "search_logs"             # the MCP tool name your server exposes
    default_domain: Optional[str] = None       # e.g. "billing", "activation", etc.

    @staticmethod
    def from_env():
        return MCPBridgeConfig(
            server_url=os.environ.get("QQ_MCP_URL"),
            auth_token_env_var="QQ_MCP_TOKEN",
            tool_name=os.environ.get("QQ_MCP_TOOL_NAME", "search_logs"),
            default_domain=os.environ.get("QQ_MCP_DEFAULT_DOMAIN"),
        )


class MCPLogBridge:
    """
    Adapter around your internal MCP server.

    Usage once wired up:
        bridge = MCPLogBridge(MCPBridgeConfig.from_env())
        records = bridge.fetch_recent(domain="activation", hours=24, limit=200)

    You will need to plug in the actual MCP call in `_call_mcp_tool` below,
    using whatever MCP client library your internal tooling already uses
    (this is left as a clearly marked stub since every internal MCP setup
    wires up its transport a little differently).
    """

    def __init__(self, config: MCPBridgeConfig):
        self.config = config
        self._client = None  # lazily initialized real MCP client goes here

    def _get_token(self) -> Optional[str]:
        return os.environ.get(self.config.auth_token_env_var)

    def _call_mcp_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """
        REPLACE THIS with your actual MCP call.

        If you're using an MCP Python SDK, this typically looks like:

            from mcp import ClientSession
            async with ClientSession(...) as session:
                result = await session.call_tool(tool_name, arguments)
                return result

        Or if your internal flow MCP is exposed over HTTP, this might be
        a simple authenticated POST request instead. Either way, keep the
        call isolated to this one method so the rest of the bridge never
        needs to change.
        """
        raise NotImplementedError(
            "Wire up your internal MCP server call here. "
            f"Would call tool='{tool_name}' with arguments={arguments}"
        )

    def fetch_recent(self, domain: Optional[str] = None, hours: int = 24, limit: int = 200) -> List[Dict[str, Any]]:
        """Fetch recent log/query records for a domain over a time window."""
        domain = domain or self.config.default_domain
        arguments = {"domain": domain, "hours": hours, "limit": limit}
        raw = self._call_mcp_tool(self.config.tool_name, arguments)
        return self._normalize(raw)

    def _normalize(self, raw: Any) -> List[Dict[str, Any]]:
        """
        Normalize whatever your MCP server returns into a flat list of
        dicts, each with at least a 'text' field decidekit can train on.

        Adjust this once you see your server's real response shape.
        Common shapes to handle: a list of dicts, a dict with a 'results'
        key, or a JSON string that needs parsing first.
        """
        if isinstance(raw, str):
            raw = json.loads(raw)
        if isinstance(raw, dict) and "results" in raw:
            raw = raw["results"]
        if not isinstance(raw, list):
            raise ValueError(f"Unexpected MCP response shape: {type(raw)}")

        normalized = []
        for item in raw:
            if isinstance(item, str):
                normalized.append({"text": item})
            elif isinstance(item, dict):
                text = item.get("text") or item.get("query") or item.get("message") or ""
                normalized.append({**item, "text": text})
        return normalized
