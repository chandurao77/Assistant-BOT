"""Scan local docs and repos for real error codes, services and domains.

Nothing here talks to the network. It only reads files under the folders
you list in seedgen.config.json.
"""
import json
import re
from pathlib import Path

SKIP_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__", "target",
    "build", "dist", ".idea", ".gradle", ".pytest_cache", ".mypy_cache",
}
TEXT_EXTS = {".md", ".txt", ".py", ".java", ".json", ".yaml", ".yml", ".ts", ".js"}
DOC_EXTS = {".md", ".txt", ".pdf"}
MAX_BYTES = 1_000_000

# A pattern with a capture group uses group 1, otherwise the whole match.
DEFAULT_CODE_PATTERNS = [
    r"\b[A-Z]{2,8}[-_]\d{2,6}\b",                       # ERR-1001, ORA-00942, ACT_4001
    r"\bE\d{3,6}\b",                                    # E1001
    r"(?i:\b(?:http|status)(?:\s+code)?[:\s]+)([45]\d{2})\b",  # HTTP 503, status: 500
]

HANDLER_STEMS = {"app", "handler", "lambda_function", "main", "index"}
STRIP_SUFFIXES = ("Handler", "Function", "Lambda", "Processor", "Consumer", "Service")


def spoken(name):
    """ActivationGatewayHandler -> 'activation gateway'; my-svc_name -> 'my svc name'."""
    base = name
    for suf in STRIP_SUFFIXES:
        if base.endswith(suf) and len(base) > len(suf):
            base = base[: -len(suf)]
            break
    base = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", base)
    base = re.sub(r"[-_.]+", " ", base)
    return re.sub(r"\s+", " ", base).strip().lower()


def _clean(s):
    s = re.sub(r"[`*#>]", " ", s)
    s = s.replace("|", " - ")
    s = re.sub(r"(?:\s*-\s*){2,}", " - ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip(" -:\t")


def _meaning_for(code, lines, i):
    """Pull a short human meaning for `code` from line i (or the next line)."""
    line = lines[i].replace(code, " ")
    meaning = _clean(line)
    if len(meaning) < 8:
        for j in range(i + 1, min(i + 3, len(lines))):
            nxt = _clean(lines[j])
            if len(nxt) >= 8:
                meaning = nxt
                break
    return meaning[:200]


def _read_pdf(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        return None
    try:
        reader = PdfReader(str(path))
        return "\n".join((p.extract_text() or "") for p in reader.pages)
    except Exception:
        return None


def _iter_files(root, exts):
    root = Path(root).expanduser()
    if not root.exists():
        return
    for p in root.rglob("*"):
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        if p.is_file() and p.suffix.lower() in exts:
            yield p


def _read_text(path, stats):
    if path.suffix.lower() == ".pdf":
        text = _read_pdf(path)
        if text is None:
            stats["pdf_skipped"] += 1
        return text
    try:
        if path.stat().st_size > MAX_BYTES:
            stats["too_large"] += 1
            return None
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None


def _services_from_json(text, path):
    try:
        data = json.loads(text)
    except ValueError:
        return []
    out = []
    if isinstance(data, dict) and isinstance(data.get("States"), dict):
        stem = path.name.split(".")[0]
        out.append(("state_machine", stem))
        for name, st in data["States"].items():
            out.append(("step", name))
            res = st.get("Resource") if isinstance(st, dict) else None
            if isinstance(res, str) and ":function:" in res:
                out.append(("lambda", res.split(":function:")[1].split(":")[0]))
    if isinstance(data, dict) and isinstance(data.get("Resources"), dict):
        for name, r in data["Resources"].items():
            typ = r.get("Type", "") if isinstance(r, dict) else ""
            if typ.endswith("Function"):
                out.append(("lambda", name))
            elif "StateMachine" in typ:
                out.append(("state_machine", name))
    return out


def _services_from_yaml(text):
    out, last = [], None
    for line in text.splitlines():
        m = re.match(r"^  ([A-Za-z0-9_\-]+):\s*$", line)
        if m:
            last = m.group(1)
            continue
        t = re.match(r"^    Type:\s*['\"]?(AWS::[A-Za-z:]+)", line)
        if t and last:
            typ = t.group(1)
            if typ.endswith("Function"):
                out.append(("lambda", last))
            elif "StateMachine" in typ:
                out.append(("state_machine", last))
    return out


def _services_from_code(text, path):
    out = []
    suffix = path.suffix.lower()
    if suffix == ".py" and re.search(r"def\s+(lambda_handler|handler)\s*\(", text):
        name = path.parent.name if path.stem in HANDLER_STEMS else path.stem
        out.append(("lambda", name))
    if suffix == ".java":
        for m in re.finditer(r"class\s+(\w+(?:Handler|Service|Processor|Consumer))\b", text):
            out.append(("java_class", m.group(1)))
    return out


def scan(doc_roots, repo_roots, domains=None, extra_patterns=None, max_items=300):
    patterns = [re.compile(p) for p in DEFAULT_CODE_PATTERNS + list(extra_patterns or [])]
    stats = {"files_read": 0, "pdf_skipped": 0, "too_large": 0}
    codes = {}      # code -> {"code","meaning","source","from_doc"}
    services = {}   # name -> {"name","spoken","kind","source"}

    def add_codes(text, path, from_doc):
        lines = text.splitlines()
        for i, line in enumerate(lines):
            for pat in patterns:
                for m in pat.finditer(line):
                    code = m.group(1) if pat.groups else m.group(0)
                    meaning = _meaning_for(code, lines, i)
                    cur = codes.get(code)
                    better = cur is None or (from_doc and not cur["from_doc"]) or (
                        not cur["meaning"] and meaning)
                    if better:
                        codes[code] = {"code": code, "meaning": meaning,
                                       "source": str(path), "from_doc": from_doc}

    def add_service(kind, name, path):
        if name and name not in services:
            services[name] = {"name": name, "spoken": spoken(name),
                              "kind": kind, "source": str(path)}

    for root in doc_roots:
        for p in _iter_files(root, DOC_EXTS):
            text = _read_text(p, stats)
            if text:
                stats["files_read"] += 1
                add_codes(text, p, from_doc=True)

    for root in repo_roots:
        for p in _iter_files(root, TEXT_EXTS):
            text = _read_text(p, stats)
            if not text:
                continue
            stats["files_read"] += 1
            add_codes(text, p, from_doc=p.suffix.lower() in DOC_EXTS)
            suffix = p.suffix.lower()
            found = []
            if suffix == ".json":
                found = _services_from_json(text, p)
            elif suffix in (".yaml", ".yml"):
                found = _services_from_yaml(text)
            else:
                found = _services_from_code(text, p)
            for kind, name in found:
                add_service(kind, name, p)

    code_list = sorted(codes.values(), key=lambda c: c["code"])[:max_items]
    for c in code_list:
        c.pop("from_doc", None)
    svc_list = sorted(services.values(), key=lambda s: s["name"])[:max_items]
    return {
        "error_codes": code_list,
        "services": svc_list,
        "domains": list(domains or []),
        "stats": stats,
    }
