"""Assemble train/test files. Only REAL queries ever go into the test set."""
import hashlib
from pathlib import Path

from .generate import read_jsonl, write_jsonl

KEEP = ("text", "intent", "is_urgent", "source")


def _slim(row, source):
    out = {k: row[k] for k in KEEP if k in row}
    out["source"] = source
    return out


def _is_test(text, test_pct):
    h = int(hashlib.md5(text.lower().strip().encode()).hexdigest(), 16)
    return (h % 100) < test_pct


def build(seed_rows, real_rows, out_dir, test_pct=30, min_real_test=30):
    seed_rows = [r for r in seed_rows if r.get("review") != "dropped"]
    seed_train = [_slim(r, "seed") for r in seed_rows if r.get("group") != "holdout"]
    seed_holdout = [_slim(r, "seed") for r in seed_rows if r.get("group") == "holdout"]

    real_train, real_test = [], []
    for r in real_rows:
        (real_test if _is_test(r["text"], test_pct) else real_train).append(_slim(r, "real"))

    out = Path(out_dir)
    write_jsonl(seed_train + real_train, out / "train.jsonl")
    write_jsonl(seed_holdout, out / "seed_holdout.jsonl")
    if real_test:
        write_jsonl(real_test, out / "test.jsonl")
    elif (out / "test.jsonl").exists():
        (out / "test.jsonl").unlink()

    warnings = []
    if not real_rows:
        warnings.append("No real labeled queries yet. Accuracy on seed_holdout.jsonl is "
                        "optimistic: it is still template phrasing, not your users.")
    elif len(real_test) < min_real_test:
        warnings.append(f"Only {len(real_test)} real test rows (want {min_real_test}+). "
                        "Treat accuracy numbers as rough.")
    return {
        "train": len(seed_train) + len(real_train),
        "seed_train": len(seed_train), "real_train": len(real_train),
        "seed_holdout": len(seed_holdout), "real_test": len(real_test),
        "warnings": warnings,
    }
