"""seedgen CLI.

    python -m seedgen scan
    python -m seedgen generate
    python -m seedgen review
    python -m seedgen build
"""
import argparse
import json
import sys
from pathlib import Path

from .scan import scan
from .generate import generate, load_templates, read_jsonl, write_jsonl
from .review import pick_sample, review_interactive, summary, DEFAULT_INTENTS
from .build import build


def _intents_from_questions(path):
    try:
        with open(path) as f:
            for q in json.load(f):
                if q.get("name") == "intent":
                    return q["options"]
    except OSError:
        pass
    return DEFAULT_INTENTS


def cmd_scan(a):
    cfg_path = Path(a.config)
    if not cfg_path.exists():
        sys.exit(f"{a.config} not found. Copy seedgen.config.example.json to {a.config} "
                 "and set your doc and repo folders.")
    cfg = json.loads(cfg_path.read_text())
    base = cfg_path.parent
    resolve = lambda paths: [str((base / p).expanduser()) if not Path(p).expanduser().is_absolute()
                             else str(Path(p).expanduser()) for p in paths]
    k = scan(resolve(cfg.get("doc_roots", [])), resolve(cfg.get("repo_roots", [])),
             cfg.get("domains"), cfg.get("error_code_patterns"), cfg.get("max_items", 300))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(k, indent=2))
    s = k["stats"]
    print(f"Read {s['files_read']} files -> {len(k['error_codes'])} error codes, "
          f"{len(k['services'])} services, {len(k['domains'])} domains. Saved {a.out}")
    if s["pdf_skipped"]:
        print(f"  {s['pdf_skipped']} PDFs skipped (pip install pypdf to read them)")
    if not k["error_codes"]:
        print("  WARNING: no error codes found. Check doc_roots, or add error_code_patterns.")
    for c in k["error_codes"][:8]:
        print(f"  {c['code']}: {c['meaning'][:70]}")
    print("Open the file and delete junk before generating.")


def cmd_generate(a):
    k = json.loads(Path(a.knowledge).read_text())
    tpl = load_templates(a.templates)
    rows, warnings = generate(k, tpl, a.per_template, a.seed)
    write_jsonl(rows, a.out)
    print(f"Wrote {len(rows)} seed rows to {a.out}")
    for w in warnings:
        print("  " + w)


def cmd_review(a):
    src = Path(a.out) if Path(a.out).exists() else Path(a.inp)
    rows = read_jsonl(src)
    idxs = pick_sample(rows, a.fraction)
    print(f"Reviewing {len(idxs)} of {len(rows)} rows (resuming from {src}).")
    finished = review_interactive(rows, idxs, _intents_from_questions(a.questions))
    write_jsonl(rows, a.out)
    s = summary(rows)
    print(f"\nSaved to {a.out}. accepted={s['accepted']} fixed={s['fixed']} dropped={s['dropped']}")
    if s["agreement"] is not None:
        print(f"Template labels were right {s['agreement']:.0%} of the time.")
        if s["agreement"] < 0.9:
            print("Below 90%: fix the templates in seedgen/templates.json and regenerate.")
    if not finished:
        print("Stopped early. Run again to continue.")


def cmd_build(a):
    reviewed = Path(a.reviewed)
    seed_path = reviewed if reviewed.exists() else Path(a.candidates)
    if not seed_path.exists():
        sys.exit("No seed data. Run: python -m seedgen generate")
    if seed_path == Path(a.candidates):
        print("Note: using unreviewed seed data. Run `python -m seedgen review` first.")
    real = read_jsonl(a.real) if Path(a.real).exists() else []
    r = build(read_jsonl(seed_path), real, a.out_dir, a.test_pct)
    print(f"train.jsonl: {r['train']} rows ({r['seed_train']} seed + {r['real_train']} real)")
    print(f"seed_holdout.jsonl: {r['seed_holdout']} rows (unseen template phrasing)")
    print(f"test.jsonl: {r['real_test']} real rows")
    for w in r["warnings"]:
        print("WARNING: " + w)


def main():
    p = argparse.ArgumentParser(prog="seedgen")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("scan")
    s.add_argument("--config", default="seedgen.config.json")
    s.add_argument("--out", default="data/seed/knowledge.json")
    s.set_defaults(func=cmd_scan)

    g = sub.add_parser("generate")
    g.add_argument("--knowledge", default="data/seed/knowledge.json")
    g.add_argument("--templates", default=None)
    g.add_argument("--out", default="data/seed/candidates.jsonl")
    g.add_argument("--per-template", type=int, default=12)
    g.add_argument("--seed", type=int, default=7)
    g.set_defaults(func=cmd_generate)

    r = sub.add_parser("review")
    r.add_argument("--in", dest="inp", default="data/seed/candidates.jsonl")
    r.add_argument("--out", default="data/seed/reviewed.jsonl")
    r.add_argument("--fraction", type=float, default=0.15)
    r.add_argument("--questions", default="examples/questions.json")
    r.set_defaults(func=cmd_review)

    b = sub.add_parser("build")
    b.add_argument("--candidates", default="data/seed/candidates.jsonl")
    b.add_argument("--reviewed", default="data/seed/reviewed.jsonl")
    b.add_argument("--real", default="data/real/labeled.jsonl")
    b.add_argument("--out-dir", default="data/labeled")
    b.add_argument("--test-pct", type=int, default=30)
    b.set_defaults(func=cmd_build)

    a = p.parse_args()
    a.func(a)


if __name__ == "__main__":
    main()
