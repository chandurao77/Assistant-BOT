"""Fill templates with terms found by scan.py to make starter training rows.

These rows are SEED data: template phrasing with real error codes and
service names. Labels come from the template, not from a human, so every
row is marked needs_review and should be spot-checked (see review.py).
"""
import json
import random
import re
from pathlib import Path

PLACEHOLDER = re.compile(r"\{(\w+)\}")
DEFAULT_TEMPLATES = Path(__file__).with_name("templates.json")


def load_templates(path=None):
    with open(path or DEFAULT_TEMPLATES) as f:
        return json.load(f)


def _pools(knowledge, tpl):
    svc = []
    for s in knowledge.get("services", []):
        svc.append(s["name"])
        if s.get("spoken") and s["spoken"] != s["name"].lower():
            svc.append(s["spoken"])
    return {
        "code": [c["code"] for c in knowledge.get("error_codes", [])],
        "service": svc,
        "domain": list(knowledge.get("domains", [])),
        "time": list(tpl.get("time_phrases", [])),
    }


def _fill(text, pools, rng):
    def repl(m):
        key = m.group(1)
        if key == "account":
            return str(rng.randint(100, 99999))
        return rng.choice(pools[key])
    return PLACEHOLDER.sub(repl, text)


def _vary(text, rng):
    if rng.random() < 0.4:
        text = text.lower()
    if rng.random() < 0.15:
        text = "please " + text
    if rng.random() < 0.1:
        text = text.rstrip("?.!")
    return text


def generate(knowledge, templates=None, per_template=12, seed=7):
    tpl = templates or load_templates()
    rng = random.Random(seed)
    pools = _pools(knowledge, tpl)
    rows, seen, warnings = [], set(), []

    for intent, items in tpl["intents"].items():
        p_urgent = tpl.get("urgent_probability", {}).get(intent, 0.0)
        for t in items:
            needs = set(PLACEHOLDER.findall(t["text"])) - {"account"}
            missing = [k for k in needs if not pools.get(k)]
            if missing:
                warnings.append(f"skipped template {t['id']}: no {', '.join(sorted(missing))} found")
                continue
            has_slots = bool(PLACEHOLDER.search(t["text"]))
            target = per_template if has_slots else 1
            attempts = 0
            made = 0
            while made < target and attempts < target * 20:
                attempts += 1
                text = _vary(_fill(t["text"], pools, rng), rng)
                urgent = "no"
                if rng.random() < p_urgent:
                    if rng.random() < 0.5:
                        text = rng.choice(tpl["urgent_prefixes"]) + text
                    else:
                        text = text + rng.choice(tpl["urgent_suffixes"])
                    urgent = "yes"
                key = text.lower().strip()
                if key in seen:
                    continue
                seen.add(key)
                rows.append({
                    "text": text, "intent": intent, "is_urgent": urgent,
                    "source": "seed", "group": t["group"],
                    "template_id": t["id"], "needs_review": True,
                })
                made += 1
    return rows, warnings


def write_jsonl(rows, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")


def read_jsonl(path):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows
