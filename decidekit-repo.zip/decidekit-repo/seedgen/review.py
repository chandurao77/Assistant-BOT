"""Spot-check a sample of seed rows instead of labeling everything by hand."""
import random
from collections import defaultdict

DEFAULT_INTENTS = ["recall", "search_logs", "explain", "remediate", "investigate", "unclear"]


def pick_sample(rows, fraction=0.15, min_per_intent=5, seed=11):
    """Stratified sample of row indexes: every intent gets checked."""
    rng = random.Random(seed)
    by_intent = defaultdict(list)
    for i, r in enumerate(rows):
        by_intent[r["intent"]].append(i)
    picked = []
    for idxs in by_intent.values():
        k = min(len(idxs), max(min_per_intent, round(len(idxs) * fraction)))
        picked += rng.sample(idxs, k)
    rng.shuffle(picked)
    return picked


def summary(rows):
    accepted = sum(1 for r in rows if r.get("review") == "accepted")
    fixed = sum(1 for r in rows if r.get("review") == "fixed")
    dropped = sum(1 for r in rows if r.get("review") == "dropped")
    checked = accepted + fixed
    return {
        "accepted": accepted, "fixed": fixed, "dropped": dropped,
        "agreement": (accepted / checked) if checked else None,
    }


def review_interactive(rows, idxs, intents=None, input_fn=input, print_fn=print):
    """Walk through sampled rows. Enter accepts; edits are applied in place."""
    intents = intents or DEFAULT_INTENTS
    menu = "  ".join(f"{n + 1}={name}" for n, name in enumerate(intents))
    for n, i in enumerate(idxs, 1):
        r = rows[i]
        if r.get("review"):
            continue
        changed = False
        while True:
            print_fn(f"\n[{n}/{len(idxs)}] {r['text']}")
            print_fn(f"  intent={r['intent']}  urgent={r['is_urgent']}")
            print_fn(f"  Enter=accept  {menu}  u=toggle urgent  d=drop  q=quit")
            cmd = input_fn("> ").strip().lower()
            if cmd == "":
                r["review"] = "fixed" if changed else "accepted"
                r["needs_review"] = False
                break
            if cmd == "q":
                return False
            if cmd == "d":
                r["review"] = "dropped"
                r["needs_review"] = False
                break
            if cmd == "u":
                r["is_urgent"] = "no" if r["is_urgent"] == "yes" else "yes"
                changed = True
                continue
            if cmd.isdigit() and 1 <= int(cmd) <= len(intents):
                r["intent"] = intents[int(cmd) - 1]
                changed = True
                continue
            print_fn("  not recognised")
    return True
