"""seedgen: build starter training data from your own docs and repos."""
