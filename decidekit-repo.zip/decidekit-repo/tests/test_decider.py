import json
import tempfile
import shutil
from pathlib import Path

import pytest

from decidekit.questions import Choice, Score, Noul, question_from_dict
from decidekit.model import Decider


SAMPLE_TEXTS = [
    "show me errors for account 1234 in the last hour",
    "find all timeouts for account 5678 since yesterday",
    "what does error code 503 mean",
    "explain why the gateway returned a 500",
    "restart the activation service for account 91",
    "roll back the last deployment on the billing service",
    "why did account 42 fail activation yesterday",
    "investigate the spike in errors this morning",
    "hi",
    "thanks for the help",
]
SAMPLE_INTENTS = [
    "search_logs", "search_logs", "explain", "explain",
    "remediate", "remediate", "investigate", "investigate",
    "unclear", "unclear",
]
SAMPLE_URGENCY = ["no", "no", "no", "no", "yes", "yes", "yes", "yes", "no", "no"]


@pytest.fixture
def questions():
    return [
        Choice(name="intent", prompt="intent?", options=["recall", "search_logs", "explain", "remediate", "investigate", "unclear"]),
        Noul(name="is_urgent", prompt="urgent?"),
    ]


@pytest.fixture
def labels():
    return {"intent": SAMPLE_INTENTS, "is_urgent": SAMPLE_URGENCY}


def test_choice_roundtrip():
    q = Choice(name="intent", prompt="p", options=["a", "b"])
    d = q.to_dict()
    q2 = question_from_dict(d)
    assert q2.name == q.name
    assert q2.options == q.options


def test_score_roundtrip():
    q = Score(name="s", prompt="p", value_range=(0, 10))
    d = q.to_dict()
    q2 = question_from_dict(d)
    assert q2.value_range == (0, 10)


def test_noul_roundtrip():
    q = Noul(name="n", prompt="p")
    d = q.to_dict()
    q2 = question_from_dict(d)
    assert q2.name == "n"


def test_unknown_type_raises():
    with pytest.raises(ValueError):
        question_from_dict({"type": "bogus", "name": "x", "prompt": "p"})


def test_fit_and_decide_tfidf(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    result = decider.decide("show me errors for account 99")
    assert "intent" in result
    assert "is_urgent" in result
    assert result["intent"]["answer"] in ["recall", "search_logs", "explain", "remediate", "investigate", "unclear"]
    assert 0.0 <= result["intent"]["confidence"] <= 1.0


def test_decide_many(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    results = decider.decide_many(["show me errors", "restart the service"])
    assert len(results) == 2


def test_probabilities_sum_to_one(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    result = decider.decide("restart the activation service")
    total = sum(result["intent"]["probabilities"].values())
    assert abs(total - 1.0) < 1e-6


def test_evaluate(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    scores = decider.evaluate(SAMPLE_TEXTS, labels)
    assert "intent" in scores
    assert scores["intent"]["n"] == len(SAMPLE_TEXTS)


def test_cross_validate_runs(questions, labels):
    decider = Decider(questions, features="tfidf")
    report = decider.cross_validate(SAMPLE_TEXTS, labels, n_splits=2)
    assert "intent" in report
    assert "threshold_table" in report["intent"]
    assert "suggested_threshold" in report["intent"]


def test_save_and_load_roundtrip(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    tmpdir = tempfile.mkdtemp()
    try:
        decider.save(tmpdir)
        loaded = Decider.load(tmpdir)
        result = loaded.decide("show me errors for account 1")
        assert "intent" in result
    finally:
        shutil.rmtree(tmpdir)


def test_explain_tfidf_mode(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    explanation = decider.explain("show me errors for account 1", "intent")
    assert "answer" in explanation
    assert "top_features" in explanation


def test_explain_raises_in_embeddings_mode(questions, labels):
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, labels)
    decider.features = "embeddings"  # simulate wrong mode without downloading model
    with pytest.raises(Exception):
        decider.explain("test", "does_not_exist_question")


def test_decide_before_fit_raises(questions):
    decider = Decider(questions, features="tfidf")
    with pytest.raises(RuntimeError):
        decider.decide("test")


def test_partial_labels_only_trains_available_questions():
    questions = [Choice(name="intent", prompt="p", options=["a", "b", "c", "d", "e", "f"])]
    decider = Decider(questions, features="tfidf")
    decider.fit(SAMPLE_TEXTS, {"intent": SAMPLE_INTENTS})
    result = decider.decide("test text")
    assert "intent" in result


class _FakeEmbedder:
    """Stands in for fastembed so tests never download a model."""
    def embed(self, texts):
        import numpy as np
        for t in texts:
            v = np.zeros(32)
            for i, ch in enumerate(t.lower()):
                v[(ord(ch) + i) % 32] += 1.0
            yield v / (np.linalg.norm(v) or 1.0)


def test_embeddings_mode_saves_loads_and_cross_validates(questions, labels, monkeypatch, tmp_path):
    from decidekit import model as model_mod
    monkeypatch.setitem(model_mod._MODELS, "BAAI/bge-small-en-v1.5", _FakeEmbedder())
    monkeypatch.setattr(model_mod, "_EMBED_CACHE", {})
    decider = Decider(questions, features="embeddings")
    decider.fit(SAMPLE_TEXTS, labels)
    decider.save(tmp_path)                       # used to crash: unpicklable ONNX session
    loaded = Decider.load(tmp_path)
    assert "intent" in loaded.decide("show me errors for account 5")
    report = Decider(questions, features="embeddings").cross_validate(SAMPLE_TEXTS, labels, n_splits=2)
    assert "intent" in report                    # used to fail: sklearn could not clone
