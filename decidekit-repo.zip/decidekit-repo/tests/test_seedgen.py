import json
import re
from pathlib import Path

import pytest

from seedgen.scan import scan, spoken
from seedgen.generate import generate
from seedgen.review import pick_sample, review_interactive, summary
from seedgen.build import build

ROOT = Path(__file__).resolve().parent.parent
KB = str(ROOT / "examples" / "sample_kb")
REPO = str(ROOT / "examples" / "sample_repo")


@pytest.fixture(scope="module")
def knowledge():
    return scan([KB], [REPO], domains=["activation", "billing"])


def test_scan_finds_codes_with_meanings(knowledge):
    codes = {c["code"]: c["meaning"] for c in knowledge["error_codes"]}
    assert "ACT-1001" in codes and "timed out" in codes["ACT-1001"].lower()
    assert "BIL-2001" in codes
    assert "ACT-1003" in codes                     # heading style
    assert "503" in codes                          # HTTP 503


def test_scan_finds_services(knowledge):
    names = {s["name"]: s["kind"] for s in knowledge["services"]}
    assert names["ActivationGatewayFunction"] == "lambda"        # yaml
    assert names["BillingRunStateMachine"] == "state_machine"    # yaml
    assert names["ValidateAccountFn"] == "lambda"                # ASL arn
    assert names["Validate Account"] == "step"                   # ASL state
    assert names["activation_gateway"] == "lambda"               # python handler


def test_spoken_names():
    assert spoken("ActivationGatewayFunction") == "activation gateway"
    assert spoken("billing-run_worker") == "billing run worker"


def test_generate_only_uses_known_terms(knowledge):
    rows, _ = generate(knowledge, per_template=5)
    known = {c["code"] for c in knowledge["error_codes"]}
    pat = re.compile(r"\b[A-Z]{2,8}-\d{2,6}\b")
    seen = set()
    for r in rows:
        seen.update(pat.findall(r["text"].upper()))
    assert seen and seen <= {k.upper() for k in known}


def test_generate_valid_labels_and_deterministic(knowledge):
    a, _ = generate(knowledge, per_template=4, seed=3)
    b, _ = generate(knowledge, per_template=4, seed=3)
    assert a == b
    assert {r["intent"] for r in a} == {"recall", "search_logs", "explain",
                                       "remediate", "investigate", "unclear"}
    assert all(r["is_urgent"] in ("yes", "no") for r in a)
    assert all(r["needs_review"] for r in a)


def test_generate_skips_templates_without_data():
    empty = {"error_codes": [], "services": [], "domains": []}
    rows, warnings = generate(empty, per_template=3)
    assert warnings
    assert all("{" not in r["text"] for r in rows)
    intents = {r["intent"] for r in rows}
    assert "unclear" in intents                       # placeholder-free templates still work
    assert not intents & {"explain", "remediate"}     # every template there needs a real term


def test_review_sample_covers_every_intent(knowledge):
    rows, _ = generate(knowledge, per_template=6)
    idx = pick_sample(rows, fraction=0.1, min_per_intent=3)
    assert {rows[i]["intent"] for i in idx} == {r["intent"] for r in rows}


def test_review_interactive_accept_fix_drop():
    rows = [
        {"text": "a", "intent": "search_logs", "is_urgent": "no"},
        {"text": "b", "intent": "search_logs", "is_urgent": "no"},
        {"text": "c", "intent": "search_logs", "is_urgent": "no"},
    ]
    answers = iter(["", "3", "", "d"])   # accept a; change b to explain(3); accept; drop c
    review_interactive(rows, [0, 1, 2], input_fn=lambda _: next(answers), print_fn=lambda *_: None)
    assert rows[0]["review"] == "accepted"
    assert rows[1]["review"] == "fixed" and rows[1]["intent"] == "explain"
    assert rows[2]["review"] == "dropped"
    s = summary(rows)
    assert s["agreement"] == 0.5


def _seed(intent, group, text, review=None):
    r = {"text": text, "intent": intent, "is_urgent": "no", "group": group, "source": "seed"}
    if review:
        r["review"] = review
    return r


def test_build_keeps_seed_out_of_test(tmp_path):
    seed = [_seed("explain", "train", "s1"), _seed("explain", "holdout", "s2"),
            _seed("recall", "train", "s3", review="dropped")]
    real = [{"text": f"real query {i}", "intent": "search_logs", "is_urgent": "no"} for i in range(200)]
    res = build(seed, real, tmp_path, test_pct=30)
    train = [json.loads(l) for l in (tmp_path / "train.jsonl").read_text().splitlines()]
    test = [json.loads(l) for l in (tmp_path / "test.jsonl").read_text().splitlines()]
    holdout = [json.loads(l) for l in (tmp_path / "seed_holdout.jsonl").read_text().splitlines()]
    assert all(r["source"] == "real" for r in test)          # test is real only
    assert {r["text"] for r in test}.isdisjoint({r["text"] for r in train})
    assert len(test) + sum(r["source"] == "real" for r in train) == 200
    assert len(holdout) == 1 and holdout[0]["text"] == "s2"
    assert all(r["text"] != "s3" for r in train)             # dropped row excluded
    assert 40 <= len(test) <= 80                             # roughly 30%


def test_build_warns_without_real_data(tmp_path):
    res = build([_seed("explain", "train", "s1")], [], tmp_path)
    assert res["real_test"] == 0
    assert res["warnings"]
    assert not (tmp_path / "test.jsonl").exists()
