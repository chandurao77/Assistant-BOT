# decidekit

Small local classifiers that answer structured questions about a piece of text
("what is the user's intent?", "is this urgent?") in milliseconds, with a confidence
score, without calling an LLM. Inspired by TypeSafe's Jev, but trained on your own
examples and running entirely on your machine.

Built for QueryQuokka: route a query to `recall`, `search_logs`, `explain`,
`remediate`, `investigate` or `unclear`, and send low-confidence ones to a person or a full LLM.

## The idea in one picture

    your docs + repos  --seedgen-->  starter training rows (seed)   \
                                                                     >-- decidekit train --> model
    real queries (you label)  ------------------------------------ /
              \
               +--> also the TEST set: the only honest accuracy number

Seed data gets the model started. **Real queries you label yourself are what tell you whether it works.**

## What's in here

| Folder / file | Purpose |
|---|---|
| `decidekit/` | The library: question types, trainable `Decider`, CLI (`train`, `cv`, `eval`, `predict`) |
| `seedgen/` | Builds seed data from your markdown/PDF knowledge base and cloned repos |
| `mcp_bridge/` | Adapter for your internal flow MCP server (LLM gateway -> Kibana). You fill in one method |
| `label_from_mcp.py` | Interactive labeling of real queries (from MCP or a text file) |
| `.github/copilot-instructions.md` | Rules GitHub Copilot follows in this repo |
| `.github/prompts/` | Copilot task prompts: `/setup-repo`, `/wire-mcp`, `/build-seed-data` |
| `examples/` | `questions.json`, plus a small FAKE knowledge base and repo for smoke testing |
| `tests/` | 25 tests (no model download needed) |

## Quick start (manual)

    python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    python -m pytest tests/ -q

Try the whole pipeline on the fake sample data first:

    cp seedgen.config.example.json seedgen.config.json      # points at examples/ by default
    python -m seedgen scan
    python -m seedgen generate
    python -m seedgen review
    python -m seedgen build
    python -m decidekit train --questions examples/questions.json --data data/labeled/train.jsonl --out models/current
    python -m decidekit predict --model models/current --text "fetch me the gateway activation for the last 24 hours"

The first run with the default `embeddings` features downloads a ~130 MB model once (needs
network); after that everything is offline. Add `--features tfidf` to skip the download
(less accurate on new phrasing).

## Quick start (with GitHub Copilot)

Open the folder in VS Code with Copilot Chat in **agent mode**. Copilot reads
`.github/copilot-instructions.md` automatically. Then run these in chat, in order:

1. `/setup-repo`: creates the venv, installs, runs tests.
2. `/wire-mcp`: finds how your internal MCP server is called in your local repos and fills in `mcp_bridge`.
3. `/build-seed-data`: locates your docs and repos, scans them, generates seed rows, hands review to you, trains, evaluates.

If a `/` command doesn't show up, your Copilot version may want `mode:` instead of `agent:` in the
prompt file header; you can also paste the body of a prompt file into chat.

## Building seed data from your docs and repos

`seedgen.config.json` (copy from the example, gitignored):

    {
      "doc_roots":  ["C:/path/to/queryquokka/docs", "C:/path/to/knowledge-base"],
      "repo_roots": ["C:/path/to/cloned/repos"],
      "domains":    ["activation", "billing"],
      "error_code_patterns": [],
      "max_items": 300
    }

- `scan` reads `.md`, `.txt`, `.pdf` (needs `pypdf`), and code/config files. It extracts error codes
  with a short meaning, and service names from SAM/CloudFormation templates, Step Functions
  definitions (`.asl.json`), Python `lambda_handler` files, and Java `*Handler/*Service` classes.
  It writes `data/seed/knowledge.json`. **Open it and delete junk** before generating.
  Error code formats differ by team: add regexes under `error_code_patterns`.
- `generate` fills the templates in `seedgen/templates.json` with those real terms. Edit the
  templates to match how your users actually phrase things. Templates marked `holdout` are kept
  out of training so you can test on unseen phrasing.
- `review` shows a stratified ~15% sample. Press Enter to accept, a number to change the intent,
  `u` to flip urgency, `d` to drop. It reports how often the template labels were right. If that is
  under 90%, fix the templates.
- `build` writes `data/labeled/train.jsonl`, `seed_holdout.jsonl`, and `test.jsonl`.

### About the labels

Seed labels come from the template, not from understanding the docs, and the urgency label is
synthetic (added phrases like "asap"). The docs tell the model which error codes and services
exist; they can't tell it how your users phrase things. That is why real queries matter.

## Real queries (the important part)

    python label_from_mcp.py --domain activation --hours 24 --limit 100     # via your MCP bridge
    python label_from_mcp.py --from-file my_real_queries.txt                # or a text file, one per line

You choose the label for each one; answers save as you go to `data/real/labeled.jsonl`.
`seedgen build` splits these ~70/30 into train and test (stable per query). Aim for 30+ real test
rows at minimum, a few hundred real rows overall, and at least 20 per intent.

    python -m decidekit eval --model models/current --data data/labeled/test.jsonl

**This is the number to trust.** Accuracy on `seed_holdout.jsonl` is optimistic (still template
phrasing), and random-split cross-validation on seed data will look near-perfect because rows are
near-duplicates.

## Wiring the MCP bridge

`mcp_bridge/client.py` doesn't know your server. Either run `/wire-mcp` in Copilot, or fill in
`_call_mcp_tool` (transport, tool name, arguments) and check `_normalize` (response shape) yourself.
Copy `.env.example` to `.env` for URL/token/tool name. Keep secrets in env vars only.

## Feature modes

- `embeddings` (default): local sentence embeddings (fastembed, BAAI/bge-small-en-v1.5). More
  accurate on new phrasing. On the fake sample data, held-out-phrasing accuracy was about 87% for
  intent versus 61% for tfidf.
- `tfidf`: no download; supports `Decider.explain()` (top contributing words).

## Limitations

- No reasoning, arithmetic, or long documents. Short text in, label out.
- Confidence is only as good as the evaluation data. A term the training data never touched
  (a new error code, a new service) can still get a confident wrong answer. Retrain as your
  systems and phrasing change.
- Pick your confidence threshold from `cv`/`eval` tables on real data, and send anything below it
  to a person or an LLM.

## Data handling

Everything runs locally and `data/`, `models/`, `.env`, and `seedgen.config.json` are gitignored.
Still, check your company's policy before copying production logs or queries to local files, and
prefer anonymized examples.
