"""Decider: trains and runs small local classifiers per question."""
import json
from pathlib import Path
import numpy as np
import joblib

from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict

from .questions import Choice, Score, Noul, question_from_dict


_MODELS = {}        # model_name -> loaded fastembed model (never pickled)
_EMBED_CACHE = {}   # (model_name, text) -> vector; speeds up CV and repeat questions


class _EmbeddingVectorizer(BaseEstimator, TransformerMixin):
    """fastembed as a sklearn transformer.

    Holds only the model NAME, so it pickles and clones cleanly. The loaded
    model lives in a module-level cache.
    """

    def __init__(self, model_name="BAAI/bge-small-en-v1.5"):
        self.model_name = model_name

    def _load(self):
        if self.model_name not in _MODELS:
            from fastembed import TextEmbedding
            _MODELS[self.model_name] = TextEmbedding(model_name=self.model_name)
        return _MODELS[self.model_name]

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = list(X)
        missing = [t for t in dict.fromkeys(X) if (self.model_name, t) not in _EMBED_CACHE]
        if missing:
            for t, v in zip(missing, self._load().embed(missing)):
                _EMBED_CACHE[(self.model_name, t)] = np.asarray(v)
        return np.vstack([_EMBED_CACHE[(self.model_name, t)] for t in X])


def _make_pipeline(features: str):
    if features == "embeddings":
        vectorizer = _EmbeddingVectorizer()
    elif features == "tfidf":
        vectorizer = TfidfVectorizer(ngram_range=(1, 2), analyzer="word", min_df=1)
    else:
        raise ValueError(f"Unknown features mode: {features}")
    clf = LogisticRegression(max_iter=1000)
    return Pipeline([("features", vectorizer), ("clf", clf)])


class Decider:
    def __init__(self, questions, features="embeddings"):
        self.questions = questions
        self.features = features
        self._pipelines = {}
        self._is_fit = False

    def fit(self, texts, labels_by_question):
        for q in self.questions:
            if q.name not in labels_by_question:
                continue
            y = labels_by_question[q.name]
            pipe = _make_pipeline(self.features)
            pipe.fit(texts, y)
            self._pipelines[q.name] = pipe
        self._is_fit = True
        return self

    def decide(self, text):
        if not self._is_fit:
            raise RuntimeError("Decider has not been fit yet.")
        result = {}
        for q in self.questions:
            pipe = self._pipelines.get(q.name)
            if pipe is None:
                continue
            proba = pipe.predict_proba([text])[0]
            classes = pipe.named_steps["clf"].classes_
            best_idx = int(np.argmax(proba))
            result[q.name] = {
                "answer": classes[best_idx],
                "confidence": float(proba[best_idx]),
                "probabilities": {str(c): float(p) for c, p in zip(classes, proba)},
            }
        return result

    def decide_many(self, texts):
        return [self.decide(t) for t in texts]

    def cross_validate(self, texts, labels_by_question, n_splits=5, thresholds=None):
        if thresholds is None:
            thresholds = [0.5, 0.6, 0.7, 0.8, 0.9]
        report = {}
        texts = list(texts)
        for q in self.questions:
            if q.name not in labels_by_question:
                continue
            y = np.array(labels_by_question[q.name])
            pipe = _make_pipeline(self.features)
            min_class_count = min(np.bincount(np.unique(y, return_inverse=True)[1]))
            skf = StratifiedKFold(n_splits=min(n_splits, min_class_count), shuffle=True, random_state=42)
            proba = cross_val_predict(pipe, texts, y, cv=skf, method="predict_proba")
            classes = np.unique(y)
            preds_idx = np.argmax(proba, axis=1)
            preds = classes[preds_idx]
            confidences = proba[np.arange(len(proba)), preds_idx]
            overall_acc = float(np.mean(preds == y))

            table = []
            for t in thresholds:
                mask = confidences >= t
                coverage = float(np.mean(mask))
                if mask.sum() > 0:
                    acc_at_t = float(np.mean(preds[mask] == y[mask]))
                else:
                    acc_at_t = None
                table.append({"threshold": t, "coverage": coverage, "accuracy": acc_at_t})

            suggested = 0.5
            for row in table:
                if row["accuracy"] is not None and row["accuracy"] >= 0.9 and row["coverage"] >= 0.5:
                    suggested = row["threshold"]

            report[q.name] = {
                "overall_accuracy": overall_acc,
                "threshold_table": table,
                "suggested_threshold": suggested,
            }
        return report

    def evaluate(self, texts, labels_by_question):
        results = {}
        for q in self.questions:
            if q.name not in labels_by_question:
                continue
            pipe = self._pipelines.get(q.name)
            if pipe is None:
                continue
            y_true = labels_by_question[q.name]
            y_pred = pipe.predict(list(texts))
            acc = float(np.mean(np.array(y_pred) == np.array(y_true)))
            results[q.name] = {"accuracy": acc, "n": len(y_true)}
        return results

    def explain(self, text, question_name, top_k=8):
        pipe = self._pipelines.get(question_name)
        if pipe is None:
            raise ValueError(f"No trained pipeline for question {question_name}")
        vectorizer = pipe.named_steps["features"]
        if not isinstance(vectorizer, TfidfVectorizer):
            raise RuntimeError("explain() only works in tfidf feature mode")
        clf = pipe.named_steps["clf"]
        x = vectorizer.transform([text])
        feature_names = np.array(vectorizer.get_feature_names_out())
        proba = clf.predict_proba(x)[0]
        best_idx = int(np.argmax(proba))
        label = clf.classes_[best_idx]
        coefs = clf.coef_[best_idx] if clf.coef_.shape[0] > 1 else clf.coef_[0]
        nz = x.nonzero()[1]
        contributions = [(feature_names[i], x[0, i] * coefs[i]) for i in nz]
        contributions.sort(key=lambda t: -abs(t[1]))
        return {"answer": label, "top_features": contributions[:top_k]}

    def save(self, path):
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        joblib.dump(self._pipelines, path / "pipelines.joblib")
        with open(path / "questions.json", "w") as f:
            json.dump([q.to_dict() for q in self.questions], f, indent=2)
        with open(path / "meta.json", "w") as f:
            json.dump({"features": self.features}, f)

    @staticmethod
    def load(path):
        path = Path(path)
        with open(path / "questions.json") as f:
            questions = [question_from_dict(d) for d in json.load(f)]
        with open(path / "meta.json") as f:
            meta = json.load(f)
        decider = Decider(questions, features=meta.get("features", "embeddings"))
        decider._pipelines = joblib.load(path / "pipelines.joblib")
        decider._is_fit = True
        return decider
