"""Question type definitions for decidekit.

Three kinds of structured questions:
- Choice: pick one label from a fixed set (e.g. intent classification)
- Score: a numeric value in a range
- Noul: a yes/no question
"""
from dataclasses import dataclass
from typing import List, Tuple, Union


@dataclass
class Choice:
    name: str
    prompt: str
    options: List[str]

    def to_dict(self):
        return {"type": "choice", "name": self.name, "prompt": self.prompt, "options": self.options}

    @staticmethod
    def from_dict(d):
        return Choice(name=d["name"], prompt=d["prompt"], options=d["options"])


@dataclass
class Score:
    name: str
    prompt: str
    value_range: Tuple[float, float] = (0.0, 1.0)

    def to_dict(self):
        return {"type": "score", "name": self.name, "prompt": self.prompt, "value_range": list(self.value_range)}

    @staticmethod
    def from_dict(d):
        return Score(name=d["name"], prompt=d["prompt"], value_range=tuple(d.get("value_range", [0.0, 1.0])))


@dataclass
class Noul:
    name: str
    prompt: str

    def to_dict(self):
        return {"type": "noul", "name": self.name, "prompt": self.prompt}

    @staticmethod
    def from_dict(d):
        return Noul(name=d["name"], prompt=d["prompt"])


Question = Union[Choice, Score, Noul]


def question_from_dict(d):
    t = d.get("type")
    if t == "choice":
        return Choice.from_dict(d)
    if t == "score":
        return Score.from_dict(d)
    if t == "noul":
        return Noul.from_dict(d)
    raise ValueError(f"Unknown question type: {t}")
