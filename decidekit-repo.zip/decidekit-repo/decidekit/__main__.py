"""Command line interface for decidekit.

Usage:
    python -m decidekit train --questions examples/questions.json --data data/labeled/train.jsonl --out models/current
    python -m decidekit cv --questions examples/questions.json --data data/labeled/train.jsonl
    python -m decidekit eval --model models/current --data data/labeled/test.jsonl
    python -m decidekit predict --model models/current --text "fetch me the gateway activation for the last 24 hours"
"""
import argparse
import json
import sys

from .questions import question_from_dict
from .model import Decider


def _load_jsonl(path):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _rows_to_texts_and_labels(rows, questions):
    texts = [r["text"] for r in rows]
    labels_by_question = {}
    for q in questions:
        if all(q.name in r for r in rows):
            labels_by_question[q.name] = [r[q.name] for r in rows]
    return texts, labels_by_question


def cmd_train(args):
    with open(args.questions) as f:
        questions = [question_from_dict(d) for d in json.load(f)]
    rows = _load_jsonl(args.data)
    texts, labels_by_question = _rows_to_texts_and_labels(rows, questions)
    decider = Decider(questions, features=args.features)
    decider.fit(texts, labels_by_question)
    decider.save(args.out)
    print(f"Trained on {len(texts)} rows. Saved to {args.out}")


def cmd_cv(args):
    with open(args.questions) as f:
        questions = [question_from_dict(d) for d in json.load(f)]
    rows = _load_jsonl(args.data)
    texts, labels_by_question = _rows_to_texts_and_labels(rows, questions)
    decider = Decider(questions, features=args.features)
    report = decider.cross_validate(texts, labels_by_question)
    print(json.dumps(report, indent=2))


def cmd_eval(args):
    decider = Decider.load(args.model)
    rows = _load_jsonl(args.data)
    texts, labels_by_question = _rows_to_texts_and_labels(rows, decider.questions)
    results = decider.evaluate(texts, labels_by_question)
    print(json.dumps(results, indent=2))


def cmd_predict(args):
    decider = Decider.load(args.model)
    result = decider.decide(args.text)
    print(json.dumps(result, indent=2))


def main():
    parser = argparse.ArgumentParser(prog="decidekit")
    sub = parser.add_subparsers(dest="command", required=True)

    p_train = sub.add_parser("train")
    p_train.add_argument("--questions", required=True)
    p_train.add_argument("--data", required=True)
    p_train.add_argument("--out", required=True)
    p_train.add_argument("--features", default="embeddings", choices=["embeddings", "tfidf"])
    p_train.set_defaults(func=cmd_train)

    p_cv = sub.add_parser("cv")
    p_cv.add_argument("--questions", required=True)
    p_cv.add_argument("--data", required=True)
    p_cv.add_argument("--features", default="embeddings", choices=["embeddings", "tfidf"])
    p_cv.set_defaults(func=cmd_cv)

    p_eval = sub.add_parser("eval")
    p_eval.add_argument("--model", required=True)
    p_eval.add_argument("--data", required=True)
    p_eval.set_defaults(func=cmd_eval)

    p_predict = sub.add_parser("predict")
    p_predict.add_argument("--model", required=True)
    p_predict.add_argument("--text", required=True)
    p_predict.set_defaults(func=cmd_predict)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
