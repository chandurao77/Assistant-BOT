def lambda_handler(event, context):
    # FAKE sample handler
    raise RuntimeError("ACT-1001 activation timed out")
