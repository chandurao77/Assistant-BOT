# Sample error code reference (FAKE DATA for smoke testing only)

| Code | Meaning |
|---|---|
| ACT-1001 | Activation request timed out at the gateway |
| ACT-1002 | Device is not provisioned for activation |
| BIL-2001 | Duplicate charge detected during billing run |

## ACT-1003: Gateway returned malformed response

The activation gateway sent a payload that failed schema validation.

## Status codes

HTTP 503 from the gateway means the upstream service is unavailable.
