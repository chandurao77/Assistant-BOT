# decidekit: instructions for GitHub Copilot

## What this repo is
decidekit trains small local classifiers (scikit-learn on local sentence embeddings) that answer
structured questions about a short piece of text, for example "what is the user's intent" or
"is this urgent". It is being built for QueryQuokka (an AI log investigation platform) so the
router can classify a query in milliseconds instead of calling an LLM. Everything runs locally.

## Layout
- `decidekit/`: the library (`questions.py`, `model.py`, CLI in `__main__.py`).
- `seedgen/`: builds starter training data from our docs and repos (`scan`, `generate`, `review`, `build`).
- `mcp_bridge/`: adapter for our internal flow MCP server (LLM gateway -> Kibana logs). All MCP calls live in `_call_mcp_tool`.
- `label_from_mcp.py`: interactive labeling of real queries (from MCP or a text file).
- `examples/questions.json`: the questions (intent, is_urgent). Options must match the labels in data.
- `.github/prompts/`: task prompts. Run them with `/setup-repo`, `/wire-mcp`, `/build-seed-data`.

## Commands
- Tests: `python -m pytest tests/ -q` (uses tfidf or a fake embedder; must not need a model download)
- Seed data: `python -m seedgen scan | generate | review | build`
- Train: `python -m decidekit train --questions examples/questions.json --data data/labeled/train.jsonl --out models/current`
- Honest accuracy: `python -m decidekit eval --model models/current --data data/labeled/test.jsonl`

## Rules

1. **Look things up before asking me.** If you need an error code's meaning, a service name, a domain,
   or how our internal MCP server is called, search first: the doc and repo folders in
   `seedgen.config.json` (local clones of our repos, lambdas, step functions and the knowledge-base
   markdown), and any MCP tools available in this workspace. Only ask me if you still can't find it,
   and tell me what you searched.
2. **Never invent** error codes, service names, domains, or their meanings. If you can't find a term,
   leave it out. A template that needs a missing term is skipped, not filled with a guess.
3. **Data stays local.** Never send logs, queries, or documents to an external service, and never
   paste them into chat output beyond a few short examples. Never commit `data/`, `models/`, `.env`,
   or `seedgen.config.json` (they are in `.gitignore`). Read secrets from environment variables only.
4. **Seed data is not real data.** Seed rows come from templates and carry `source: seed`. The test
   set (`data/labeled/test.jsonl`) must contain only real user queries, labeled by a person. Never
   move seed rows into the test set. Report accuracy from `test.jsonl` only, and say when there
   are too few real rows to trust it.
5. **Confidence is not correctness.** When suggesting thresholds, base them on the `cv`/`eval`
   tables from real data, and explain that out-of-vocabulary terms can still give confident wrong answers.
6. **Keep changes small and tested.** Run the test suite after each change. Do not add heavy
   dependencies without asking. Keep the MCP transport code isolated in `mcp_bridge/client.py`.
7. **Be plain about problems.** If something fails or a number looks too good (for example 100%
   accuracy from random-split cross-validation on near-duplicate rows), say so instead of smoothing it over.
