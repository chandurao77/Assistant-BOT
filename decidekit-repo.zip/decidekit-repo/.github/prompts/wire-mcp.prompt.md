---
description: 'Fill in mcp_bridge so it pulls real queries from our internal flow MCP server'
agent: 'agent'
---
Wire `mcp_bridge/client.py` to our internal flow MCP server (the one that connects to the LLM
gateway and pulls Kibana logs across domains).

Look it up yourself first. Search the local repos listed in `seedgen.config.json`, and any MCP
tools available in this workspace, for how that server is called: transport (HTTP or stdio),
URL or command, tool names, tool arguments, response shape, and how auth works.

Then:
1. Implement `_call_mcp_tool` and adjust `_normalize` so `fetch_recent(domain, hours, limit)` returns
   a list of dicts that each have a `text` field (the user's query text).
2. Put URL, tool name, and default domain in environment variables (see `.env.example`). Never
   hardcode a token or secret.
3. Before pulling anything from production, show me the exact call you plan to make and wait for
   my OK. Then pull a small sample (limit 5) and show me only the shape, not the full content.
4. Note in the README anything about data handling I should confirm with my team.

If you cannot find how the server is called, tell me exactly what you searched and what is missing.
