---
description: 'Build seed training data from our docs and repos, then train and evaluate'
agent: 'agent'
---
Build starter training data for decidekit from our own documentation and repos.

Look things up yourself; do not ask me for information that is in the local folders.

1. Create `seedgen.config.json` from `seedgen.config.example.json`. Find the local paths yourself:
   the QueryQuokka repo and its markdown/PDF knowledge base (error codes and failure meanings), the
   org repos, lambdas and step functions I have cloned locally. Set `doc_roots`, `repo_roots`, and
   `domains`. If you cannot locate a folder, list what you searched and ask me for that one path.
2. Run `python -m seedgen scan`. Open `data/seed/knowledge.json` and look for junk (numbers that
   are not error codes, generic class names). Fix it by tightening `error_code_patterns` or editing
   the config, then rescan. Show me the 15 most useful error codes and services you found.
3. Read `seedgen/templates.json`. Compare it with how real QueryQuokka queries are phrased (look in
   the repo for example queries, tests, or docs). Add or reword templates so they sound like real
   users. Keep some templates in group `holdout`.
4. Run `python -m seedgen generate`, then tell me how many rows per intent.
5. Stop and hand review to me: run `python -m seedgen review` for me to spot-check about 15%.
   Do not auto-accept rows on my behalf.
6. After I finish, run `python -m seedgen build`, then train:
   `python -m decidekit train --questions examples/questions.json --data data/labeled/train.jsonl --out models/current`
   and evaluate on `data/labeled/seed_holdout.jsonl`.
7. Report accuracy, and be clear that seed_holdout is optimistic. The trustworthy number comes from
   `data/labeled/test.jsonl`, which needs real queries labeled by me (`python label_from_mcp.py`).
   Tell me how many more real queries I need.

Never invent error codes or service names. Never send any data outside this machine.
