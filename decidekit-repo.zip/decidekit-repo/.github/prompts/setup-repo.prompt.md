---
description: 'Set up the Python environment and confirm decidekit works'
agent: 'agent'
---
Set up this repo on my machine.

1. Create a virtual environment in `.venv` and install `requirements.txt`.
2. Run `python -m pytest tests/ -q` and show me the result. All tests should pass.
3. Run one smoke test with `--features tfidf` (no model download): train on a few rows, then run `predict`.
4. Tell me the exact command to activate the venv for my OS and shell.

If any step fails, fix it if it is an environment problem, and tell me plainly what you changed.
Do not download the embedding model yet. First run of `--features embeddings` downloads about
130 MB once; tell me before that happens in case my network policy blocks it.
