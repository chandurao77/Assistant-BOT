"""
Interactive helper: pull real query/log records via the MCP bridge,
then label them one by one to build a decidekit training file.

Run it like:
    python label_from_mcp.py --domain activation --hours 24 --limit 100
    python label_from_mcp.py --from-file my_real_queries.txt

It will:
  1. Pull records from your internal MCP server via mcp_bridge.
  2. Show you each one's text.
  3. Ask you to type the correct answer for each configured question.
  4. Append each labeled row as one line of JSON to your output file.

You can stop at any time with Ctrl+C -- everything labeled so far is
already saved, since each row is written immediately after you answer it.
"""
import argparse
import json
import sys

from mcp_bridge import MCPLogBridge, MCPBridgeConfig
from decidekit.questions import question_from_dict, Choice, Noul


def load_questions(path):
    with open(path) as f:
        return [question_from_dict(d) for d in json.load(f)]


def prompt_for_label(question):
    if isinstance(question, Choice):
        options_str = ", ".join(f"{i+1}) {opt}" for i, opt in enumerate(question.options))
        while True:
            raw = input(f"  {question.prompt} [{options_str}]: ").strip()
            if raw.isdigit() and 1 <= int(raw) <= len(question.options):
                return question.options[int(raw) - 1]
            if raw in question.options:
                return raw
            print("  Please enter a number from the list or the exact option text.")
    elif isinstance(question, Noul):
        while True:
            raw = input(f"  {question.prompt} [y/n]: ").strip().lower()
            if raw in ("y", "yes"):
                return "yes"
            if raw in ("n", "no"):
                return "no"
            print("  Please answer y or n.")
    else:
        raw = input(f"  {question.prompt} (number): ").strip()
        return float(raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--questions", default="examples/questions.json")
    parser.add_argument("--domain", default=None)
    parser.add_argument("--hours", type=int, default=24)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--out", default="data/real/labeled.jsonl")
    parser.add_argument("--from-file", default=None,
                        help="Plain text file, one real query per line (skips the MCP pull)")
    args = parser.parse_args()

    questions = load_questions(args.questions)
    if args.from_file:
        with open(args.from_file) as f:
            records = [{"text": line.strip()} for line in f if line.strip()]
        records = records[: args.limit]
    else:
        bridge = MCPLogBridge(MCPBridgeConfig.from_env())
        print(f"Pulling up to {args.limit} records for domain={args.domain}, last {args.hours}h...")
        records = bridge.fetch_recent(domain=args.domain, hours=args.hours, limit=args.limit)
    print(f"Got {len(records)} records. Starting labeling. Ctrl+C to stop early; progress is saved as you go.\n")

    with open(args.out, "a") as out_f:
        for i, record in enumerate(records):
            text = record.get("text", "").strip()
            if not text:
                continue
            print(f"[{i+1}/{len(records)}] {text}")
            row = {"text": text}
            try:
                for q in questions:
                    row[q.name] = prompt_for_label(q)
            except KeyboardInterrupt:
                print("\nStopped early. Progress saved.")
                sys.exit(0)
            out_f.write(json.dumps(row) + "\n")
            out_f.flush()
            print()

    print(f"Done. Labeled rows appended to {args.out}")


if __name__ == "__main__":
    main()
