# QueryQuokka — Topic Investigation UI: implementation prompt

Use this as a self-contained brief for a developer or coding agent. It describes the
redesigned Topic Investigation view, its information architecture, design tokens, and
every component with the real data shapes.

---

## 1. Goal

Rebuild the QueryQuokka topic-investigation page so an on-call engineer can answer three
questions in the first screenful: **what broke, where, and how bad**. Evidence (errors,
services, accounts, raw query) moves behind tabs so each screen has one job.

Problems in the old UI that this fixes:

| Problem | Fix |
|---|---|
| Everything looks equally important | One verdict card with a severity rail; all other panels are visually quieter |
| Bars unreadable — `≥10,000` clipped with no scale | Index-wide signatures get a shared 10,000 ceiling, a hatched cap marker, and a linear/log scale toggle |
| Too much repeated raw log text | Error list split into *index-wide signatures* vs *in-sample message frequency* (they were two different scales in one list) |
| Card-in-card nesting | Flat panels, single border, no nested cards |
| Too pale / low contrast | Token-based dark + light themes with real text contrast |
| Service name chips repeat everywhere | One colour per service, assigned once, reused in every bar, chain node, dot and legend |
| Can't tell which section to act on | Recommendations are a numbered action list with an "Open evidence" affordance per row |

---

## 2. Screens

1. **Investigations** (list/history) — table: topic, failure boundary, severity, matches, accounts, run time.
2. **New investigation** — topic textarea, time-range segmented control (24h / 7d / 30d / custom), index display, "Run investigation", recent-topic chips.
3. **Topic investigation detail** — the main screen. Tabs: `Overview · Errors · Services · Accounts · Query`.

Left rail (252px, sticky, full height): brand mark, nav (Investigations, New investigation),
RECENT list (severity dot + title + meta), footer with theme toggle and "Spec notes" toggle.

---

## 3. Design tokens

Set as CSS custom properties on the app shell, switched by `data-theme`.

```css
[data-theme="dark"]{
  --bg:#0B0E12; --panel:#12161C; --panel2:#171C23;
  --line:#222933; --line2:#2C3540;
  --fg:#E7ECF3; --fg2:#9AA6B4; --fg3:#6B7684;
  --hi:#22C8A8; --hiSoft:rgba(34,200,168,.14);
  --sev:#FF5F63; --sevBg:rgba(255,95,99,.10);
  --warn:#F0A83C; --ok:#3FD0A0; --info:#5B8DEF;
  --track:rgba(255,255,255,.06); --hatch:rgba(255,255,255,.22);
}
[data-theme="light"]{
  --bg:#F4F6F8; --panel:#FFFFFF; --panel2:#F8FAFB;
  --line:#E3E7EC; --line2:#D2D9E0;
  --fg:#0F1519; --fg2:#55616E; --fg3:#7C8894;
  --hi:#0E9E85; --hiSoft:rgba(14,158,133,.10);
  --sev:#D63B41; --sevBg:rgba(214,59,65,.07);
  --warn:#B4720B; --ok:#0E9E85; --info:#2C64C7;
  --track:rgba(15,25,35,.07); --hatch:rgba(0,0,0,.22);
}
```

**Type**: `IBM Plex Sans` for UI (400/500/600/700), `IBM Plex Mono` for all identifiers,
counts, timestamps, log text and query bodies. Base 14px / 1.5.

**Section label style**: 10px, `letter-spacing:.1em`, weight 600, `--fg3`, uppercase.

**Panels**: `1px solid var(--line)`, radius 12px, `background var(--panel)`.
Accent rails: 3px left border — `--sev` for the verdict, `--info` for executive summary,
`--warn` for trend/timing. No shadows. No nested cards.

**Radii**: panel 12, control 8, chip/pill 6, bar 3.

---

## 4. Service colour map (single source of truth)

Assign once; reuse in every chart, dot, chain node and legend.

| service | events | share | colour |
|---|---|---|---|
| xbo-events-handler-lambda | 3,835 | 60.7% | `#5B8DEF` |
| ap-get-account-accountproducts-and-devices | 985 | 19.7% | `#EC5FA8` |
| gateway-act-events-processor | 296 | 5.9% | `#3FD0A0` |
| mpa-xbo-account-refresher-lambda | 288 | 5.8% | `#F59E5B` |
| global-events-platform | 241 | 4.8% | `#8B9DF7` |
| gateway-status | 60 | 1.2% | `#E879C0` |
| ape-configset-events-handler-lambda | 37 | 0.7% | `#4FC3E0` |
| get-personalization-details-lambda | 33 | 0.7% | `#4ED8B0` |
| ap-xbo-account-product-update-lambda | 8 | 0.2% | `#C2A2F5` |
| ap-gateway-update-configset-group | 6 | 0.1% | `#7FD0F0` |
| ape-gateway-activation-events-translation | 5 | 0.1% | `#F2B84B` |
| ape-gateway-auxiliary-events-translation | 3 | 0.1% | `#A3B3C2` |
| melee_lambda_extension | 2 | 0.0% | `#9AA5B1` |
| xdp-events-handler-lambda | 1 | 0.0% | `#6E7A88` |

---

## 5. Detail screen — header

Sticky, `--bg`, bottom `1px solid var(--line)`.

- Breadcrumb (mono, 11px, `--fg3`): `TOPIC INVESTIGATION / 02536aac-db9b-489e-bfbf-9b5293e3028b`
- H1 23px / 600 / `-.02em`: the topic string
- Meta row (mono 12px): query chip `q xbo`, `Aug 17, 01:19 → Aug 24, 01:19`, `SAMPLED 5,000 / 10,000+`
- Right: severity pill (`--sevBg` fill, `--sev` border and text, 7px pulsing dot,
  2.4s `opacity 1 → .35` loop), `Re-run` (outline), `Share` (solid `--hi`, text `#04140F`)
- Tab bar: label + count badge; active tab = `--fg`, weight 600, 2px `--hi` bottom border.
  Counts: Overview `RCA`, Errors `22`, Services `14`, Accounts `1,289`, Query `—`

Content column: `max-width 1220px`, padding `24px 28px 64px`, sections stacked with 20px gap.

---

## 6. Overview tab

**6.1 Verdict card** — `border-left:3px solid var(--sev)`.
- Label `VERDICT` in `--sev`
- Statement, 19px / 600 / `-.015em`, max 74ch:
  *"Upstream state reconciliation in the XBO provisioning chain is producing sustained write/update rejections, amplified by downstream throttling."*
- Three equal facts, divided by 1px lines: **PRIMARY SIGNAL** `message failure` (mono, `--sev`) ·
  **FAILURE BOUNDARY** `ape-gateway-activation-events-translation` (mono) ·
  **OBSERVED IMPACT** `≥ 10,000 matching events` (mono)
- Footer on `--panel2`: `Likely root cause:` + full LLM root-cause paragraph, inline `<code>` in mono for every identifier.

**6.2 Stat strip** — 4 equal cells, 1px dividers, single outer border:
`TOTAL OCCURRENCES 5,000` (of 10,000+ matches) · `UNIQUE ACCOUNTS 1,289` (`--info`) ·
`UNIQUE DEVICES 762` (`--hi`) · `FAILING SERVICES 14` (`--sev`, sub: "top 2 = 80.4% of events").
Numbers 24px / 600.

**6.3 Failure path** — wrapping horizontal chain of 14 mono nodes joined by `→`.
Each node: coloured service dot + name, `--panel2` fill, `--line2` border.
The first failing hop (`ape-gateway-activation-events-translation`) is the only emphasised node:
`--sev` border, `--sevBg` fill, `--sev` text. Footnote line repeats it in `--sev`.
Order: `ap-get-account-accountproducts-and-devices → xbo-events-handler-lambda → global-events-platform → get-personalization-details-lambda → gateway-act-events-processor → ape-gateway-activation-events-translation → ape-configset-events-handler-lambda → mpa-xbo-account-refresher-lambda → ap-gateway-update-configset-group → gateway-status → ap-xbo-account-product-update-lambda → ape-gateway-auxiliary-events-translation → xdp-events-handler-lambda → melee_lambda_extension`

**6.4 Volume over window** — 180px column chart, y-axis 0–800 (ticks every 200),
5 horizontal gridlines, dashed mean line at 553, per-bar value label above each bar,
bars `--info`, radius `4px 4px 0 0`. Right of the title: mean legend +
`STABLE · 1.2× in last 20%` badge.
Buckets: `aug 17, 1am` 601 · `aug 17, 10pm` 592 · `aug 18, 7pm` 585 · `aug 19, 4pm` 574 ·
`aug 20, 1pm` 563 · `aug 21, 10am` 548 · `aug 22, 7am` 537 · `aug 23, 4am` 519 · `aug 24, 1am` 512.

**6.5 Recommended next steps** — numbered rows (mono badge on `--hiSoft`), 13.5px body,
max 96ch, `Open evidence` outline button per row. Four items, verbatim from the analysis.

**6.6 Executive summary** (`--info` rail) and **Trend and timing** (`--warn` rail) side by side,
then **What happened** full width. All body copy `--fg2`, identifiers in mono `<code>`.

---

## 7. Errors tab

**7.1 Error signatures · index-wide** — grid
`minmax(120px,300px) minmax(70px,1fr) 84px 90px`, 14px gap, 1px row dividers.
Bars share a **10,000 ceiling**. Capped values render a full-width bar plus a 9%-wide
hatched overlay at the right end (`repeating-linear-gradient(135deg, var(--hatch) 0 2px, transparent 2px 6px)`)
and a `≥` prefix on the count. Capped rows use `--sev`, uncapped `--warn`.
Header has a `linear / log` scale toggle — log uses `log10(v+1) / log10(10001)`.
Footer legend explains the hatch: *"value clipped at query ceiling — true count is higher"*.

Rows: `unable to get the access token` ≥10,000 · `exception occurred while calling devicehealth…` ≥10,000 ·
`unexpected exception occurred while awaitin…` ≥10,000 · `event\.status=FAILURE` ≥10,000 ·
`SFA_MPA_CBE_\w+` ≥10,000 · `SFA_MPA_GW_\w+` ≥10,000 · `no devices found` ≥10,000 ·
`validateinputs` 7,037 · `already_unclaimed (HTTP 400)` 280 · `TOO_MANY_REQUESTS (HTTP 429)` 72.
All scoped `Index-wide`.

**7.2 Message frequency · in sample** — grid `1fr 240px 64px 52px`.
Bars relative to the top value (860), coloured by emitting service, with a leading service dot.
Twelve rows, 860 → 43, percentages 17.2% → 0.9%.

**7.3 Anomalies** — 3-column card grid, `border-top: 2px solid` severity colour,
big mono figure + explanatory sentence. Six cards (≥10,000 ×2, ≥10,000, 7,037, 280 · 5.6%, 72 · 1.4%, 21 events).

**7.4 Failure categories · retrieved sample** — two rows.
`message failure` (`--sev`, 5 services, `source: EventHandlerLoader.java · trace: 0e26e700-fd1f-410e-9299-7c2c54d9d5b8`, 21 events 0.4%) and
`function_log_record_unmarshal` (`--warn`, melee_lambda_extension, 2 events 0%).

---

## 8. Services tab

Single panel: **Event share by service**, grid `300px 1fr 76px 58px`.
Row = colour swatch + mono name, 14px bar track (`--track`) with a fill relative to the
largest value (3,835), count, percentage. Subhead: *"Top service accounts for 60.7% of the sample."*

---

## 9. Accounts tab

**Affected accounts** — grid `minmax(150px,200px) 96px 68px 104px minmax(140px,1fr)`.
Header row on `--panel2`. Legend in the panel header maps the three recurring service colours.

- Account ID: mono, `--hi` (link)
- Occurrences: mini bar (`--info`, width = value/22 × 58px) + right-aligned number
- Devices: mono, right-aligned
- Services: coloured dots (`title` = service name) + `"N svcs"` — **no text chips**
- Time range: mono, `nowrap` with ellipsis

Eight rows, top by occurrences (7888126287827651055 / 22 / 2 … 3307468661083126719 / 12 / 12).

---

## 10. Query tab

- **Elasticsearch query** panel with `Copy` action; mono `<pre>`, `query_string: "xbo"` +
  `@timestamp` range `2026-08-17T01:19:38Z → 2026-08-24T01:19:38Z`, `size: 5000`, sort desc.
- **Sample messages (10)** — collapsible; each row = service dot + mono message + right-aligned timestamp.
- Run metadata strip (mono, `--fg3`): `ID: 02536aac-…` · `engine: vv2-topic` · `total: 235.2s` · `index: logs-*`

---

## 11. Behaviour

- Tabs, screens, theme, scale toggle and sample expansion are local UI state; deep-link each
  tab in the URL hash (`#investigation/<id>/errors`).
- Theme: `data-theme` on the app shell; persist the user's choice. Page background must follow
  the theme (don't hardcode the dark colour on `body`).
- Severity pill dot pulses; nothing else animates.
- "Spec notes" toggle (dev/design mode only) reveals dashed `--hi` annotation strips explaining
  each section's rationale.
- Responsive: every table uses `minmax()` columns so bar tracks never collapse to 0px;
  below ~1150px the label columns shrink first, bars keep real width.

---

## 12. Accessibility

- All body text ≥ 12px, meta ≥ 10.5px only for uppercase labels.
- Service colour is never the only carrier of meaning — dots always have a `title` and the
  legend or adjacent mono name.
- Severity is colour + text (`HIGH SEVERITY`), never colour alone.
